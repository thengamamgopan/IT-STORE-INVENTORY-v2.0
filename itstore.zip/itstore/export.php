<?php
/* Downloads the equipment list (with the current filters) as a CSV file that opens in Excel */
require __DIR__ . '/includes/init.php';
require_export();
$pdo = db();

[$where, $params] = device_filter($_GET);
$typeId = (int)get('type');
$type = $typeId ? get_type($typeId) : null;

$st = $pdo->prepare("SELECT d.*, t.name AS type_name FROM devices d JOIN device_types t ON t.id = d.type_id
                     WHERE $where ORDER BY t.sort_order, d.asset_tag");
$st->execute($params);
$devices = $st->fetchAll();

$values = [];
$st = $pdo->prepare("SELECT v.device_id, v.field_id, v.value, tf.label FROM device_values v
                     JOIN type_fields tf ON tf.id = v.field_id
                     WHERE v.device_id IN (SELECT d.id FROM devices d WHERE $where) ORDER BY tf.sort_order, tf.id");
$st->execute($params);
foreach ($st->fetchAll() as $r) {
    $values[(int)$r['device_id']][(int)$r['field_id']] = $r;
}
$extras = [];
$st = $pdo->prepare("SELECT device_id, label, value FROM device_extras
                     WHERE device_id IN (SELECT d.id FROM devices d WHERE $where) ORDER BY sort_order, id");
$st->execute($params);
foreach ($st->fetchAll() as $r) {
    $extras[(int)$r['device_id']][] = $r['label'] . ': ' . $r['value'];
}

$fields = $type ? get_type_fields($typeId) : [];

function csv_cell($v): string
{
    $v = (string)$v;
    // stop Excel from treating text as a formula
    if ($v !== '' && preg_match('/^[=+@\t\r]/', $v)) {
        $v = "'" . $v;
    }
    return $v;
}

$name = 'equipment' . ($type ? '-' . preg_replace('/[^a-z0-9]+/', '-', strtolower($type['name'])) : '') . '-' . date('Y-m-d') . '.csv';
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $name . '"');
header('Cache-Control: no-store');

$out = fopen('php://output', 'w');
fwrite($out, "\xEF\xBB\xBF"); // lets Excel read the file as UTF-8

$head = ['Asset tag', 'Type', 'Make', 'Model', 'Serial no.'];
foreach ($fields as $fl) {
    $head[] = $fl['label'];
}
$head = array_merge($head, ['Section', 'Location', 'Grant', 'Status']);
if (!$type) {
    $head[] = 'Specifications';
}
$head = array_merge($head, ['Additional details', 'Remarks', 'Added on', 'Last edited']);
fputcsv($out, $head, ',', '"', '');

foreach ($devices as $d) {
    $did = (int)$d['id'];
    $row = [$d['asset_tag'], $d['type_name'], $d['make'], $d['model'], $d['serial_no']];
    foreach ($fields as $fl) {
        $row[] = $values[$did][(int)$fl['id']]['value'] ?? '';
    }
    $row = array_merge($row, [$d['section'], $d['location'], $d['grant_name'], $d['status']]);
    if (!$type) {
        $spec = [];
        foreach ($values[$did] ?? [] as $v) {
            $spec[] = $v['label'] . ': ' . $v['value'];
        }
        $row[] = implode('; ', $spec);
    }
    $row[] = implode('; ', $extras[$did] ?? []);
    $row[] = $d['remarks'];
    $row[] = $d['created_at'];
    $row[] = $d['updated_at'];
    fputcsv($out, array_map('csv_cell', $row), ',', '"', '');
}
fclose($out);
