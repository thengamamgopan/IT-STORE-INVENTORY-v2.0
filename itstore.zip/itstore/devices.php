<?php
require __DIR__ . '/includes/init.php';
require_login();

$pdo = db();
$f = [
    'q'       => get('q'),
    'type'    => (int)get('type'),
    'status'  => get('status'),
    'section' => get('section'),
    'sort'    => get('sort', 'tag'),
    'dir'     => get('dir', 'asc') === 'desc' ? 'desc' : 'asc',
];
$page = max(1, (int)get('page', '1'));

if (!in_array($f['sort'], ['tag', 'type', 'make', 'serial', 'section', 'status', 'updated'], true)) {
    $f['sort'] = 'tag';
}

[$where, $params] = device_filter($f);

$st = $pdo->prepare("SELECT COUNT(*) FROM devices d WHERE $where");
$st->execute($params);
$total = (int)$st->fetchColumn();
$pages = max(1, (int)ceil($total / PER_PAGE));
$page = min($page, $pages);
$offset = ($page - 1) * PER_PAGE;

$order = device_sort_sql($f['sort'], $f['dir']);
$sql = "SELECT d.*, t.name AS type_name, t.icon AS type_icon,
          (SELECT v.value FROM device_values v JOIN type_fields tf ON tf.id = v.field_id
             WHERE v.device_id = d.id AND tf.field_type = 'ip' ORDER BY tf.sort_order, tf.id LIMIT 1) AS ip,
          (SELECT v.value FROM device_values v JOIN type_fields tf ON tf.id = v.field_id
             WHERE v.device_id = d.id AND tf.field_type = 'person' ORDER BY tf.sort_order, tf.id LIMIT 1) AS person
        FROM devices d JOIN device_types t ON t.id = d.type_id
        WHERE $where ORDER BY $order, d.id LIMIT " . (int)PER_PAGE . ' OFFSET ' . (int)$offset;
$st = $pdo->prepare($sql);
$st->execute($params);
$rows = $st->fetchAll();

// When one type is picked, show its "show in list" fields as columns
$type = $f['type'] ? get_type($f['type']) : null;
$listFields = [];
$cell = [];
if ($type) {
    $listFields = array_values(array_filter(get_type_fields((int)$type['id']), function ($fl) { return (int)$fl['show_in_list'] === 1; }));
    if ($listFields && $rows) {
        $ids = array_map('intval', array_column($rows, 'id'));
        $fids = array_map('intval', array_column($listFields, 'id'));
        $in1 = implode(',', array_fill(0, count($ids), '?'));
        $in2 = implode(',', array_fill(0, count($fids), '?'));
        $vs = $pdo->prepare("SELECT device_id, field_id, value FROM device_values WHERE device_id IN ($in1) AND field_id IN ($in2)");
        $vs->execute(array_merge($ids, $fids));
        foreach ($vs->fetchAll() as $v) {
            $cell[(int)$v['device_id']][(int)$v['field_id']] = $v['value'];
        }
    }
}

$types = get_types();
$sections = distinct_values('section');
$filtered = $f['q'] !== '' || $f['type'] || $f['status'] !== '' || $f['section'] !== '';

function qs(array $base, array $over = []): string
{
    $q = array_merge($base, $over);
    $q = array_filter($q, function ($v) { return $v !== '' && $v !== 0 && $v !== null; });
    if (($q['sort'] ?? '') === 'tag') unset($q['sort']);
    if (($q['dir'] ?? '') === 'asc') unset($q['dir']);
    if (($q['page'] ?? 1) == 1) unset($q['page']);
    return $q ? '?' . http_build_query($q) : '';
}

function sort_th(string $key, string $label, array $f, string $class = ''): string
{
    $isCur = $f['sort'] === $key;
    $dir = $isCur && $f['dir'] === 'asc' ? 'desc' : 'asc';
    $aria = $isCur ? ' aria-sort="' . ($f['dir'] === 'asc' ? 'ascending' : 'descending') . '"' : '';
    $mark = $isCur ? ($f['dir'] === 'asc' ? ' ▲' : ' ▼') : '';
    return '<th class="' . $class . '"' . $aria . '><a href="devices.php' . e(qs($f, ['sort' => $key, 'dir' => $dir])) . '">' . e($label) . $mark . '</a></th>';
}

$pageTitle = $type ? $type['name'] : 'Equipment';
$activeNav = 'devices';
require __DIR__ . '/includes/header.php';
?>
<div class="page-head">
  <div>
    <h1><?php if ($type): ?><?= icon($type['icon'], 26) ?> <?php endif; ?><?= e($type ? $type['name'] : 'Equipment') ?></h1>
    <p class="muted"><?= number_format($total) ?> item<?= $total === 1 ? '' : 's' ?><?= $filtered ? ' match your filters' : ' in the register' ?>.</p>
  </div>
  <div class="actions">
    <?php $lf = list_filters($f); $lq = function (array $extra = []) use ($lf) { $q = array_merge($lf, $extra); return $q ? '?' . http_build_query($q) : ''; }; ?>
    <?php if (can_export()): ?>
    <a class="btn" href="print.php<?= e($lq(['autoprint' => 1])) ?>" target="_blank" rel="noopener"><?= icon('print', 17) ?> Print</a>
    <details class="menu">
      <summary class="btn"><?= icon('download', 17) ?> Export</summary>
      <div class="menu-list">
        <a href="export_pdf.php<?= e($lq()) ?>"><?= icon('file', 17) ?><span>PDF<small>The list as shown, A4 landscape</small></span></a>
        <?php if ($type): ?>
        <a href="export_pdf.php<?= e($lq(['all' => 1])) ?>"><?= icon('file', 17) ?><span>PDF with all <?= e($type['name']) ?> fields<small>Every field, additional details and remarks</small></span></a>
        <?php endif; ?>
        <a href="export.php<?= e($lq()) ?>"><?= icon('sheet', 17) ?><span>Excel (CSV)<small>Every field; opens in Excel, can be imported again</small></span></a>
      </div>
    </details>
    <?php endif; ?>
    <?php if (is_admin()): ?><a class="btn" href="import.php<?= $type ? '?type=' . (int)$type['id'] : '' ?>"><?= icon('upload', 17) ?> Import</a><?php endif; ?>
    <?php if (can_edit()): ?><a class="btn btn-primary" href="device_form.php<?= $type ? '?type=' . (int)$type['id'] : '' ?>"><?= icon('plus', 17) ?> Add <?= $type ? e($type['name']) : 'equipment' ?></a><?php endif; ?>
  </div>
</div>

<form class="filters" method="get" action="devices.php">
  <label class="field grow"><span>Search</span><input type="search" name="q" value="<?= e($f['q']) ?>" placeholder="Tag, serial, make, IP, MAC, user, section…"></label>
  <label class="field"><span>Type</span>
    <select name="type">
      <option value="">All types</option>
      <?php foreach ($types as $t): ?>
        <option value="<?= (int)$t['id'] ?>" <?= $f['type'] === (int)$t['id'] ? 'selected' : '' ?>><?= e($t['name']) ?> (<?= (int)$t['item_count'] ?>)</option>
      <?php endforeach; ?>
    </select></label>
  <label class="field"><span>Status</span>
    <select name="status">
      <option value="">Any status</option>
      <?php foreach (STATUS_OPTIONS as $s): ?><option <?= $f['status'] === $s ? 'selected' : '' ?>><?= e($s) ?></option><?php endforeach; ?>
    </select></label>
  <label class="field"><span>Section</span>
    <select name="section">
      <option value="">All sections</option>
      <?php foreach ($sections as $s): ?><option <?= $f['section'] === $s ? 'selected' : '' ?>><?= e($s) ?></option><?php endforeach; ?>
    </select></label>
  <?php if ($f['sort'] !== 'tag'): ?><input type="hidden" name="sort" value="<?= e($f['sort']) ?>"><input type="hidden" name="dir" value="<?= e($f['dir']) ?>"><?php endif; ?>
  <div class="filter-btns">
    <button class="btn btn-primary" type="submit"><?= icon('search', 16) ?> Filter</button>
    <?php if ($filtered): ?><a class="btn btn-ghost" href="devices.php">Clear</a><?php endif; ?>
  </div>
</form>

<?php if (!$rows): ?>
  <div class="empty">
    <?= icon($type ? $type['icon'] : 'search', 40) ?>
    <?php if ($filtered): ?>
      <h2>Nothing matches</h2>
      <p>No equipment matches these filters. Try fewer words, or clear the filters.</p>
      <p><a class="btn" href="devices.php">Clear filters</a></p>
    <?php else: ?>
      <h2>The register is empty</h2>
      <p>Add the first item to start the register.</p>
      <?php if (can_edit()): ?><p><a class="btn btn-primary" href="device_form.php"><?= icon('plus', 17) ?> Add equipment</a></p><?php endif; ?>
    <?php endif; ?>
  </div>
<?php else: ?>
<div class="table-wrap">
<table class="table devices">
  <thead><tr>
    <?= sort_th('tag', 'Asset tag', $f) ?>
    <?php if (!$type): ?><?= sort_th('type', 'Type', $f) ?><?php endif; ?>
    <?= sort_th('make', 'Make & model', $f) ?>
    <?= sort_th('serial', 'Serial no.', $f) ?>
    <?php if ($type): foreach ($listFields as $lf): ?><th><?= e($lf['label']) ?></th><?php endforeach; else: ?>
      <th>IP address</th><th>User</th>
    <?php endif; ?>
    <?= sort_th('section', 'Section', $f) ?>
    <?= sort_th('status', 'Status', $f) ?>
    <?php if (can_edit()): ?><th class="row-actions"><span class="sr">Actions</span></th><?php endif; ?>
  </tr></thead>
  <tbody>
  <?php foreach ($rows as $r): $id = (int)$r['id']; ?>
    <tr data-href="device_view.php?id=<?= $id ?>">
      <td><a href="device_view.php?id=<?= $id ?>"><?= asset_tag($r['asset_tag']) ?></a></td>
      <?php if (!$type): ?><td class="nowrap"><span class="type-name"><?= icon($r['type_icon'], 16) ?><?= e($r['type_name']) ?></span></td><?php endif; ?>
      <td><b><?= e($r['make']) ?></b> <?= e($r['model']) ?></td>
      <td class="data"><?= e($r['serial_no']) ?></td>
      <?php if ($type): foreach ($listFields as $lf):
          $v = $cell[$id][(int)$lf['id']] ?? ''; ?>
        <td class="<?= in_array($lf['field_type'], ['ip', 'mac'], true) ? 'data' : '' ?>"><?= $lf['field_type'] === 'date' && $v ? e(fmt_date($v, false)) : e($v) ?></td>
      <?php endforeach; else: ?>
        <td class="data"><?= e($r['ip']) ?></td>
        <td><?= e($r['person']) ?></td>
      <?php endif; ?>
      <td><?= e($r['section']) ?></td>
      <td><?= status_badge($r['status']) ?></td>
      <?php if (can_edit()): ?><td class="row-actions"><a class="icon-btn" href="device_form.php?id=<?= $id ?>" title="Edit <?= e($r['asset_tag']) ?>" aria-label="Edit <?= e($r['asset_tag']) ?>"><?= icon('edit', 16) ?></a></td><?php endif; ?>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>

<?php if ($pages > 1): ?>
<nav class="pager" aria-label="Pages">
  <span class="muted">Showing <?= $offset + 1 ?> to <?= min($offset + PER_PAGE, $total) ?> of <?= number_format($total) ?></span>
  <span class="pager-links">
    <?php if ($page > 1): ?><a class="btn btn-sm" href="devices.php<?= e(qs($f, ['page' => $page - 1])) ?>">Previous</a><?php endif; ?>
    <?php for ($p = max(1, $page - 2); $p <= min($pages, $page + 2); $p++): ?>
      <?php if ($p === $page): ?><span class="btn btn-sm current" aria-current="page"><?= $p ?></span>
      <?php else: ?><a class="btn btn-sm" href="devices.php<?= e(qs($f, ['page' => $p])) ?>"><?= $p ?></a><?php endif; ?>
    <?php endfor; ?>
    <?php if ($page < $pages): ?><a class="btn btn-sm" href="devices.php<?= e(qs($f, ['page' => $page + 1])) ?>">Next</a><?php endif; ?>
  </span>
</nav>
<?php endif; ?>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php';
