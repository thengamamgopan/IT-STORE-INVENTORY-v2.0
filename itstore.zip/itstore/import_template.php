<?php
/* Blank CSV template for the importer: just the column names */
require __DIR__ . '/includes/init.php';
require_admin();

$type = (int)get('type') ? get_type((int)get('type')) : null;
$head = ['Asset tag'];
if (!$type) {
    $head[] = 'Type';
}
$head = array_merge($head, ['Make', 'Model', 'Serial no.']);
if ($type) {
    foreach (get_type_fields((int)$type['id']) as $fl) {
        $head[] = $fl['label'];
    }
}
$head = array_merge($head, ['Section', 'Location', 'Grant', 'Status', 'Additional details', 'Remarks']);

$name = 'import-template-' . ($type ? strtolower(preg_replace('/[^A-Za-z0-9]+/', '-', $type['name'])) : 'mixed') . '.csv';
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $name . '"');
header('Cache-Control: no-store');
$out = fopen('php://output', 'w');
fwrite($out, "\xEF\xBB\xBF");
fputcsv($out, $head, ',', '"', '');
fclose($out);
