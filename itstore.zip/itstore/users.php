<?php
require __DIR__ . '/includes/init.php';
require_admin();
$pdo = db();
$me = current_user();
ensure_guest_role();

$editId = (int)get('edit');
$editing = null;
if ($editId) {
    $st = $pdo->prepare('SELECT * FROM users WHERE id = ?');
    $st->execute([$editId]);
    $editing = $st->fetch() ?: null;
    if (!$editing) {
        $editId = 0;
    }
}
$errors = [];
$form = $editing ?: ['full_name' => '', 'username' => '', 'role' => 'user', 'is_active' => 1];

function can_guests_export_text(): string
{
    return (!defined('GUESTS_CAN_EXPORT') || GUESTS_CAN_EXPORT) ? ', search, print and download lists' : ' and search; no printing or downloads';
}

function active_admins(PDO $pdo, int $exceptId): int
{
    $st = $pdo->prepare("SELECT COUNT(*) FROM users WHERE role = 'admin' AND is_active = 1 AND id <> ?");
    $st->execute([$exceptId]);
    return (int)$st->fetchColumn();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $uid = (int)post('user_id');
    $pass = isset($_POST['password']) && is_string($_POST['password']) ? $_POST['password'] : '';
    $form = [
        'full_name' => str_cut(post('full_name'), 100),
        'username'  => strtolower(post('username')),
        'role'      => in_array(post('role'), ['admin', 'user', 'guest'], true) ? post('role') : 'user',
        'is_active' => post('is_active') === '1' ? 1 : 0,
    ];
    if (!$uid) {
        $form['is_active'] = 1;
    }

    if ($form['full_name'] === '') {
        $errors[] = 'Enter the person\'s full name.';
    }
    if (!preg_match('/^[a-z0-9._-]{3,50}$/', $form['username'])) {
        $errors[] = 'Username must be 3 to 50 characters: letters, numbers, dot, dash or underscore.';
    } else {
        $chk = $pdo->prepare('SELECT COUNT(*) FROM users WHERE username = ? AND id <> ?');
        $chk->execute([$form['username'], $uid]);
        if ($chk->fetchColumn()) {
            $errors[] = 'The username "' . $form['username'] . '" is already taken.';
        }
    }
    if (!$uid && strlen($pass) < 8) {
        $errors[] = 'Password must be at least 8 characters.';
    }
    if ($uid && $pass !== '' && strlen($pass) < 8) {
        $errors[] = 'The new password must be at least 8 characters.';
    }
    if ($uid && ($form['role'] !== 'admin' || !$form['is_active'])) {
        if ($uid === (int)$me['id']) {
            $errors[] = 'You cannot remove your own admin rights or switch off your own account.';
        } elseif (active_admins($pdo, $uid) === 0) {
            $errors[] = 'There must be at least one active admin.';
        }
    }

    if (!$errors) {
        if ($uid) {
            $pdo->prepare('UPDATE users SET full_name=?, username=?, role=?, is_active=?, failed_logins=0, locked_until=NULL WHERE id=?')
                ->execute([$form['full_name'], $form['username'], $form['role'], $form['is_active'], $uid]);
            if ($pass !== '') {
                $pdo->prepare('UPDATE users SET password_hash=? WHERE id=?')->execute([password_hash($pass, PASSWORD_DEFAULT), $uid]);
            }
            log_activity('user_updated', null, '', 'Edited user ' . $form['username'] . ($pass !== '' ? ' (password reset)' : ''));
            flash('success', 'Saved <b>' . e($form['full_name']) . '</b>.' . ($pass !== '' ? ' Their new password works from now on.' : ''));
        } else {
            $pdo->prepare('INSERT INTO users (username, full_name, password_hash, role, created_at) VALUES (?,?,?,?,?)')
                ->execute([$form['username'], $form['full_name'], password_hash($pass, PASSWORD_DEFAULT), $form['role'], now()]);
            log_activity('user_added', null, '', 'Added ' . $form['role'] . ' ' . $form['username']);
            flash('success', 'Added <b>' . e($form['full_name']) . '</b>. They can sign in as <b>' . e($form['username']) . '</b>.');
        }
        redirect('users.php');
    }
    $editId = $uid;
}

$users = $pdo->query('SELECT * FROM users ORDER BY is_active DESC, role, full_name')->fetchAll();
$pageTitle = 'Users';
$activeNav = 'users';
require __DIR__ . '/includes/header.php';
?>
<div class="page-head">
  <div>
    <h1>Users</h1>
    <p class="muted">Admins can do everything. Users can view, add and edit equipment<?= USERS_CAN_DELETE ? ', and delete it' : ' but cannot delete it' ?>.
      Guests can only view<?= can_guests_export_text() ?>.</p>
  </div>
</div>

<div class="split">
  <section class="panel">
    <table class="table">
      <thead><tr><th>Name</th><th>Username</th><th>Role</th><th>Last signed in</th><th>Account</th><th class="row-actions"><span class="sr">Actions</span></th></tr></thead>
      <tbody>
      <?php foreach ($users as $u): $locked = $u['locked_until'] && strtotime($u['locked_until']) > time(); ?>
        <tr class="<?= $u['is_active'] ? '' : 'is-off' ?><?= (int)$u['id'] === $editId ? ' is-editing' : '' ?>">
          <td><b><?= e($u['full_name']) ?></b><?= (int)$u['id'] === (int)$me['id'] ? ' <small class="muted">(you)</small>' : '' ?></td>
          <td><?= e($u['username']) ?></td>
          <td><?= e(role_label($u['role'])) ?></td>
          <td><?= $u['last_login'] ? e(fmt_date($u['last_login'])) : '<span class="muted">Never</span>' ?></td>
          <td><?php if (!$u['is_active']): ?><span class="muted">Switched off</span><?php elseif ($locked): ?><span class="status st-bad">Locked</span><?php else: ?>Active<?php endif; ?></td>
          <td class="row-actions"><a class="icon-btn" href="users.php?edit=<?= (int)$u['id'] ?>#user-form" aria-label="Edit <?= e($u['full_name']) ?>"><?= icon('edit', 16) ?></a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </section>

  <section class="panel form-panel" id="user-form">
    <h2><?= $editId ? 'Edit ' . e($form['full_name'] ?: 'user') : 'Add a user' ?></h2>
    <?php if ($errors): ?><div class="notice notice-error"><?= implode('<br>', array_map('e', $errors)) ?></div><?php endif; ?>
    <form method="post" class="stack" autocomplete="off">
      <?= csrf_field() ?>
      <input type="hidden" name="user_id" value="<?= $editId ?>">
      <label class="field"><span>Full name</span><input name="full_name" value="<?= e($form['full_name']) ?>" maxlength="100" required></label>
      <label class="field"><span>Username</span><input name="username" value="<?= e($form['username']) ?>" maxlength="50" required autocapitalize="none"></label>
      <label class="field"><span><?= $editId ? 'New password <small class="muted">(leave blank to keep the current one)</small>' : 'Password <small class="muted">(at least 8 characters)</small>' ?></span>
        <input type="password" name="password" minlength="8" autocomplete="new-password" <?= $editId ? '' : 'required' ?>></label>
      <fieldset class="field"><legend>Role</legend>
        <div class="seg">
          <label><input type="radio" name="role" value="guest" <?= $form['role'] === 'guest' ? 'checked' : '' ?>><span>Guest</span></label>
          <label><input type="radio" name="role" value="user" <?= !in_array($form['role'], ['admin', 'guest'], true) ? 'checked' : '' ?>><span>User</span></label>
          <label><input type="radio" name="role" value="admin" <?= $form['role'] === 'admin' ? 'checked' : '' ?>><span>Admin</span></label>
        </div>
        <small class="hint">Guest: view only<?= can_guests_export_text() ?>. User: add and edit. Admin: everything.</small>
      </fieldset>
      <?php if ($editId): ?>
        <label class="check"><input type="checkbox" name="is_active" value="1" <?= $form['is_active'] ? 'checked' : '' ?>> Account is on (untick to stop this person signing in)</label>
        <p class="muted small">Saving also unlocks the account if it was locked after wrong passwords.</p>
      <?php endif; ?>
      <div class="row-btns">
        <button class="btn btn-primary" type="submit"><?= $editId ? 'Save user' : 'Add user' ?></button>
        <?php if ($editId): ?><a class="btn btn-ghost" href="users.php">Cancel</a><?php endif; ?>
      </div>
    </form>
  </section>
</div>
<?php require __DIR__ . '/includes/footer.php';
