<?php
/* Import equipment from a CSV file: upload, check, then save */
require __DIR__ . '/includes/init.php';
require __DIR__ . '/includes/import_lib.php';
require_admin();

$types = get_types();
$error = '';

function import_forget(): void
{
    if (!empty($_SESSION['import']['file']) && is_file($_SESSION['import']['file'])) {
        @unlink($_SESSION['import']['file']);
    }
    unset($_SESSION['import']);
}

$job = $_SESSION['import'] ?? null;
if ($job && (empty($job['file']) || !is_file($job['file']))) {
    unset($_SESSION['import']);
    $job = null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = post('action');

    if ($action === 'cancel') {
        import_forget();
        redirect('import.php');
    }

    if ($action === 'check') {
        import_forget();
        $up = $_FILES['file'] ?? null;
        $code = is_array($up) ? (int)$up['error'] : UPLOAD_ERR_NO_FILE;
        $ext = is_array($up) ? strtolower(pathinfo((string)$up['name'], PATHINFO_EXTENSION)) : '';
        if ($code === UPLOAD_ERR_NO_FILE) {
            $error = 'Choose a CSV file to import.';
        } elseif ($code === UPLOAD_ERR_INI_SIZE || $code === UPLOAD_ERR_FORM_SIZE || ($code === UPLOAD_ERR_OK && $up['size'] > IMPORT_MAX_BYTES)) {
            $error = 'The file is too big. The limit is ' . round(IMPORT_MAX_BYTES / 1048576) . ' MB; split it into smaller files.';
        } elseif ($code !== UPLOAD_ERR_OK) {
            $error = 'The upload did not finish (error ' . $code . '). Try again.';
        } elseif (in_array($ext, ['xlsx', 'xls', 'ods'], true)) {
            $error = 'This is a spreadsheet file. In Excel choose File > Save As > "CSV UTF-8 (Comma delimited)", then import that file.';
        } elseif (!in_array($ext, ['csv', 'txt', 'tsv'], true)) {
            $error = 'Import a .csv file saved from Excel or exported from this app.';
        } else {
            $tmp = tempnam(sys_get_temp_dir(), 'itsimp');
            if ($tmp === false || !move_uploaded_file($up['tmp_name'], $tmp)) {
                $error = 'The server could not keep the uploaded file. Check that PHP\'s temp folder is writable.';
            } else {
                $_SESSION['import'] = [
                    'file' => $tmp,
                    'name' => str_cut(basename((string)$up['name']), 120),
                    'type' => (int)post('type'),
                    'mode' => post('mode') === 'update' ? 'update' : 'skip',
                ];
                redirect('import.php?step=check');
            }
        }
    }

    if ($action === 'import') {
        if (!$job) {
            flash('error', 'The uploaded file has expired. Upload it again.');
            redirect('import.php');
        }
        $readErr = '';
        $table = import_read_csv($job['file'], $readErr);
        if ($table === null) {
            import_forget();
            flash('error', e($readErr));
            redirect('import.php');
        }
        $an = import_analyse($table, $job['type'], $job['mode']);
        $done = import_apply($an, $job['name']);
        import_forget();

        $parts = [];
        if ($done['added']) {
            $parts[] = $done['added'] . ' new item' . ($done['added'] === 1 ? '' : 's') . ' added';
        }
        if ($done['updated']) {
            $parts[] = $done['updated'] . ' updated';
        }
        if ($done['unchanged']) {
            $parts[] = $done['unchanged'] . ' already up to date';
        }
        if ($an['counts']['skip']) {
            $parts[] = $an['counts']['skip'] . ' skipped because the asset tag was already in the register';
        }
        if (!$parts) {
            $parts[] = 'nothing needed to change';
        }
        flash('success', 'Import of <b>' . e($job['name']) . '</b> finished: ' . implode(', ', $parts) . '.');
        if ($an['counts']['error']) {
            flash('warning', $an['counts']['error'] . ' row' . ($an['counts']['error'] === 1 ? ' had problems and was' : 's had problems and were') . ' left out. Fix them in the file and import it again.');
        }
        redirect('devices.php' . ($job['type'] ? '?type=' . $job['type'] . '&sort=updated&dir=desc' : '?sort=updated&dir=desc'));
    }
}

$pageTitle = 'Import equipment';
$activeNav = 'devices';
$typeName = function (int $id) use ($types): string {
    foreach ($types as $t) {
        if ((int)$t['id'] === $id) {
            return $t['name'];
        }
    }
    return '';
};

/* ---------- Step 2: show what will happen ---------- */
if ($job && get('step') === 'check') {
    $readErr = '';
    $table = import_read_csv($job['file'], $readErr);
    if ($table === null) {
        import_forget();
        $error = $readErr;
    } else {
        $an = import_analyse($table, $job['type'], $job['mode']);
        $c = $an['counts'];
        $willSave = $c['add'] + $c['update'];
        $rows = $an['rows'];
        // problems first, then warnings, then the rest, each in file order
        usort($rows, function ($a, $b) {
            $rank = function ($r) {
                if ($r['action'] === 'error') return 0;
                if ($r['action'] === 'same' || $r['action'] === 'skip') return 3;
                return $r['warnings'] ? 1 : 2;
            };
            return [$rank($a), $a['line']] <=> [$rank($b), $b['line']];
        });
        $shown = array_slice($rows, 0, 300);
        $labels = ['add' => ['New', 'st-ok'], 'update' => ['Update', 'st-other'], 'same' => ['No change', 'st-skip'], 'skip' => ['Skip', 'st-skip'], 'error' => ['Problem', 'st-bad']];

        require __DIR__ . '/includes/header.php'; ?>
        <div class="page-head">
          <div>
            <p class="crumb"><a href="import.php">Import equipment</a></p>
            <h1>Check the import</h1>
            <p class="muted"><b><?= e($job['name']) ?></b>, <?= number_format(count($an['rows'])) ?> row<?= count($an['rows']) === 1 ? '' : 's' ?>. Nothing is saved until you click Import.</p>
          </div>
        </div>

        <dl class="tally">
          <div class="tally-ok"><dt>New items</dt><dd><?= $c['add'] ?></dd></div>
          <div><dt>Updates</dt><dd><?= $c['update'] ?></dd></div>
          <div><dt><?= $job['mode'] === 'update' ? 'Already up to date' : 'Skipped (already in register)' ?></dt><dd><?= $job['mode'] === 'update' ? $c['same'] : $c['skip'] ?></dd></div>
          <div class="tally-bad"><dt>Rows with problems</dt><dd><?= $c['error'] ?></dd></div>
        </dl>

        <div class="preview-stack">
          <section class="panel">
            <div class="panel-head"><h2>Rows</h2><?php if (count($rows) > 300): ?><span class="muted small">Showing 300 of <?= number_format(count($rows)) ?>, problems first</span><?php endif; ?></div>
            <div class="table-scroll">
            <table class="table import-table">
              <thead><tr><th class="num">Row</th><th>Result</th><th>Asset tag</th><th>Type</th><th>Make &amp; model</th><th>Serial no.</th><th>Notes</th></tr></thead>
              <tbody>
              <?php foreach ($shown as $r):
                  $core = $r['core']; ?>
                <tr>
                  <td class="num muted"><?= (int)$r['line'] ?></td>
                  <td><span class="status <?= $labels[$r['action']][1] ?>"><?= $labels[$r['action']][0] ?></span></td>
                  <td><?= $r['tag'] !== '' ? asset_tag($r['tag'], 'tag-sm') : '<span class="muted small">Next number</span>' ?></td>
                  <td class="nowrap"><?= e($r['type_id'] ? $an['types'][$r['type_id']]['name'] : '') ?></td>
                  <td><?= e(trim(($core['make'] ?? '') . ' ' . ($core['model'] ?? ''))) ?></td>
                  <td class="data"><?= e($core['serial_no'] ?? '') ?></td>
                  <td class="notes">
                    <?php foreach ($r['errors'] as $m): ?><div class="err-line"><?= e($m) ?></div><?php endforeach; ?>
                    <?php foreach ($r['warnings'] as $m): ?><div class="warn-line"><?= e($m) ?></div><?php endforeach; ?>
                    <?php if ($r['action'] === 'update'): ?><div class="change-line"><?= e(implode('; ', $r['changes'])) ?></div><?php endif; ?>
                    <?php if (!$r['errors'] && !$r['warnings'] && $r['action'] !== 'update'): ?><span class="muted small"><?= count(array_filter($r['values'], 'strlen')) ?> field<?= count(array_filter($r['values'], 'strlen')) === 1 ? '' : 's' ?><?= $r['extras'] ? ', ' . count($r['extras']) . ' additional detail' . (count($r['extras']) === 1 ? '' : 's') : '' ?></span><?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
            </div>
          </section>

          <section class="panel">
            <div class="panel-head"><h2>How the columns are read</h2></div>
            <table class="table compact col-map">
              <tbody>
              <?php foreach ($an['columns'] as $col): ?>
                <tr><td><b><?= e($col[0]) ?></b></td><td class="<?= $col[1] === 'Not imported' ? 'muted' : '' ?>"><?= e($col[1]) ?></td></tr>
              <?php endforeach; ?>
              </tbody>
            </table>
            <p class="muted small pad">Type: <?= $job['type'] ? e($typeName($job['type'])) . ' (unless a row has its own Type)' : 'read from each row\'s Type column' ?>.<br>
              Existing asset tags: <?= $job['mode'] === 'update' ? 'update the item; blank cells keep the current value' : 'skip the row' ?>.</p>
          </section>
        </div>

        <form method="post" class="form-bar">
          <?= csrf_field() ?>
          <button class="btn btn-primary" type="submit" name="action" value="import" <?= $willSave ? '' : 'disabled' ?>>
            <?= $willSave ? 'Import ' . $willSave . ' item' . ($willSave === 1 ? '' : 's') : 'Nothing to import' ?></button>
          <button class="btn" type="submit" name="action" value="cancel">Choose another file</button>
          <?php if ($c['error']): ?><span class="muted small form-bar-note"><?= $c['error'] ?> row<?= $c['error'] === 1 ? '' : 's' ?> with problems will be left out.</span><?php endif; ?>
        </form>
        <?php require __DIR__ . '/includes/footer.php';
        exit;
    }
}

/* ---------- Step 1: upload ---------- */
$preType = (int)get('type');
require __DIR__ . '/includes/header.php';
?>
<div class="page-head">
  <div>
    <p class="crumb"><a href="devices.php">Equipment</a></p>
    <h1>Import equipment</h1>
    <p class="muted">Add many items at once from a CSV file, such as your existing stock list saved from Excel.</p>
  </div>
</div>
<?php if ($error): ?><div class="notice notice-error" role="alert"><?= e($error) ?></div><?php endif; ?>

<div class="split">
  <section class="panel form-panel">
    <h2>Upload a file</h2>
    <form method="post" enctype="multipart/form-data" class="stack">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="check">
      <label class="field"><span>CSV file</span>
        <input type="file" name="file" accept=".csv,.txt,.tsv,text/csv" required>
        <small class="hint">Up to <?= number_format(IMPORT_MAX_ROWS) ?> rows and <?= round(IMPORT_MAX_BYTES / 1048576) ?> MB.</small></label>
      <label class="field"><span>Type of equipment in the file</span>
        <select name="type">
          <option value="0">Mixed: each row has a Type column</option>
          <?php foreach ($types as $t): ?><option value="<?= (int)$t['id'] ?>" <?= $preType === (int)$t['id'] ? 'selected' : '' ?>><?= e($t['name']) ?></option><?php endforeach; ?>
        </select>
        <small class="hint">If the file has a Type column, its value is used for that row.</small></label>
      <fieldset class="field"><legend>When an asset tag is already in the register</legend>
        <label class="check"><input type="radio" name="mode" value="skip" checked> Skip that row</label>
        <label class="check"><input type="radio" name="mode" value="update"> Update that item from the file (blank cells keep the current value)</label>
      </fieldset>
      <button class="btn btn-primary" type="submit">Check the file</button>
      <p class="muted small">Next you will see every row and what will happen to it. Nothing is saved yet.</p>
    </form>
  </section>

  <section class="panel form-panel">
    <h2>Preparing the file</h2>
    <form method="get" action="import_template.php" class="template-form">
      <label class="field"><span>Download a blank template</span>
        <select name="type">
          <option value="0">Mixed types (with a Type column)</option>
          <?php foreach ($types as $t): ?><option value="<?= (int)$t['id'] ?>" <?= $preType === (int)$t['id'] ? 'selected' : '' ?>><?= e($t['name']) ?></option><?php endforeach; ?>
        </select></label>
      <button class="btn" type="submit"><?= icon('download', 16) ?> Template</button>
    </form>
    <ul class="tips">
      <li>The first row must be the column names. Columns can be in any order.</li>
      <li>Known names: Asset tag, Type, Make, Model, Serial no., Section, Location, Grant, Status, Remarks, plus each type's field names (Processor, RAM, IP address, User of the PC…).</li>
      <li>Any other column is kept as an additional detail, for example "Purchase date" or "Supplier".</li>
      <li>Leave Asset tag empty to number items automatically (PC-0001, PC-0002…).</li>
      <li>Dates: YYYY-MM-DD or DD/MM/YYYY. Status: Serviceable or Unserviceable; empty means Serviceable.</li>
      <li>A file exported from this app (Export, Excel CSV) can be imported again as it is.</li>
      <li>In Excel, save with File &gt; Save As &gt; "CSV UTF-8 (Comma delimited)".</li>
    </ul>
  </section>
</div>
<?php require __DIR__ . '/includes/footer.php';
