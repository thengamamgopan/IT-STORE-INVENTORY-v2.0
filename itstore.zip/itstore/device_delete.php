<?php
require __DIR__ . '/includes/init.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('devices.php');
}
csrf_check();
if (!can_delete()) {
    flash('error', 'Only administrators can delete equipment.');
    redirect('devices.php');
}

$id = (int)post('id');
$d = load_device($id);
if (!$d) {
    flash('error', 'That item was already deleted.');
    redirect('devices.php');
}

// Keep a copy of what was deleted in the activity log
$lines = [trim($d['type_name'] . ': ' . $d['make'] . ' ' . $d['model'])];
if ($d['serial_no'] !== '') {
    $lines[] = 'Serial no.: ' . $d['serial_no'];
}
$vals = load_device_values($id);
foreach (get_type_fields((int)$d['type_id']) as $fl) {
    $v = $vals[(int)$fl['id']] ?? '';
    if ($v !== '') {
        $lines[] = $fl['label'] . ': ' . $v;
    }
}
foreach (['section' => 'Section', 'location' => 'Location', 'grant_name' => 'Grant', 'status' => 'Status'] as $k => $lab) {
    if ($d[$k] !== '') {
        $lines[] = "$lab: " . $d[$k];
    }
}

$pdo = db();
$pdo->beginTransaction();
$pdo->prepare('DELETE FROM devices WHERE id = ?')->execute([$id]);
$pdo->prepare('UPDATE activity_log SET device_id = NULL WHERE device_id = ?')->execute([$id]);
log_activity('deleted', null, $d['asset_tag'], implode("\n", $lines));
$pdo->commit();

flash('success', 'Deleted <b>' . e($d['asset_tag']) . '</b> from the register.');
redirect('devices.php');
