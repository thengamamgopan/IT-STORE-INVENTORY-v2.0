<?php
require __DIR__ . '/includes/init.php';
require_login();

$id = (int)get('id');
$d = load_device($id);
if (!$d) {
    flash('error', 'That item is not in the register any more.');
    redirect('devices.php');
}
$fields = get_type_fields((int)$d['type_id']);
$values = load_device_values($id);
$extras = load_device_extras($id);

$st = db()->prepare('SELECT * FROM activity_log WHERE device_id = ? ORDER BY id DESC LIMIT 30');
$st->execute([$id]);
$history = $st->fetchAll();

function show_value(string $v, string $kind = 'text'): string
{
    if ($v === '') {
        return '<span class="muted">—</span>';
    }
    if ($kind === 'date') {
        return e(fmt_date($v, false));
    }
    if (in_array($kind, ['ip', 'mac'], true)) {
        return '<span class="data">' . e($v) . '</span>';
    }
    return nl2br(e($v));
}

$pageTitle = $d['asset_tag'];
$activeNav = 'devices';
require __DIR__ . '/includes/header.php';
?>
<div class="print-only print-head"><b><?= e(ORG_NAME) ?></b> | <?= e(APP_NAME) ?> | printed <?= e(fmt_date(now())) ?></div>

<div class="device-head">
  <div class="tag-lg" aria-label="Asset tag">
    <small><?= e(ORG_NAME) ?></small>
    <b><?= e($d['asset_tag']) ?></b>
  </div>
  <div class="device-title">
    <a class="type-name muted" href="devices.php?type=<?= (int)$d['type_id'] ?>"><?= icon($d['type_icon'], 16) ?><?= e($d['type_name']) ?></a>
    <h1><?= e(trim($d['make'] . ' ' . $d['model'])) ?: e($d['type_name']) ?></h1>
    <p><?= status_badge($d['status']) ?><?php if ($d['serial_no'] !== ''): ?> <span class="muted">Serial no.</span> <span class="data"><?= e($d['serial_no']) ?></span><?php endif; ?></p>
  </div>
  <div class="actions no-print">
    <?php if (can_edit()): ?>
    <a class="btn btn-primary" href="device_form.php?id=<?= $id ?>"><?= icon('edit', 16) ?> Edit</a>
    <a class="btn" href="device_form.php?copy=<?= $id ?>" title="Start a new item with the same make, model and specs"><?= icon('copy', 16) ?> Add similar</a>
    <?php endif; ?>
    <button class="btn" type="button" data-print><?= icon('print', 16) ?> Print</button>
    <?php if (can_delete()): ?>
      <form method="post" action="device_delete.php" data-confirm="Delete <?= e($d['asset_tag']) ?> from the register? This cannot be undone.">
        <?= csrf_field() ?><input type="hidden" name="id" value="<?= $id ?>">
        <button class="btn btn-danger" type="submit"><?= icon('trash', 16) ?> Delete</button>
      </form>
    <?php endif; ?>
  </div>
</div>

<div class="view-grid">
  <div class="view-main">
    <section class="panel">
      <h2>Identification and placement</h2>
      <dl class="specs">
        <div><dt>Make</dt><dd><?= show_value($d['make']) ?></dd></div>
        <div><dt>Model</dt><dd><?= show_value($d['model']) ?></dd></div>
        <div><dt>Serial number</dt><dd><?= $d['serial_no'] !== '' ? '<span class="data">' . e($d['serial_no']) . '</span>' : show_value('') ?></dd></div>
        <div><dt>Section</dt><dd><?= $d['section'] !== '' ? '<a href="devices.php?section=' . urlencode($d['section']) . '">' . e($d['section']) . '</a>' : show_value('') ?></dd></div>
        <div><dt>Location</dt><dd><?= show_value($d['location']) ?></dd></div>
        <div><dt>Grant</dt><dd><?= show_value($d['grant_name']) ?></dd></div>
        <div><dt>Status</dt><dd><?= status_badge($d['status']) ?></dd></div>
      </dl>
    </section>

    <?php if ($fields): ?>
    <section class="panel">
      <h2><?= e($d['type_name']) ?> details</h2>
      <dl class="specs">
        <?php foreach ($fields as $fl): $v = (string)($values[(int)$fl['id']] ?? ''); ?>
          <div class="<?= $fl['field_type'] === 'textarea' ? 'span-2' : '' ?>"><dt><?= e($fl['label']) ?></dt><dd><?= show_value($v, $fl['field_type']) ?></dd></div>
        <?php endforeach; ?>
      </dl>
    </section>
    <?php endif; ?>

    <?php if ($extras || $d['remarks'] !== ''): ?>
    <section class="panel">
      <h2>Additional details</h2>
      <?php if ($extras): ?>
      <dl class="specs">
        <?php foreach ($extras as $x): ?><div><dt><?= e($x['label']) ?></dt><dd><?= show_value($x['value']) ?></dd></div><?php endforeach; ?>
      </dl>
      <?php endif; ?>
      <?php if ($d['remarks'] !== ''): ?>
        <h3>Remarks</h3>
        <p class="remarks-text"><?= nl2br(e($d['remarks'])) ?></p>
      <?php endif; ?>
    </section>
    <?php endif; ?>
  </div>

  <aside class="view-side">
    <section class="panel">
      <h2>Record</h2>
      <dl class="specs one-col">
        <div><dt>Added</dt><dd><?= e(fmt_date($d['created_at'])) ?><?= $d['created_by_name'] ? ' by ' . e($d['created_by_name']) : '' ?></dd></div>
        <div><dt>Last edited</dt><dd><?= e(fmt_date($d['updated_at'])) ?><?= $d['updated_by_name'] ? ' by ' . e($d['updated_by_name']) : '' ?></dd></div>
      </dl>
    </section>
    <section class="panel no-print">
      <h2>History</h2>
      <ol class="history">
        <?php foreach ($history as $h): ?>
          <li>
            <div><b><?= e(action_label($h['action'])) ?></b> <span class="muted">by <?= e($h['username']) ?>, <?= e(fmt_date($h['created_at'])) ?></span></div>
            <?php if ($h['details'] && $h['action'] === 'updated'): ?>
              <ul class="changes"><?php foreach (explode("\n", $h['details']) as $line): ?><li><?= e($line) ?></li><?php endforeach; ?></ul>
            <?php endif; ?>
          </li>
        <?php endforeach; ?>
      </ol>
    </section>
  </aside>
</div>
<?php require __DIR__ . '/includes/footer.php';
