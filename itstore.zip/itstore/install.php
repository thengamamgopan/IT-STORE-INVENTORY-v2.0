<?php
/*
 * One-time setup: creates the database, the tables, the starter device types
 * and the first admin account. It refuses to run again once an admin exists.
 */
require __DIR__ . '/includes/init.php';
require __DIR__ . '/includes/schema.php';

function install_page(string $title, string $body): void
{
    ?><!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> | <?= e(APP_NAME) ?></title><link rel="stylesheet" href="assets/style.css?v=4"><link rel="icon" type="image/svg+xml" href="assets/favicon.svg"></head>
<body class="auth-page"><main class="auth-card wide">
<div class="auth-brand"><span class="brand-mark" aria-hidden="true">IT</span><div><b><?= e(APP_NAME) ?></b><small>Setup</small></div></div>
<?= $body ?>
</main></body></html><?php
    exit;
}

if (!extension_loaded('pdo_mysql')) {
    install_page('Setup', '<h1>Turn on pdo_mysql first</h1><p>In WAMP, left-click the tray icon, open <b>PHP &gt; PHP extensions</b> and tick <b>pdo_mysql</b>. Then reload this page.</p>');
}

// Connect to the MySQL server (without choosing a database yet)
try {
    $server = new PDO('mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';charset=utf8mb4', DB_USER, DB_PASS, db_options());
} catch (PDOException $ex) {
    install_page('Setup', '<h1>Cannot reach MySQL</h1><p>Make sure WAMP is running and its tray icon is green. '
        . 'Then check <b>DB_HOST</b>, <b>DB_PORT</b>, <b>DB_USER</b> and <b>DB_PASS</b> in <b>includes/config.php</b>. '
        . 'WAMP\'s MariaDB usually uses port 3307 and MySQL uses 3306.</p><p class="muted small">' . e($ex->getMessage()) . '</p>');
}

// Already installed?
$dbExists = (bool)$server->query("SHOW DATABASES LIKE " . $server->quote(DB_NAME))->fetch();
if ($dbExists) {
    $server->exec('USE `' . str_replace('`', '', DB_NAME) . '`');
    $hasUsers = (bool)$server->query("SHOW TABLES LIKE 'users'")->fetch();
    if ($hasUsers && (int)$server->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn() > 0) {
        install_page('Already set up', '<h1>Already set up</h1><p>The database <b>' . e(DB_NAME) . '</b> already has an admin account, so setup will not run again.</p>'
            . '<p>For safety, delete or rename <b>install.php</b> now.</p><p><a class="btn btn-primary" href="login.php">Go to sign in</a></p>');
    }
}

$errors = [];
$form = ['full_name' => 'Administrator', 'username' => 'admin'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $form['full_name'] = str_cut(post('full_name'), 100);
    $form['username']  = strtolower(post('username'));
    $pass  = $_POST['password'] ?? '';
    $pass2 = $_POST['password2'] ?? '';

    if ($form['full_name'] === '') {
        $errors[] = 'Enter the admin\'s full name.';
    }
    if (!preg_match('/^[a-z0-9._-]{3,50}$/', $form['username'])) {
        $errors[] = 'Username must be 3 to 50 characters: letters, numbers, dot, dash or underscore.';
    }
    if (!is_string($pass) || strlen($pass) < 8) {
        $errors[] = 'Password must be at least 8 characters.';
    } elseif ($pass !== $pass2) {
        $errors[] = 'The two passwords do not match.';
    }

    if (!$errors) {
        try {
            $name = str_replace('`', '', DB_NAME);
            $server->exec("CREATE DATABASE IF NOT EXISTS `$name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $server->exec("USE `$name`");
            foreach (schema_sql() as $sql) {
                $server->exec($sql);
            }

            // Starter device types (only if none exist yet)
            if ((int)$server->query('SELECT COUNT(*) FROM device_types')->fetchColumn() === 0) {
                $insType  = $server->prepare('INSERT INTO device_types (name, prefix, icon, sort_order) VALUES (?,?,?,?)');
                $insField = $server->prepare('INSERT INTO type_fields (type_id, label, field_type, options, placeholder, show_in_list, sort_order)
                                              VALUES (?,?,?,?,?,?,?)');
                foreach (starter_types() as $i => $type) {
                    [$tName, $prefix, $icon, $fields] = $type;
                    $insType->execute([$tName, $prefix, $icon, ($i + 1) * 10]);
                    $typeId = (int)$server->lastInsertId();
                    foreach ($fields as $j => $f) {
                        $insField->execute([$typeId, $f[0], $f[1], $f[2] !== '' ? $f[2] : null, $f[3] !== '' ? $f[3] : null, $f[4], ($j + 1) * 10]);
                    }
                }
            }

            $st = $server->prepare('INSERT INTO users (username, full_name, password_hash, role, created_at) VALUES (?,?,?,?,?)');
            $st->execute([$form['username'], $form['full_name'], password_hash($pass, PASSWORD_DEFAULT), 'admin', now()]);

            install_page('Setup complete', '<h1>Setup complete</h1>'
                . '<p>The database <b>' . e(DB_NAME) . '</b> is ready with ' . count(starter_types()) . ' device types, and the admin account <b>' . e($form['username']) . '</b> has been created.</p>'
                . '<div class="notice notice-warning">Delete or rename <b>install.php</b> now so nobody can run it again.</div>'
                . '<p><a class="btn btn-primary" href="login.php">Go to sign in</a></p>');
        } catch (PDOException $ex) {
            $errors[] = 'MySQL error: ' . $ex->getMessage();
        }
    }
}

ob_start(); ?>
<h1>Set up the database</h1>
<p class="muted">This creates the database <b><?= e(DB_NAME) ?></b> on <?= e(DB_HOST) ?>:<?= e(DB_PORT) ?>, adds starter device types (Computer, Laptop, NAS, switches, routers, printers, NVR, CCTV, biometric and more) and your admin account.</p>
<?php if ($errors): ?><div class="notice notice-error"><?= implode('<br>', array_map('e', $errors)) ?></div><?php endif; ?>
<form method="post" class="stack" autocomplete="off">
  <?= csrf_field() ?>
  <label class="field"><span>Admin full name</span><input name="full_name" value="<?= e($form['full_name']) ?>" required maxlength="100"></label>
  <label class="field"><span>Admin username</span><input name="username" value="<?= e($form['username']) ?>" required maxlength="50"></label>
  <label class="field"><span>Password <small class="muted">(at least 8 characters)</small></span><input type="password" name="password" required minlength="8" autocomplete="new-password"></label>
  <label class="field"><span>Type the password again</span><input type="password" name="password2" required minlength="8" autocomplete="new-password"></label>
  <button class="btn btn-primary btn-block" type="submit">Create database and admin</button>
</form>
<?php install_page('Setup', ob_get_clean());
