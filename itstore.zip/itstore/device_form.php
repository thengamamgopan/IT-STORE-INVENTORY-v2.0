<?php
/* Add equipment (step 1: pick a type, step 2: fill in the form) and edit equipment */
require __DIR__ . '/includes/init.php';
require_editor();
$pdo = db();

$id     = (int)get('id');
$copyId = (int)get('copy');
$typeId = (int)get('type');
$device = null;
$src    = null;

if ($id) {
    $device = load_device($id);
    if (!$device) {
        flash('error', 'That item is not in the register any more.');
        redirect('devices.php');
    }
    $typeId = (int)$device['type_id'];
} elseif ($copyId) {
    $src = load_device($copyId);
    $typeId = $src ? (int)$src['type_id'] : $typeId;
}

/* ---------- Step 1: choose what is being added ---------- */
if (!$typeId) {
    $types = get_types(true);
    $pageTitle = 'Add equipment';
    $activeNav = 'add';
    require __DIR__ . '/includes/header.php'; ?>
    <div class="page-head"><div><h1>Add equipment</h1><p class="muted">What are you adding? The form will ask for the details that type of equipment needs.</p></div></div>
    <div class="type-picker">
      <?php foreach ($types as $t): ?>
        <a class="type-tile" href="device_form.php?type=<?= (int)$t['id'] ?>">
          <?= icon($t['icon'], 30) ?>
          <b><?= e($t['name']) ?></b>
          <small><?= (int)$t['item_count'] ?> in register</small>
        </a>
      <?php endforeach; ?>
    </div>
    <?php if (is_admin()): ?><p class="muted small">Missing a type? Add it in <a href="types.php">Device types &amp; fields</a>.</p><?php endif;
    require __DIR__ . '/includes/footer.php';
    exit;
}

/* ---------- Step 2: the form ---------- */
$type = get_type($typeId);
if (!$type || (!$device && !(int)$type['is_active'])) {
    flash('error', 'That device type is not available. Pick another one.');
    redirect('device_form.php');
}
$fields = get_type_fields($typeId);
$fieldById = [];
foreach ($fields as $fl) {
    $fieldById[(int)$fl['id']] = $fl;
}

$coreKeys = ['asset_tag', 'make', 'model', 'serial_no', 'section', 'location', 'grant_name', 'status', 'remarks'];
$core = array_fill_keys($coreKeys, '');
$core['status'] = STATUS_OPTIONS[0];
$values = [];
$extras = [];
$oldCore = $oldValues = $oldExtras = [];

if ($device) {
    foreach ($coreKeys as $k) {
        $core[$k] = (string)$device[$k];
    }
    $values = load_device_values($id);
    $extras = load_device_extras($id);
    [$oldCore, $oldValues, $oldExtras] = [$core, $values, $extras];
} elseif ($src) {
    // "Add another like this": copy the specs, but not the things that are unique to one item
    foreach ($coreKeys as $k) {
        $core[$k] = (string)$src[$k];
    }
    $core['serial_no'] = '';
    $core['asset_tag'] = next_asset_tag($type['prefix']);
    foreach (load_device_values($copyId) as $fid => $v) {
        if (isset($fieldById[$fid]) && !in_array($fieldById[$fid]['field_type'], ['ip', 'mac', 'person'], true)) {
            $values[$fid] = $v;
        }
    }
    $extras = load_device_extras($copyId);
} else {
    $core['asset_tag'] = next_asset_tag($type['prefix']);
}

$errors = [];
$fieldErrors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    $limits = ['asset_tag' => 50, 'make' => 100, 'model' => 100, 'serial_no' => 100, 'section' => 100, 'location' => 100, 'grant_name' => 100];
    foreach ($limits as $k => $len) {
        $core[$k] = str_cut(post($k), $len);
    }
    $core['remarks'] = str_cut(post('remarks'), 5000);
    $core['status']  = post('status');

    if ($core['asset_tag'] === '') {
        $fieldErrors['asset_tag'] = 'Enter an asset tag.';
    } else {
        $chk = $pdo->prepare('SELECT id FROM devices WHERE asset_tag = ? AND id <> ?');
        $chk->execute([$core['asset_tag'], $id]);
        if ($other = $chk->fetchColumn()) {
            $fieldErrors['asset_tag'] = 'This tag is already used by <a href="device_view.php?id=' . (int)$other . '" target="_blank">another item</a>. Use a different one.';
        }
    }
    $statusOk = in_array($core['status'], STATUS_OPTIONS, true) || ($device && $core['status'] === $oldCore['status']);
    if (!$statusOk) {
        $fieldErrors['status'] = 'Pick a status.';
    }

    $posted = isset($_POST['f']) && is_array($_POST['f']) ? $_POST['f'] : [];
    $values = [];
    foreach ($fields as $fl) {
        $fid = (int)$fl['id'];
        $v = isset($posted[$fid]) && is_string($posted[$fid]) ? $posted[$fid] : '';
        $v = str_cut($v, $fl['field_type'] === 'textarea' ? 5000 : 255);
        $key = 'f' . $fid;
        if ($v === '') {
            if ((int)$fl['is_required'] === 1) {
                $fieldErrors[$key] = 'This is required.';
            }
        } else {
            switch ($fl['field_type']) {
                case 'ip':
                    if (!filter_var($v, FILTER_VALIDATE_IP)) {
                        $fieldErrors[$key] = 'Enter a valid IP address, like 192.168.1.20.';
                    }
                    break;
                case 'mac':
                    $m = normalize_mac($v);
                    if ($m === null) {
                        $fieldErrors[$key] = 'Enter a valid MAC address, like 00:1A:2B:3C:4D:5E.';
                    } else {
                        $v = $m;
                    }
                    break;
                case 'number':
                    if (!is_numeric($v)) {
                        $fieldErrors[$key] = 'Enter numbers only.';
                    }
                    break;
                case 'date':
                    $d = DateTime::createFromFormat('Y-m-d', $v);
                    if (!$d || $d->format('Y-m-d') !== $v) {
                        $fieldErrors[$key] = 'Enter a date.';
                    }
                    break;
                case 'select':
                    if (!in_array($v, field_options($fl['options']), true) && ($oldValues[$fid] ?? null) !== $v) {
                        $fieldErrors[$key] = 'Pick one of the choices.';
                    }
                    break;
            }
        }
        $values[$fid] = $v;
    }

    $labels = isset($_POST['extra_label']) && is_array($_POST['extra_label']) ? $_POST['extra_label'] : [];
    $vals   = isset($_POST['extra_value']) && is_array($_POST['extra_value']) ? $_POST['extra_value'] : [];
    $extras = [];
    foreach ($labels as $i => $lab) {
        $lab = str_cut(is_string($lab) ? $lab : '', 100);
        $val = isset($vals[$i]) && is_string($vals[$i]) ? str_cut($vals[$i], 2000) : '';
        if ($lab === '' && $val === '') {
            continue;
        }
        if ($lab === '') {
            $errors['extra'] = 'Each additional detail needs a name on the left, for example "Warranty until".';
        }
        $extras[] = ['label' => $lab, 'value' => $val];
    }

    if (!$errors && !$fieldErrors) {
        $uid = (int)current_user()['id'];
        $ts = now();

        // What changed (for the activity log)
        $changes = [];
        if ($device) {
            $coreLabels = ['asset_tag' => 'Asset tag', 'make' => 'Make', 'model' => 'Model', 'serial_no' => 'Serial no.',
                'section' => 'Section', 'location' => 'Location', 'grant_name' => 'Grant', 'status' => 'Status'];
            foreach ($coreLabels as $k => $lab) {
                if ($oldCore[$k] !== $core[$k]) {
                    $changes[] = "$lab: " . ($oldCore[$k] === '' ? '(blank)' : $oldCore[$k]) . ' → ' . ($core[$k] === '' ? '(blank)' : $core[$k]);
                }
            }
            if ($oldCore['remarks'] !== $core['remarks']) {
                $changes[] = 'Remarks updated';
            }
            foreach ($fields as $fl) {
                $fid = (int)$fl['id'];
                $o = $oldValues[$fid] ?? '';
                $n = $values[$fid] ?? '';
                if ($o !== $n) {
                    $changes[] = $fl['label'] . ': ' . ($o === '' ? '(blank)' : $o) . ' → ' . ($n === '' ? '(blank)' : $n);
                }
            }
            $norm = function ($rows) { return array_map(function ($r) { return [$r['label'], $r['value']]; }, $rows); };
            if ($norm($oldExtras) !== $norm($extras)) {
                $changes[] = 'Additional details updated';
            }
            if (!$changes) {
                flash('info', 'Nothing was changed on ' . e($core['asset_tag']) . '.');
                redirect('device_view.php?id=' . $id);
            }
        }

        try {
            $pdo->beginTransaction();
            if ($device) {
                $pdo->prepare('UPDATE devices SET asset_tag=?, make=?, model=?, serial_no=?, section=?, location=?, grant_name=?, status=?, remarks=?,
                                updated_by=?, updated_at=? WHERE id=?')
                    ->execute([$core['asset_tag'], $core['make'], $core['model'], $core['serial_no'], $core['section'], $core['location'],
                        $core['grant_name'], $core['status'], $core['remarks'], $uid, $ts, $id]);
            } else {
                $pdo->prepare('INSERT INTO devices (asset_tag, type_id, make, model, serial_no, section, location, grant_name, status, remarks,
                                created_by, updated_by, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
                    ->execute([$core['asset_tag'], $typeId, $core['make'], $core['model'], $core['serial_no'], $core['section'], $core['location'],
                        $core['grant_name'], $core['status'], $core['remarks'], $uid, $uid, $ts, $ts]);
                $id = (int)$pdo->lastInsertId();
            }

            $pdo->prepare('DELETE FROM device_values WHERE device_id = ?')->execute([$id]);
            $ins = $pdo->prepare('INSERT INTO device_values (device_id, field_id, value) VALUES (?,?,?)');
            foreach ($values as $fid => $v) {
                if ($v !== '') {
                    $ins->execute([$id, $fid, $v]);
                }
            }
            $pdo->prepare('DELETE FROM device_extras WHERE device_id = ?')->execute([$id]);
            $ins = $pdo->prepare('INSERT INTO device_extras (device_id, label, value, sort_order) VALUES (?,?,?,?)');
            foreach ($extras as $i => $x) {
                $ins->execute([$id, $x['label'], $x['value'], $i]);
            }

            if ($device) {
                log_activity('updated', $id, $core['asset_tag'], implode("\n", $changes));
            } else {
                $summary = trim($type['name'] . ': ' . $core['make'] . ' ' . $core['model']) . ($core['serial_no'] !== '' ? ', S/N ' . $core['serial_no'] : '');
                log_activity('added', $id, $core['asset_tag'], $summary);
            }
            $pdo->commit();
        } catch (PDOException $ex) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            if (isset($ex->errorInfo[1]) && (int)$ex->errorInfo[1] === 1062) {
                $fieldErrors['asset_tag'] = 'Someone just saved an item with this tag. A new number has been suggested.';
                $core['asset_tag'] = next_asset_tag($type['prefix']);
                if (!$device) {
                    $id = 0;
                }
            } else {
                throw $ex;
            }
        }

        if (!$fieldErrors) {
            // Friendly warnings about possible duplicates (the item is still saved)
            $warn = [];
            $linkTags = function (array $rows) {
                return implode(', ', array_map(function ($r) { return '<a href="device_view.php?id=' . (int)$r['id'] . '">' . e($r['asset_tag']) . '</a>'; }, $rows));
            };
            if ($core['serial_no'] !== '') {
                $q = $pdo->prepare('SELECT id, asset_tag FROM devices WHERE serial_no = ? AND id <> ? LIMIT 5');
                $q->execute([$core['serial_no'], $id]);
                if ($dup = $q->fetchAll()) {
                    $warn[] = 'Serial no. <b>' . e($core['serial_no']) . '</b> is also on ' . $linkTags($dup) . '.';
                }
            }
            $q = $pdo->prepare("SELECT d.id, d.asset_tag FROM device_values v JOIN type_fields tf ON tf.id = v.field_id JOIN devices d ON d.id = v.device_id
                                WHERE tf.field_type = ? AND v.value = ? AND v.device_id <> ? LIMIT 5");
            foreach ($fields as $fl) {
                $fid = (int)$fl['id'];
                if (in_array($fl['field_type'], ['ip', 'mac'], true) && ($values[$fid] ?? '') !== '') {
                    $q->execute([$fl['field_type'], $values[$fid], $id]);
                    if ($dup = $q->fetchAll()) {
                        $warn[] = e($fl['label']) . ' <b>' . e($values[$fid]) . '</b> is also on ' . $linkTags($dup) . '.';
                    }
                }
            }

            flash('success', ($device ? 'Saved changes to ' : 'Added ') . '<b>' . e($core['asset_tag']) . '</b>.');
            if ($warn) {
                flash('warning', 'Please check: ' . implode(' ', $warn));
            }
            $after = post('after');
            if (!$device && $after === 'next') {
                redirect('device_form.php?type=' . $typeId);
            }
            if (!$device && $after === 'copy') {
                redirect('device_form.php?copy=' . $id);
            }
            redirect('device_view.php?id=' . $id);
        }
    }
}

/* ---------- Suggestions for the inputs ---------- */
$suggest = [];
$suggestIds = [];
foreach ($fields as $fl) {
    if (in_array($fl['field_type'], ['text', 'person'], true)) {
        $suggest[(int)$fl['id']] = $fl['field_type'] === 'text' ? field_options($fl['options']) : [];
        if ($fl['field_type'] === 'text') {
            $suggestIds[] = (int)$fl['id'];
        }
    }
}
if ($suggestIds) {
    $in = implode(',', array_fill(0, count($suggestIds), '?'));
    $q = $pdo->prepare("SELECT field_id, value FROM device_values WHERE field_id IN ($in) GROUP BY field_id, value ORDER BY value");
    $q->execute($suggestIds);
    foreach ($q->fetchAll() as $r) {
        $fid = (int)$r['field_id'];
        if (count($suggest[$fid]) < 200 && !in_array($r['value'], $suggest[$fid], true)) {
            $suggest[$fid][] = $r['value'];
        }
    }
}
$people = $pdo->query("SELECT DISTINCT v.value FROM device_values v JOIN type_fields tf ON tf.id = v.field_id
                       WHERE tf.field_type = 'person' ORDER BY v.value LIMIT 500")->fetchAll(PDO::FETCH_COLUMN);
$extraLabels = array_values(array_unique(array_merge(
    ['Purchase date', 'Warranty until', 'Supplier / vendor', 'Invoice / PO no.', 'Price', 'Issued on', 'Previous user', 'Keyboard', 'Mouse', 'Antivirus', 'Office version', 'Domain / workgroup', 'Computer name'],
    $pdo->query('SELECT DISTINCT label FROM device_extras ORDER BY label LIMIT 200')->fetchAll(PDO::FETCH_COLUMN)
)));

function field_input(array $fl, string $value, ?string $error, array $suggest, array $people): string
{
    $fid = (int)$fl['id'];
    $name = 'f[' . $fid . ']';
    $idAttr = 'f' . $fid;
    $req = (int)$fl['is_required'] === 1 ? ' required' : '';
    $ph = $fl['placeholder'] ? ' placeholder="' . e($fl['placeholder']) . '"' : '';
    $inv = $error ? ' aria-invalid="true" aria-describedby="' . $idAttr . '-err"' : '';
    $common = ' id="' . $idAttr . '" name="' . e($name) . '"' . $req . $ph . $inv;
    $kind = $fl['field_type'];
    $wide = $kind === 'textarea' ? ' span-2' : '';

    switch ($kind) {
        case 'textarea':
            $input = '<textarea' . $common . ' rows="2">' . e($value) . '</textarea>';
            break;
        case 'number':
            $input = '<input type="number" step="any"' . $common . ' value="' . e($value) . '">';
            break;
        case 'date':
            $input = '<input type="date"' . $common . ' value="' . e($value) . '">';
            break;
        case 'select':
            $opts = field_options($fl['options']);
            if ($value !== '' && !in_array($value, $opts, true)) {
                $opts[] = $value;
            }
            $input = '<select' . $common . '><option value="">Not set</option>';
            foreach ($opts as $o) {
                $input .= '<option' . ($o === $value ? ' selected' : '') . '>' . e($o) . '</option>';
            }
            $input .= '</select>';
            break;
        case 'ip':
            $input = '<input type="text" class="data" inputmode="decimal" autocomplete="off" spellcheck="false"' . $common . ' value="' . e($value) . '">';
            break;
        case 'mac':
            $input = '<input type="text" class="data" autocomplete="off" spellcheck="false" maxlength="17"' . $common . ' value="' . e($value) . '">';
            break;
        case 'person':
            $input = '<input type="text" list="dl-people" autocomplete="off"' . $common . ' value="' . e($value) . '">';
            break;
        default:
            $dl = !empty($suggest[$fid]) ? ' list="dl-' . $idAttr . '"' : '';
            $input = '<input type="text" autocomplete="off"' . $dl . $common . ' value="' . e($value) . '">'
                   . (!empty($suggest[$fid]) ? datalist('dl-' . $idAttr, $suggest[$fid]) : '');
    }
    $label = e($fl['label']) . ((int)$fl['is_required'] === 1 ? ' <i class="req" title="Required">*</i>' : '');
    return '<div class="field' . $wide . ($error ? ' has-error' : '') . '"><label for="' . $idAttr . '">' . $label . '</label>' . $input
         . ($error ? '<span class="err" id="' . $idAttr . '-err">' . $error . '</span>' : '') . '</div>';
}

function core_input(string $key, string $label, string $value, array $fieldErrors, string $extra = '', ?string $hint = null): string
{
    $err = $fieldErrors[$key] ?? null;
    $inv = $err ? ' aria-invalid="true"' : '';
    return '<div class="field' . ($err ? ' has-error' : '') . '"><label for="c-' . $key . '">' . $label . '</label>'
         . '<input type="text" id="c-' . $key . '" name="' . $key . '" value="' . e($value) . '"' . $extra . $inv . '>'
         . ($hint ? '<span class="hint">' . $hint . '</span>' : '')
         . ($err ? '<span class="err">' . $err . '</span>' : '') . '</div>';
}

$isEdit = (bool)$device;
$pageTitle = $isEdit ? 'Edit ' . $device['asset_tag'] : 'Add ' . $type['name'];
$activeNav = $isEdit ? 'devices' : 'add';
require __DIR__ . '/includes/header.php';
$errCount = count($errors) + count($fieldErrors);
?>
<div class="page-head">
  <div>
    <h1><?= icon($type['icon'], 26) ?> <?= $isEdit ? 'Edit ' . e($type['name']) . ' ' . asset_tag($device['asset_tag']) : 'Add ' . e($type['name']) ?></h1>
    <p class="muted"><?php if ($isEdit): ?>Change what you need and save.<?php elseif ($src): ?>Copied from <?= e($src['asset_tag']) ?>. Serial number, IP, MAC and user were left blank.<?php else: ?>Fill in what you know. Only the asset tag is needed to save.<?php endif; ?>
    <?php if (!$isEdit): ?> <a href="device_form.php">Pick a different type</a><?php endif; ?></p>
  </div>
</div>

<?php if ($errCount): ?><div class="notice notice-error" role="alert">Fix the <?= $errCount === 1 ? 'highlighted field' : $errCount . ' highlighted fields' ?> and save again.<?= isset($errors['extra']) ? '<br>' . e($errors['extra']) : '' ?></div><?php endif; ?>

<form method="post" class="device-form" novalidate>
  <?= csrf_field() ?>

  <section class="panel form-panel">
    <h2>Identification</h2>
    <div class="form-grid">
      <?= core_input('asset_tag', 'Asset tag <i class="req" title="Required">*</i>', $core['asset_tag'], $fieldErrors, ' class="tag-input" maxlength="50" required', $isEdit ? null : 'Next free number. You can type your own stock number instead.') ?>
      <?= core_input('make', 'Make', $core['make'], $fieldErrors, ' list="dl-make" maxlength="100" placeholder="e.g. Dell, HP, Cisco"') ?>
      <?= core_input('model', 'Model', $core['model'], $fieldErrors, ' list="dl-model" maxlength="100"') ?>
      <?= core_input('serial_no', 'Serial number', $core['serial_no'], $fieldErrors, ' class="data" maxlength="100" spellcheck="false" autocomplete="off"') ?>
    </div>
  </section>

  <?php if ($fields): ?>
  <section class="panel form-panel">
    <h2><?= e($type['name']) ?> details</h2>
    <div class="form-grid">
      <?php foreach ($fields as $fl) {
          $fid = (int)$fl['id'];
          echo field_input($fl, (string)($values[$fid] ?? ''), $fieldErrors['f' . $fid] ?? null, $suggest, $people);
      } ?>
    </div>
  </section>
  <?php endif; ?>

  <section class="panel form-panel">
    <h2>Placement and status</h2>
    <div class="form-grid">
      <?= core_input('section', 'Section', $core['section'], $fieldErrors, ' list="dl-section" maxlength="100" placeholder="e.g. Accounts"') ?>
      <?= core_input('location', 'Location', $core['location'], $fieldErrors, ' list="dl-location" maxlength="100" placeholder="e.g. Block A, room 12"') ?>
      <?= core_input('grant_name', 'Grant', $core['grant_name'], $fieldErrors, ' list="dl-grant" maxlength="100"') ?>
      <div class="field<?= isset($fieldErrors['status']) ? ' has-error' : '' ?>">
        <span class="label" id="status-label">Status</span>
        <div class="seg" role="radiogroup" aria-labelledby="status-label">
          <?php $opts = STATUS_OPTIONS; if (!in_array($core['status'], $opts, true) && $core['status'] !== '') { $opts[] = $core['status']; }
          foreach ($opts as $s): $cls = strcasecmp($s, 'Unserviceable') === 0 ? 'seg-bad' : (strcasecmp($s, 'Serviceable') === 0 ? 'seg-ok' : ''); ?>
            <label class="<?= $cls ?>"><input type="radio" name="status" value="<?= e($s) ?>" <?= $core['status'] === $s ? 'checked' : '' ?>><span><?= e($s) ?></span></label>
          <?php endforeach; ?>
        </div>
        <?php if (isset($fieldErrors['status'])): ?><span class="err"><?= $fieldErrors['status'] ?></span><?php endif; ?>
      </div>
    </div>
  </section>

  <section class="panel form-panel">
    <h2>Additional details</h2>
    <p class="muted small">Anything else worth recording for this item, such as warranty date, supplier or invoice number.</p>
    <div class="extras" id="extras">
      <?php foreach ($extras as $x): ?>
        <div class="extra-row">
          <input type="text" name="extra_label[]" value="<?= e($x['label']) ?>" list="dl-extra" placeholder="Detail name, e.g. Warranty until" aria-label="Detail name"<?= $x['label'] === '' ? ' aria-invalid="true"' : '' ?>>
          <input type="text" name="extra_value[]" value="<?= e($x['value']) ?>" placeholder="Value" aria-label="Value">
          <button type="button" class="icon-btn" data-remove-row title="Remove this detail" aria-label="Remove this detail"><?= icon('x', 16) ?></button>
        </div>
      <?php endforeach; ?>
    </div>
    <template id="extra-template">
      <div class="extra-row">
        <input type="text" name="extra_label[]" list="dl-extra" placeholder="Detail name, e.g. Warranty until" aria-label="Detail name">
        <input type="text" name="extra_value[]" placeholder="Value" aria-label="Value">
        <button type="button" class="icon-btn" data-remove-row title="Remove this detail" aria-label="Remove this detail"><?= icon('x', 16) ?></button>
      </div>
    </template>
    <button type="button" class="btn btn-dashed" data-add-row><?= icon('plus', 16) ?> Add more detail</button>

    <div class="field remarks">
      <label for="c-remarks">Remarks</label>
      <textarea id="c-remarks" name="remarks" rows="3" placeholder="Notes, faults, repair history…"><?= e($core['remarks']) ?></textarea>
    </div>
  </section>

  <div class="form-bar">
    <?php if ($isEdit): ?>
      <button class="btn btn-primary" type="submit">Save changes</button>
      <a class="btn btn-ghost" href="device_view.php?id=<?= (int)$device['id'] ?>">Cancel</a>
    <?php else: ?>
      <button class="btn btn-primary" type="submit" name="after" value="view">Save equipment</button>
      <button class="btn" type="submit" name="after" value="next">Save and add another</button>
      <button class="btn" type="submit" name="after" value="copy" title="Opens a new form with the same make, model and specs">Save and add a similar one</button>
      <a class="btn btn-ghost" href="devices.php">Cancel</a>
    <?php endif; ?>
  </div>

  <?= datalist('dl-make', distinct_values('make')) ?>
  <?= datalist('dl-model', distinct_values('model', $typeId)) ?>
  <?= datalist('dl-section', distinct_values('section')) ?>
  <?= datalist('dl-location', distinct_values('location')) ?>
  <?= datalist('dl-grant', distinct_values('grant_name')) ?>
  <?= datalist('dl-people', $people) ?>
  <?= datalist('dl-extra', $extraLabels) ?>
</form>
<?php require __DIR__ . '/includes/footer.php';
