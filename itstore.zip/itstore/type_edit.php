<?php
require __DIR__ . '/includes/init.php';
require_admin();
$pdo = db();

$id = (int)get('id');
$type = get_type($id);
if (!$type) {
    flash('error', 'That device type does not exist.');
    redirect('types.php');
}
$self = 'type_edit.php?id=' . $id;

$itemCount = (int)$pdo->query('SELECT COUNT(*) FROM devices WHERE type_id = ' . $id)->fetchColumn();
$editFieldId = (int)get('field');
$errors = [];
$fieldForm = ['label' => '', 'field_type' => 'text', 'options' => '', 'placeholder' => '', 'is_required' => 0, 'show_in_list' => 0];
if ($editFieldId) {
    $st = $pdo->prepare('SELECT * FROM type_fields WHERE id = ? AND type_id = ?');
    $st->execute([$editFieldId, $id]);
    if ($row = $st->fetch()) {
        $fieldForm = $row;
        $fieldForm['options'] = (string)$row['options'];
        $fieldForm['placeholder'] = (string)$row['placeholder'];
    } else {
        $editFieldId = 0;
    }
}

function renumber_fields(PDO $pdo, int $typeId): array
{
    $ids = $pdo->query('SELECT id FROM type_fields WHERE type_id = ' . $typeId . ' ORDER BY sort_order, id')->fetchAll(PDO::FETCH_COLUMN);
    $up = $pdo->prepare('UPDATE type_fields SET sort_order = ? WHERE id = ?');
    foreach ($ids as $i => $fid) {
        $up->execute([($i + 1) * 10, $fid]);
    }
    return array_map('intval', $ids);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = post('action');

    if ($action === 'save_type') {
        $name   = str_cut(post('name'), 80);
        $prefix = strtoupper(str_cut(post('prefix'), 10));
        $icon   = in_array(post('icon'), TYPE_ICONS, true) ? post('icon') : $type['icon'];
        $active = post('is_active') === '1' ? 1 : 0;
        if ($name === '') {
            $errors[] = 'Enter a name.';
        }
        if (!preg_match('/^[A-Z0-9]{1,10}$/', $prefix)) {
            $errors[] = 'Tag prefix must be 1 to 10 letters or numbers.';
        }
        $chk = $pdo->prepare('SELECT COUNT(*) FROM device_types WHERE name = ? AND id <> ?');
        $chk->execute([$name, $id]);
        if ($chk->fetchColumn()) {
            $errors[] = 'Another type is already called "' . $name . '".';
        }
        if (!$errors) {
            $pdo->prepare('UPDATE device_types SET name=?, prefix=?, icon=?, is_active=? WHERE id=?')->execute([$name, $prefix, $icon, $active, $id]);
            log_activity('type_changed', null, '', "Updated device type $name");
            flash('success', 'Saved the type settings.');
            redirect($self);
        }
        $type = array_merge($type, ['name' => $name, 'prefix' => $prefix, 'icon' => $icon, 'is_active' => $active]);
    }

    if ($action === 'save_field') {
        $fid = (int)post('field_id');
        $fieldForm = [
            'label'        => str_cut(post('label'), 80),
            'field_type'   => array_key_exists(post('field_type'), FIELD_KINDS) ? post('field_type') : 'text',
            'options'      => implode("\n", field_options(post('options'))),
            'placeholder'  => str_cut(post('placeholder'), 120),
            'is_required'  => post('is_required') === '1' ? 1 : 0,
            'show_in_list' => post('show_in_list') === '1' ? 1 : 0,
        ];
        if ($fieldForm['label'] === '') {
            $errors[] = 'Enter a name for the field.';
        }
        if ($fieldForm['field_type'] === 'select' && !field_options($fieldForm['options'])) {
            $errors[] = 'A drop-down list needs at least one choice. Put each choice on its own line.';
        }
        if (!$errors) {
            $opts = $fieldForm['options'] !== '' ? $fieldForm['options'] : null;
            $ph = $fieldForm['placeholder'] !== '' ? $fieldForm['placeholder'] : null;
            if ($fid) {
                $pdo->prepare('UPDATE type_fields SET label=?, field_type=?, options=?, placeholder=?, is_required=?, show_in_list=? WHERE id=? AND type_id=?')
                    ->execute([$fieldForm['label'], $fieldForm['field_type'], $opts, $ph, $fieldForm['is_required'], $fieldForm['show_in_list'], $fid, $id]);
                log_activity('type_changed', null, '', "Edited field \"{$fieldForm['label']}\" on {$type['name']}");
                flash('success', 'Saved the field <b>' . e($fieldForm['label']) . '</b>.');
            } else {
                $targets = post('apply_all') === '1' ? array_map('intval', $pdo->query('SELECT id FROM device_types')->fetchAll(PDO::FETCH_COLUMN)) : [$id];
                $ins = $pdo->prepare('INSERT INTO type_fields (type_id, label, field_type, options, placeholder, is_required, show_in_list, sort_order)
                                      VALUES (?,?,?,?,?,?,?,?)');
                $has = $pdo->prepare('SELECT COUNT(*) FROM type_fields WHERE type_id = ? AND label = ?');
                $next = $pdo->prepare('SELECT COALESCE(MAX(sort_order), 0) + 10 FROM type_fields WHERE type_id = ?');
                $added = 0;
                foreach ($targets as $tid) {
                    $has->execute([$tid, $fieldForm['label']]);
                    if ($tid !== $id && $has->fetchColumn()) {
                        continue; // that type already has a field with this name
                    }
                    $next->execute([$tid]);
                    $ins->execute([$tid, $fieldForm['label'], $fieldForm['field_type'], $opts, $ph, $fieldForm['is_required'], $fieldForm['show_in_list'], (int)$next->fetchColumn()]);
                    $added++;
                }
                log_activity('type_changed', null, '', "Added field \"{$fieldForm['label']}\" to " . ($added > 1 ? "$added types" : $type['name']));
                flash('success', 'Added the field <b>' . e($fieldForm['label']) . '</b>' . ($added > 1 ? " to $added device types" : '') . '.');
            }
            redirect($self);
        }
        $editFieldId = $fid;
    }

    if ($action === 'delete_field') {
        $fid = (int)post('field_id');
        $st = $pdo->prepare('SELECT label FROM type_fields WHERE id = ? AND type_id = ?');
        $st->execute([$fid, $id]);
        if ($label = $st->fetchColumn()) {
            $pdo->prepare('DELETE FROM type_fields WHERE id = ?')->execute([$fid]);
            log_activity('type_changed', null, '', "Removed field \"$label\" from {$type['name']}");
            flash('success', 'Removed the field <b>' . e($label) . '</b>.');
        }
        redirect($self);
    }

    if ($action === 'move_field') {
        $fid = (int)post('field_id');
        $ids = renumber_fields($pdo, $id);
        $pos = array_search($fid, $ids, true);
        $swap = post('dir') === 'up' ? $pos - 1 : $pos + 1;
        if ($pos !== false && isset($ids[$swap])) {
            $up = $pdo->prepare('UPDATE type_fields SET sort_order = ? WHERE id = ?');
            $up->execute([($swap + 1) * 10, $fid]);
            $up->execute([($pos + 1) * 10, $ids[$swap]]);
        }
        redirect($self . '#fields');
    }

    if ($action === 'delete_type') {
        if ($itemCount > 0) {
            flash('error', 'This type still has ' . $itemCount . ' item(s). Delete or move them first, or hide the type instead.');
            redirect($self);
        }
        $pdo->prepare('DELETE FROM device_types WHERE id = ?')->execute([$id]);
        log_activity('type_changed', null, '', "Deleted device type {$type['name']}");
        flash('success', 'Deleted the type <b>' . e($type['name']) . '</b>.');
        redirect('types.php');
    }
}

$fields = get_type_fields($id);
$valueCounts = [];
foreach ($pdo->query('SELECT v.field_id, COUNT(*) AS n FROM device_values v JOIN type_fields tf ON tf.id = v.field_id WHERE tf.type_id = ' . $id . ' GROUP BY v.field_id') as $r) {
    $valueCounts[(int)$r['field_id']] = (int)$r['n'];
}

$pageTitle = $type['name'] . ' fields';
$activeNav = 'types';
require __DIR__ . '/includes/header.php';
?>
<div class="page-head">
  <div>
    <p class="crumb"><a href="types.php">Device types &amp; fields</a></p>
    <h1><?= icon($type['icon'], 26) ?> <?= e($type['name']) ?></h1>
    <p class="muted"><?= $itemCount ?> item<?= $itemCount === 1 ? '' : 's' ?> in the register. <a href="device_form.php?type=<?= $id ?>">Preview the form</a></p>
  </div>
</div>
<?php if ($errors): ?><div class="notice notice-error"><?= implode('<br>', array_map('e', $errors)) ?></div><?php endif; ?>

<div class="split">
  <div>
    <section class="panel" id="fields">
      <div class="panel-head"><h2>Fields on the form</h2></div>
      <p class="muted small pad">Every item already has asset tag, make, model, serial number, section, location, grant, status, remarks and the "Add more detail" rows. The fields below are asked only for <b><?= e($type['name']) ?></b>.</p>
      <?php if ($fields): ?>
      <table class="table fields-table">
        <thead><tr><th class="order"><span class="sr">Order</span></th><th>Field</th><th>Kind</th><th>Required</th><th>Column in list</th><th class="row-actions"><span class="sr">Actions</span></th></tr></thead>
        <tbody>
        <?php foreach ($fields as $i => $fl): $fid = (int)$fl['id']; ?>
          <tr class="<?= $fid === $editFieldId ? 'is-editing' : '' ?>">
            <td class="order">
              <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="move_field"><input type="hidden" name="field_id" value="<?= $fid ?>">
                <button class="icon-btn" name="dir" value="up" <?= $i === 0 ? 'disabled' : '' ?> aria-label="Move <?= e($fl['label']) ?> up"><?= icon('up', 15) ?></button><button class="icon-btn" name="dir" value="down" <?= $i === count($fields) - 1 ? 'disabled' : '' ?> aria-label="Move <?= e($fl['label']) ?> down"><?= icon('down', 15) ?></button>
              </form>
            </td>
            <td><b><?= e($fl['label']) ?></b><?php if ($fl['field_type'] === 'select' || ($fl['field_type'] === 'text' && $fl['options'])): ?><br><small class="muted"><?= e(implode(', ', array_slice(field_options($fl['options']), 0, 6))) ?><?= count(field_options($fl['options'])) > 6 ? '…' : '' ?></small><?php endif; ?></td>
            <td class="nowrap"><?= e(preg_replace('/ \(.*\)$/', '', FIELD_KINDS[$fl['field_type']] ?? $fl['field_type'])) ?></td>
            <td><?= $fl['is_required'] ? 'Yes' : '<span class="muted">No</span>' ?></td>
            <td><?= $fl['show_in_list'] ? 'Yes' : '<span class="muted">No</span>' ?></td>
            <td class="row-actions nowrap">
              <a class="icon-btn" href="<?= e($self) ?>&amp;field=<?= $fid ?>#field-form" aria-label="Edit <?= e($fl['label']) ?>"><?= icon('edit', 16) ?></a>
              <form method="post" data-confirm="Remove the field &quot;<?= e($fl['label']) ?>&quot;?<?= !empty($valueCounts[$fid]) ? ' Its saved values on ' . $valueCounts[$fid] . ' item(s) will be deleted too.' : '' ?>">
                <?= csrf_field() ?><input type="hidden" name="action" value="delete_field"><input type="hidden" name="field_id" value="<?= $fid ?>">
                <button class="icon-btn danger" aria-label="Remove <?= e($fl['label']) ?>"><?= icon('trash', 16) ?></button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <?php else: ?>
        <p class="pad">No extra fields yet. Add the first one with the form on the right.</p>
      <?php endif; ?>
    </section>
  </div>

  <div class="stack-panels">
    <section class="panel form-panel" id="field-form">
      <h2><?= $editFieldId ? 'Edit field' : 'Add a field' ?></h2>
      <form method="post" class="stack">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="save_field">
        <input type="hidden" name="field_id" value="<?= $editFieldId ?>">
        <label class="field"><span>Field name</span><input name="label" value="<?= e($fieldForm['label']) ?>" maxlength="80" required placeholder="e.g. Warranty until"></label>
        <label class="field"><span>Kind</span>
          <select name="field_type" data-kind>
            <?php foreach (FIELD_KINDS as $k => $lab): ?><option value="<?= $k ?>" <?= $fieldForm['field_type'] === $k ? 'selected' : '' ?>><?= e($lab) ?></option><?php endforeach; ?>
          </select>
          <small class="hint">IP and MAC addresses are checked for mistakes. "Person" fields share one list of names across all types.</small></label>
        <label class="field" data-options><span data-options-label>Choices</span>
          <textarea name="options" rows="4" placeholder="One per line"><?= e($fieldForm['options']) ?></textarea>
          <small class="hint" data-options-hint>One per line.</small></label>
        <label class="field"><span>Example text in the box <small class="muted">(optional)</small></span><input name="placeholder" value="<?= e($fieldForm['placeholder']) ?>" maxlength="120" placeholder="e.g. 16 GB DDR4"></label>
        <label class="check"><input type="checkbox" name="is_required" value="1" <?= $fieldForm['is_required'] ? 'checked' : '' ?>> Must be filled in</label>
        <label class="check"><input type="checkbox" name="show_in_list" value="1" <?= $fieldForm['show_in_list'] ? 'checked' : '' ?>> Show as a column in the <?= e($type['name']) ?> list</label>
        <?php if (!$editFieldId): ?>
          <label class="check"><input type="checkbox" name="apply_all" value="1"> Add this field to every device type</label>
        <?php endif; ?>
        <div class="row-btns">
          <button class="btn btn-primary" type="submit"><?= $editFieldId ? 'Save field' : 'Add field' ?></button>
          <?php if ($editFieldId): ?><a class="btn btn-ghost" href="<?= e($self) ?>">Cancel</a><?php endif; ?>
        </div>
      </form>
    </section>

    <section class="panel form-panel">
      <h2>Type settings</h2>
      <form method="post" class="stack">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="save_type">
        <label class="field"><span>Name</span><input name="name" value="<?= e($type['name']) ?>" maxlength="80" required></label>
        <label class="field"><span>Tag prefix</span><input name="prefix" value="<?= e($type['prefix']) ?>" maxlength="10" required class="tag-input" style="text-transform:uppercase">
          <small class="hint">Used for new items only. Existing tags stay as they are.</small></label>
        <fieldset class="field"><legend>Icon</legend>
          <div class="icon-pick">
            <?php foreach (TYPE_ICONS as $ic): ?>
              <label title="<?= e($ic) ?>"><input type="radio" name="icon" value="<?= e($ic) ?>" <?= $type['icon'] === $ic ? 'checked' : '' ?>><span><?= icon($ic, 22) ?></span></label>
            <?php endforeach; ?>
          </div>
        </fieldset>
        <label class="check"><input type="checkbox" name="is_active" value="1" <?= $type['is_active'] ? 'checked' : '' ?>> Show this type when adding equipment</label>
        <button class="btn btn-primary" type="submit">Save type settings</button>
      </form>
      <?php if ($itemCount === 0): ?>
        <form method="post" class="danger-zone" data-confirm="Delete the type &quot;<?= e($type['name']) ?>&quot; and its fields?">
          <?= csrf_field() ?><input type="hidden" name="action" value="delete_type">
          <button class="btn btn-danger" type="submit"><?= icon('trash', 16) ?> Delete this type</button>
        </form>
      <?php else: ?>
        <p class="muted small">To stop using this type without losing its <?= $itemCount ?> item<?= $itemCount === 1 ? '' : 's' ?>, untick "Show this type when adding equipment".</p>
      <?php endif; ?>
    </section>
  </div>
</div>
<?php require __DIR__ . '/includes/footer.php';
