<?php
require __DIR__ . '/includes/init.php';
require_admin();
$pdo = db();

$errors = [];
$form = ['name' => '', 'prefix' => '', 'icon' => 'box'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $form['name']   = str_cut(post('name'), 80);
    $form['prefix'] = strtoupper(str_cut(post('prefix'), 10));
    $form['icon']   = in_array(post('icon'), TYPE_ICONS, true) ? post('icon') : 'box';

    if ($form['name'] === '') {
        $errors[] = 'Enter a name for the new type.';
    }
    if (!preg_match('/^[A-Z0-9]{1,10}$/', $form['prefix'])) {
        $errors[] = 'Tag prefix must be 1 to 10 letters or numbers, like PC or UPS.';
    }
    $chk = $pdo->prepare('SELECT COUNT(*) FROM device_types WHERE name = ?');
    $chk->execute([$form['name']]);
    if ($chk->fetchColumn()) {
        $errors[] = 'A type called "' . $form['name'] . '" already exists.';
    }
    if (!$errors) {
        $sort = (int)$pdo->query('SELECT COALESCE(MAX(sort_order), 0) + 10 FROM device_types')->fetchColumn();
        $pdo->prepare('INSERT INTO device_types (name, prefix, icon, sort_order) VALUES (?,?,?,?)')
            ->execute([$form['name'], $form['prefix'], $form['icon'], $sort]);
        $newId = (int)$pdo->lastInsertId();
        log_activity('type_changed', null, '', 'Added device type ' . $form['name']);
        flash('success', 'Added the type <b>' . e($form['name']) . '</b>. Now add the fields its form should ask for.');
        redirect('type_edit.php?id=' . $newId);
    }
}

$types = get_types();
$pageTitle = 'Device types & fields';
$activeNav = 'types';
require __DIR__ . '/includes/header.php';
?>
<div class="page-head">
  <div>
    <h1>Device types &amp; fields</h1>
    <p class="muted">Each type has its own form. Open a type to add, remove or reorder the fields it asks for.</p>
  </div>
</div>

<div class="split">
  <section class="panel">
    <table class="table">
      <thead><tr><th>Type</th><th>Tag prefix</th><th class="num">Fields</th><th class="num">Items</th><th>Shown when adding</th><th class="row-actions"><span class="sr">Actions</span></th></tr></thead>
      <tbody>
      <?php foreach ($types as $t): ?>
        <tr data-href="type_edit.php?id=<?= (int)$t['id'] ?>" class="<?= $t['is_active'] ? '' : 'is-off' ?>">
          <td><a class="type-name" href="type_edit.php?id=<?= (int)$t['id'] ?>"><?= icon($t['icon']) ?><?= e($t['name']) ?></a></td>
          <td><?= asset_tag($t['prefix'] . '-0001', 'tag-sm') ?></td>
          <td class="num"><?= (int)$t['field_count'] ?></td>
          <td class="num"><?= (int)$t['item_count'] ?></td>
          <td><?= $t['is_active'] ? 'Yes' : '<span class="muted">Hidden</span>' ?></td>
          <td class="row-actions"><a class="icon-btn" href="type_edit.php?id=<?= (int)$t['id'] ?>" aria-label="Edit <?= e($t['name']) ?>"><?= icon('edit', 16) ?></a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </section>

  <section class="panel form-panel">
    <h2>Add a device type</h2>
    <?php if ($errors): ?><div class="notice notice-error"><?= implode('<br>', array_map('e', $errors)) ?></div><?php endif; ?>
    <form method="post" class="stack">
      <?= csrf_field() ?>
      <label class="field"><span>Name</span><input name="name" value="<?= e($form['name']) ?>" maxlength="80" required placeholder="e.g. Projector, IP Phone, Tablet"></label>
      <label class="field"><span>Tag prefix</span><input name="prefix" value="<?= e($form['prefix']) ?>" maxlength="10" required placeholder="e.g. PRJ" class="tag-input" style="text-transform:uppercase">
        <small class="hint">New items get tags like PRJ-0001, PRJ-0002.</small></label>
      <fieldset class="field"><legend>Icon</legend>
        <div class="icon-pick">
          <?php foreach (TYPE_ICONS as $ic): ?>
            <label title="<?= e($ic) ?>"><input type="radio" name="icon" value="<?= e($ic) ?>" <?= $form['icon'] === $ic ? 'checked' : '' ?>><span><?= icon($ic, 22) ?></span></label>
          <?php endforeach; ?>
        </div>
      </fieldset>
      <button class="btn btn-primary" type="submit"><?= icon('plus', 16) ?> Add type</button>
    </form>
  </section>
</div>
<?php require __DIR__ . '/includes/footer.php';
