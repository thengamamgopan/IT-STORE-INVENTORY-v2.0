/* IT Store Inventory - small helpers, no libraries needed */
(function () {
  'use strict';

  // Mobile menu
  document.querySelectorAll('[data-open-nav]').forEach(function (b) {
    b.addEventListener('click', function () { document.body.classList.add('nav-open'); });
  });
  document.querySelectorAll('[data-close-nav]').forEach(function (b) {
    b.addEventListener('click', function () { document.body.classList.remove('nav-open'); });
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') document.body.classList.remove('nav-open');
  });

  // Click anywhere on a table row to open it
  document.querySelectorAll('tr[data-href]').forEach(function (tr) {
    tr.addEventListener('click', function (e) {
      if (e.target.closest('a, button, input, select, textarea, form, label')) return;
      if (window.getSelection && String(window.getSelection()).length) return; // let people copy text
      window.location.href = tr.getAttribute('data-href');
    });
  });

  // "Add more detail" rows
  var extras = document.getElementById('extras');
  var tpl = document.getElementById('extra-template');
  document.querySelectorAll('[data-add-row]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      if (!extras || !tpl) return;
      var row = tpl.content.firstElementChild.cloneNode(true);
      extras.appendChild(row);
      row.querySelector('input').focus();
    });
  });
  document.addEventListener('click', function (e) {
    var rm = e.target.closest('[data-remove-row]');
    if (!rm) return;
    var row = rm.closest('.extra-row');
    if (row) row.parentNode.removeChild(row);
  });

  // Confirm before deleting
  document.querySelectorAll('form[data-confirm]').forEach(function (f) {
    f.addEventListener('submit', function (e) {
      if (!window.confirm(f.getAttribute('data-confirm'))) e.preventDefault();
    });
  });

  // Print button
  document.querySelectorAll('[data-print]').forEach(function (b) {
    b.addEventListener('click', function () { window.print(); });
  });

  // Field editor: show the choices box only when it is used
  var kind = document.querySelector('select[data-kind]');
  var optBox = document.querySelector('[data-options]');
  if (kind && optBox) {
    var lbl = optBox.querySelector('[data-options-label]');
    var hint = optBox.querySelector('[data-options-hint]');
    var sync = function () {
      var k = kind.value;
      optBox.hidden = !(k === 'select' || k === 'text');
      if (k === 'select') {
        lbl.textContent = 'Choices';
        hint.textContent = 'One per line. People can only pick from these.';
      } else {
        lbl.textContent = 'Suggestions (optional)';
        hint.textContent = 'One per line. Shown as suggestions while typing; people can still type anything.';
      }
    };
    kind.addEventListener('change', sync);
    sync();
  }

  // Export menu: close when clicking elsewhere or pressing Escape
  document.addEventListener('click', function (e) {
    document.querySelectorAll('details.menu[open]').forEach(function (d) {
      if (!d.contains(e.target)) d.removeAttribute('open');
    });
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') document.querySelectorAll('details.menu[open]').forEach(function (d) { d.removeAttribute('open'); });
  });
  // Close the menu after picking a download
  document.querySelectorAll('details.menu .menu-list a').forEach(function (a) {
    a.addEventListener('click', function () { a.closest('details').removeAttribute('open'); });
  });

  // Print view opened from the Print button prints straight away
  if (document.body.hasAttribute('data-autoprint')) {
    window.addEventListener('load', function () { setTimeout(function () { window.print(); }, 300); });
  }

  // Warn before leaving a form with unsaved changes
  var form = document.querySelector('form.device-form');
  if (form) {
    var dirty = false;
    form.addEventListener('input', function () { dirty = true; });
    form.addEventListener('submit', function () { dirty = false; });
    window.addEventListener('beforeunload', function (e) {
      if (dirty) { e.preventDefault(); e.returnValue = ''; }
    });
  }
})();
