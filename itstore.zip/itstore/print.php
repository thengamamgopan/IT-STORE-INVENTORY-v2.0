<?php
/* Printable equipment report (same filters as the equipment list) */
require __DIR__ . '/includes/init.php';
require __DIR__ . '/includes/report.php';
require_export();

$all = get('all') === '1';
$rep = report_build($_GET, $all);
$f = $rep['filters'];
$me = current_user();
$link = function (string $page, array $extra = []) use ($f) {
    $q = array_merge($f, $extra);
    $q = array_filter($q, function ($v) { return $v !== '' && $v !== null; });
    return $page . ($q ? '?' . http_build_query($q) : '');
};
$dense = count($rep['columns']) > 11;
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($rep['title']) ?> | <?= e(ORG_NAME) ?></title>
<link rel="stylesheet" href="assets/style.css?v=4">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<style>@page { size: A4 landscape; margin: 10mm; }</style>
</head>
<body class="report-page"<?= get('autoprint') === '1' ? ' data-autoprint' : '' ?>>
<div class="report-bar no-print">
  <a class="btn btn-ghost" href="<?= e($link('devices.php')) ?>">Back to equipment</a>
  <span class="report-bar-gap"></span>
  <?php if ($rep['type']): ?>
    <?php if ($all): ?>
      <a class="btn" href="<?= e($link('print.php')) ?>">Show list columns only</a>
    <?php else: ?>
      <a class="btn" href="<?= e($link('print.php', ['all' => '1'])) ?>">Show all <?= e($rep['type']['name']) ?> fields</a>
    <?php endif; ?>
  <?php endif; ?>
  <a class="btn" href="<?= e($link('export_pdf.php', $all ? ['all' => '1'] : [])) ?>"><?= icon('download', 16) ?> Download PDF</a>
  <button class="btn btn-primary" type="button" data-print><?= icon('print', 16) ?> Print</button>
</div>

<main class="report">
  <header class="report-head">
    <div>
      <div class="report-org"><?= e(ORG_NAME) ?></div>
      <h1><?= e($rep['title']) ?></h1>
      <p><?= e($rep['summary']) ?></p>
    </div>
    <dl class="report-meta">
      <div><dt>Items</dt><dd><?= number_format($rep['count']) ?></dd></div>
      <div><dt>Printed</dt><dd><?= e(fmt_date(now())) ?></dd></div>
      <div><dt>By</dt><dd><?= e($me['full_name']) ?></dd></div>
    </dl>
  </header>

  <?php if (!$rep['rows']): ?>
    <p class="muted">No equipment matches these filters.</p>
  <?php elseif ($all): ?>
    <?php foreach ($rep['records'] as $rec): ?>
      <section class="rec">
        <div class="rec-head"><?= asset_tag($rec['tag'], 'tag-sm') ?><b><?= e($rec['title']) ?></b><?= status_badge($rec['status']) ?></div>
        <?php if ($rec['pairs']): ?>
        <dl class="rec-grid">
          <?php foreach ($rec['pairs'] as $p): ?>
            <div class="<?= $p[2] === 'wide' ? 'wide' : '' ?>"><dt><?= e($p[0]) ?></dt><dd class="<?= $p[2] === 'data' ? 'data' : '' ?>"><?= nl2br(e($p[1])) ?></dd></div>
          <?php endforeach; ?>
        </dl>
        <?php else: ?><p class="muted small">No other details recorded.</p><?php endif; ?>
      </section>
    <?php endforeach; ?>
  <?php else: ?>
  <table class="report-table<?= $dense ? ' dense' : '' ?>">
    <thead><tr><th class="num">#</th><?php foreach ($rep['columns'] as $c): ?><th><?= e($c[0]) ?></th><?php endforeach; ?></tr></thead>
    <tbody>
    <?php foreach ($rep['rows'] as $i => $r): ?>
      <tr>
        <td class="num"><?= $i + 1 ?></td>
        <?php foreach ($r as $j => $v): $kind = $rep['columns'][$j][1]; ?>
          <?php if ($kind === 'tag'): ?><td class="nowrap"><?= asset_tag($v, 'tag-sm') ?></td>
          <?php elseif ($kind === 'status'): ?><td class="nowrap"><?= status_badge($v) ?></td>
          <?php elseif ($kind === 'data'): ?><td class="data"><?= e($v) ?></td>
          <?php else: ?><td><?= nl2br(e($v)) ?></td><?php endif; ?>
        <?php endforeach; ?>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <?php endif; ?>
</main>
<script src="assets/app.js?v=4"></script>
</body>
</html>
