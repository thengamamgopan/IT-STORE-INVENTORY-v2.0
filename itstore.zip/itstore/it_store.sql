-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 12, 2026 at 03:16 AM
-- Server version: 9.1.0
-- PHP Version: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `it_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

DROP TABLE IF EXISTS `activity_log`;
CREATE TABLE IF NOT EXISTS `activity_log` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int UNSIGNED DEFAULT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `action` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_id` int UNSIGNED DEFAULT NULL,
  `asset_tag` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `details` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_log_device` (`device_id`),
  KEY `idx_log_time` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `activity_log`
--

INSERT INTO `activity_log` (`id`, `user_id`, `username`, `action`, `device_id`, `asset_tag`, `details`, `created_at`) VALUES
(1, NULL, '', 'login', NULL, '', '', '2026-11-12 02:50:48');

-- --------------------------------------------------------

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
CREATE TABLE IF NOT EXISTS `devices` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `asset_tag` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type_id` int UNSIGNED NOT NULL,
  `make` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `model` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `serial_no` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `section` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `location` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `grant_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Serviceable',
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `created_by` int UNSIGNED DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_asset_tag` (`asset_tag`),
  KEY `idx_dev_type` (`type_id`),
  KEY `idx_dev_serial` (`serial_no`),
  KEY `idx_dev_section` (`section`),
  KEY `idx_dev_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `device_extras`
--

DROP TABLE IF EXISTS `device_extras`;
CREATE TABLE IF NOT EXISTS `device_extras` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `device_id` int UNSIGNED NOT NULL,
  `label` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_extra_device` (`device_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `device_types`
--

DROP TABLE IF EXISTS `device_types`;
CREATE TABLE IF NOT EXISTS `device_types` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prefix` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'box',
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_type_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `device_types`
--

INSERT INTO `device_types` (`id`, `name`, `prefix`, `icon`, `sort_order`, `is_active`) VALUES
(1, 'Computer', 'PC', 'desktop', 10, 1),
(2, 'Laptop', 'LAP', 'laptop', 20, 1),
(3, 'Server', 'SRV', 'server', 30, 1),
(4, 'Monitor', 'MON', 'monitor', 40, 1),
(5, 'NAS', 'NAS', 'nas', 50, 1),
(6, 'L2 Switch', 'L2SW', 'switch', 60, 1),
(7, 'L3 Switch', 'L3SW', 'switch', 70, 1),
(8, 'Router', 'RTR', 'router', 80, 1),
(9, 'Modem', 'MDM', 'modem', 90, 1),
(10, 'Wi-Fi Access Point', 'AP', 'wifi', 100, 1),
(11, 'Firewall', 'FW', 'firewall', 110, 1),
(12, 'Network Printer', 'NPR', 'printer', 120, 1),
(13, 'Printer', 'PRN', 'printer', 130, 1),
(14, 'Scanner', 'SCN', 'scanner', 140, 1),
(15, 'MDF', 'MDF', 'rack', 150, 1),
(16, 'NVR', 'NVR', 'nvr', 160, 1),
(17, 'CCTV Camera', 'CAM', 'camera', 170, 1),
(18, 'Biometric Device', 'BIO', 'fingerprint', 180, 1),
(19, 'UPS', 'UPS', 'ups', 190, 1),
(20, 'Other', 'OTH', 'box', 200, 1);

-- --------------------------------------------------------

--
-- Table structure for table `device_values`
--

DROP TABLE IF EXISTS `device_values`;
CREATE TABLE IF NOT EXISTS `device_values` (
  `device_id` int UNSIGNED NOT NULL,
  `field_id` int UNSIGNED NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`device_id`,`field_id`),
  KEY `idx_value_field` (`field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `type_fields`
--

DROP TABLE IF EXISTS `type_fields`;
CREATE TABLE IF NOT EXISTS `type_fields` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `type_id` int UNSIGNED NOT NULL,
  `label` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `options` text COLLATE utf8mb4_unicode_ci,
  `placeholder` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT '0',
  `show_in_list` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_field_type` (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `type_fields`
--

INSERT INTO `type_fields` (`id`, `type_id`, `label`, `field_type`, `options`, `placeholder`, `is_required`, `show_in_list`, `sort_order`) VALUES
(1, 1, 'Processor', 'text', NULL, 'e.g. Intel Core i5-12400', 0, 1, 10),
(2, 1, 'Motherboard', 'text', NULL, 'e.g. Gigabyte H610M', 0, 0, 20),
(3, 1, 'GPU', 'text', 'Onboard', 'e.g. Onboard or NVIDIA GT 730 2 GB', 0, 0, 30),
(4, 1, 'RAM', 'text', '4 GB\n8 GB\n16 GB\n32 GB', 'e.g. 8 GB DDR4', 0, 1, 40),
(5, 1, 'SSD', 'text', '128 GB\n256 GB\n512 GB\n1 TB', 'e.g. 256 GB SATA', 0, 0, 50),
(6, 1, 'HDD', 'text', '500 GB\n1 TB\n2 TB', 'e.g. 1 TB', 0, 0, 60),
(7, 1, 'NVMe', 'text', '256 GB\n512 GB\n1 TB', 'e.g. 512 GB', 0, 0, 70),
(8, 1, 'IP address', 'ip', NULL, 'e.g. 192.168.1.25', 0, 1, 80),
(9, 1, 'MAC address', 'mac', NULL, 'e.g. 00:1A:2B:3C:4D:5E', 0, 0, 90),
(10, 1, 'User of the PC', 'person', NULL, 'Name of the person using it', 0, 1, 100),
(11, 1, 'OS', 'text', 'Windows 11 Pro\nWindows 10 Pro\nWindows 7\nUbuntu\nLinux Mint\nmacOS', 'e.g. Windows 11 Pro', 0, 0, 110),
(12, 1, 'OS version', 'text', NULL, 'e.g. 23H2 or build 22631', 0, 0, 120),
(13, 2, 'Processor', 'text', NULL, 'e.g. Intel Core i7-1255U', 0, 1, 10),
(14, 2, 'RAM', 'text', '8 GB\n16 GB\n32 GB', 'e.g. 16 GB', 0, 1, 20),
(15, 2, 'SSD', 'text', '256 GB\n512 GB\n1 TB', NULL, 0, 0, 30),
(16, 2, 'HDD', 'text', NULL, NULL, 0, 0, 40),
(17, 2, 'NVMe', 'text', '256 GB\n512 GB\n1 TB', NULL, 0, 0, 50),
(18, 2, 'GPU', 'text', 'Onboard', NULL, 0, 0, 60),
(19, 2, 'Screen size', 'text', '13.3 inch\n14 inch\n15.6 inch', NULL, 0, 0, 70),
(20, 2, 'IP address', 'ip', NULL, NULL, 0, 0, 80),
(21, 2, 'MAC address (LAN)', 'mac', NULL, NULL, 0, 0, 90),
(22, 2, 'MAC address (Wi-Fi)', 'mac', NULL, NULL, 0, 0, 100),
(23, 2, 'User', 'person', NULL, 'Name of the person using it', 0, 1, 110),
(24, 2, 'OS', 'text', 'Windows 11 Pro\nWindows 10 Pro\nWindows 7\nUbuntu\nLinux Mint\nmacOS', NULL, 0, 0, 120),
(25, 2, 'OS version', 'text', NULL, NULL, 0, 0, 130),
(26, 2, 'Charger', 'text', NULL, 'e.g. Original 65 W', 0, 0, 140),
(27, 3, 'Processor', 'text', NULL, 'e.g. 2 x Intel Xeon Silver 4310', 0, 1, 10),
(28, 3, 'RAM', 'text', NULL, 'e.g. 64 GB ECC', 0, 1, 20),
(29, 3, 'Storage / RAID', 'textarea', NULL, 'e.g. 4 x 1.2 TB SAS in RAID 5', 0, 0, 30),
(30, 3, 'IP address', 'ip', NULL, NULL, 0, 1, 40),
(31, 3, 'MAC address', 'mac', NULL, NULL, 0, 0, 50),
(32, 3, 'iDRAC / iLO IP', 'ip', NULL, NULL, 0, 0, 60),
(33, 3, 'Role', 'text', 'Domain controller\nFile server\nDatabase server\nApplication server\nHypervisor', NULL, 0, 1, 70),
(34, 3, 'OS', 'text', 'Windows Server 2022\nWindows Server 2019\nUbuntu Server\nVMware ESXi\nProxmox', NULL, 0, 0, 80),
(35, 3, 'OS version', 'text', NULL, NULL, 0, 0, 90),
(36, 3, 'Rack position', 'text', NULL, 'e.g. Rack 1, U10-U11', 0, 0, 100),
(37, 4, 'Screen size', 'text', '19 inch\n22 inch\n24 inch\n27 inch', NULL, 0, 1, 10),
(38, 4, 'Resolution', 'text', '1366 x 768\n1920 x 1080\n2560 x 1440', NULL, 0, 0, 20),
(39, 4, 'Ports', 'text', NULL, 'e.g. HDMI, VGA', 0, 0, 30),
(40, 4, 'Connected to', 'text', NULL, 'Asset tag of the PC, e.g. PC-0012', 0, 0, 40),
(41, 4, 'User', 'person', NULL, NULL, 0, 1, 50),
(42, 5, 'IP address', 'ip', NULL, NULL, 0, 1, 10),
(43, 5, 'MAC address', 'mac', NULL, NULL, 0, 0, 20),
(44, 5, 'Drive bays', 'number', NULL, 'e.g. 4', 0, 0, 30),
(45, 5, 'Installed disks', 'textarea', NULL, 'e.g. 4 x 4 TB WD Red', 0, 0, 40),
(46, 5, 'Usable capacity', 'text', NULL, 'e.g. 12 TB', 0, 1, 50),
(47, 5, 'RAID type', 'select', 'RAID 0\nRAID 1\nRAID 5\nRAID 6\nRAID 10\nSHR\nJBOD', NULL, 0, 0, 60),
(48, 5, 'Firmware version', 'text', NULL, 'e.g. DSM 7.2', 0, 0, 70),
(49, 6, 'Management IP', 'ip', NULL, NULL, 0, 1, 10),
(50, 6, 'MAC address', 'mac', NULL, NULL, 0, 0, 20),
(51, 6, 'Ports', 'text', NULL, 'e.g. 24 x 1G + 4 SFP', 0, 1, 30),
(52, 6, 'Managed', 'select', 'Managed\nSmart / web managed\nUnmanaged', NULL, 0, 0, 40),
(53, 6, 'PoE', 'select', 'No\nYes, all ports\nYes, some ports', NULL, 0, 0, 50),
(54, 6, 'Firmware version', 'text', NULL, NULL, 0, 0, 60),
(55, 6, 'Rack position', 'text', NULL, 'e.g. MDF rack 1, U5', 0, 0, 70),
(56, 7, 'Management IP', 'ip', NULL, NULL, 0, 1, 10),
(57, 7, 'MAC address', 'mac', NULL, NULL, 0, 0, 20),
(58, 7, 'Ports', 'text', NULL, 'e.g. 48 x 1G', 0, 1, 30),
(59, 7, 'Uplink / SFP ports', 'text', NULL, 'e.g. 4 x 10G SFP+', 0, 0, 40),
(60, 7, 'PoE', 'select', 'No\nYes, all ports\nYes, some ports', NULL, 0, 0, 50),
(61, 7, 'VLANs', 'textarea', NULL, 'e.g. 10 Admin, 20 CCTV, 30 Guest', 0, 0, 60),
(62, 7, 'Firmware version', 'text', NULL, NULL, 0, 0, 70),
(63, 7, 'Rack position', 'text', NULL, NULL, 0, 0, 80),
(64, 8, 'WAN IP', 'ip', NULL, NULL, 0, 1, 10),
(65, 8, 'LAN IP', 'ip', NULL, NULL, 0, 1, 20),
(66, 8, 'MAC address', 'mac', NULL, NULL, 0, 0, 30),
(67, 8, 'Ports', 'text', NULL, 'e.g. 1 WAN + 4 LAN', 0, 0, 40),
(68, 8, 'ISP / link', 'text', NULL, NULL, 0, 0, 50),
(69, 8, 'Firmware version', 'text', NULL, NULL, 0, 0, 60),
(70, 9, 'Connection type', 'select', 'Fiber (ONT)\nVDSL\nADSL\n4G / 5G\nCable', NULL, 0, 1, 10),
(71, 9, 'ISP', 'text', NULL, NULL, 0, 1, 20),
(72, 9, 'Account / circuit ID', 'text', NULL, NULL, 0, 0, 30),
(73, 9, 'IP address', 'ip', NULL, NULL, 0, 0, 40),
(74, 9, 'MAC address', 'mac', NULL, NULL, 0, 0, 50),
(75, 9, 'Firmware version', 'text', NULL, NULL, 0, 0, 60),
(76, 10, 'IP address', 'ip', NULL, NULL, 0, 1, 10),
(77, 10, 'MAC address', 'mac', NULL, NULL, 0, 0, 20),
(78, 10, 'SSID', 'text', NULL, 'Wi-Fi network names', 0, 1, 30),
(79, 10, 'Band', 'select', '2.4 GHz\n5 GHz\nDual band\nTri band', NULL, 0, 0, 40),
(80, 10, 'Powered by PoE', 'select', 'Yes\nNo', NULL, 0, 0, 50),
(81, 11, 'Management IP', 'ip', NULL, NULL, 0, 1, 10),
(82, 11, 'WAN IP', 'ip', NULL, NULL, 0, 0, 20),
(83, 11, 'MAC address', 'mac', NULL, NULL, 0, 0, 30),
(84, 11, 'Firmware version', 'text', NULL, NULL, 0, 0, 40),
(85, 11, 'Licence valid until', 'date', NULL, NULL, 0, 1, 50),
(86, 12, 'IP address', 'ip', NULL, NULL, 0, 1, 10),
(87, 12, 'MAC address', 'mac', NULL, NULL, 0, 0, 20),
(88, 12, 'Printer type', 'select', 'Laser mono\nLaser colour\nInkjet\nInk tank\nDot matrix\nMultifunction (print, scan, copy)', NULL, 0, 0, 30),
(89, 12, 'Toner / cartridge', 'text', NULL, 'e.g. HP 26A', 0, 1, 40),
(90, 12, 'Paper size', 'select', 'A4\nA3\nA4 and A3\nLegal', NULL, 0, 0, 50),
(91, 12, 'Duplex', 'select', 'Yes\nNo', NULL, 0, 0, 60),
(92, 12, 'Page count', 'number', NULL, NULL, 0, 0, 70),
(93, 13, 'Printer type', 'select', 'Laser mono\nLaser colour\nInkjet\nInk tank\nDot matrix\nMultifunction (print, scan, copy)', NULL, 0, 0, 10),
(94, 13, 'Connection', 'select', 'USB\nParallel\nWi-Fi direct', NULL, 0, 0, 20),
(95, 13, 'Connected to PC', 'text', NULL, 'Asset tag of the PC, e.g. PC-0012', 0, 0, 30),
(96, 13, 'User', 'person', NULL, NULL, 0, 1, 40),
(97, 13, 'Toner / cartridge', 'text', NULL, 'e.g. HP 85A', 0, 1, 50),
(98, 13, 'Paper size', 'select', 'A4\nA3\nA4 and A3\nLegal', NULL, 0, 0, 60),
(99, 14, 'Scanner type', 'select', 'Flatbed\nSheet-fed (ADF)\nFlatbed + ADF', NULL, 0, 0, 10),
(100, 14, 'Connection', 'select', 'USB\nNetwork', NULL, 0, 0, 20),
(101, 14, 'IP address', 'ip', NULL, NULL, 0, 0, 30),
(102, 14, 'User', 'person', NULL, NULL, 0, 1, 40),
(103, 14, 'Max paper size', 'select', 'A4\nA3\nA4 and A3\nLegal', NULL, 0, 0, 50),
(104, 15, 'Rack size', 'text', '6U\n9U\n12U\n22U\n42U', 'e.g. 42U', 0, 1, 10),
(105, 15, 'Patch panels', 'text', NULL, 'e.g. 2 x 24-port Cat6', 0, 0, 20),
(106, 15, 'Total ports', 'number', NULL, NULL, 0, 0, 30),
(107, 15, 'Cable type', 'select', 'Cat5e\nCat6\nCat6A\nFiber\nMixed', NULL, 0, 0, 40),
(108, 15, 'Installed equipment', 'textarea', NULL, 'e.g. L3SW-0001, L2SW-0003, NVR-0001', 0, 0, 50),
(109, 15, 'UPS connected', 'select', 'Yes\nNo', NULL, 0, 0, 60),
(110, 16, 'IP address', 'ip', NULL, NULL, 0, 1, 10),
(111, 16, 'MAC address', 'mac', NULL, NULL, 0, 0, 20),
(112, 16, 'Channels', 'text', '4\n8\n16\n32\n64', 'e.g. 16', 0, 1, 30),
(113, 16, 'HDD installed', 'text', NULL, 'e.g. 2 x 4 TB surveillance', 0, 0, 40),
(114, 16, 'Recording days', 'number', NULL, 'About how many days it keeps', 0, 0, 50),
(115, 16, 'Firmware version', 'text', NULL, NULL, 0, 0, 60),
(116, 17, 'Camera type', 'select', 'Dome\nBullet\nTurret\nPTZ\nFisheye', NULL, 0, 1, 10),
(117, 17, 'Resolution', 'text', '2 MP\n4 MP\n5 MP\n8 MP (4K)', NULL, 0, 0, 20),
(118, 17, 'IP address', 'ip', NULL, NULL, 0, 1, 30),
(119, 17, 'MAC address', 'mac', NULL, NULL, 0, 0, 40),
(120, 17, 'NVR / channel', 'text', NULL, 'e.g. NVR-0001, channel 5', 0, 0, 50),
(121, 17, 'PoE', 'select', 'Yes\nNo', NULL, 0, 0, 60),
(122, 18, 'Verification type', 'select', 'Fingerprint\nFace\nCard\nFingerprint + card\nFace + fingerprint', NULL, 0, 1, 10),
(123, 18, 'IP address', 'ip', NULL, NULL, 0, 1, 20),
(124, 18, 'MAC address', 'mac', NULL, NULL, 0, 0, 30),
(125, 18, 'Device ID / machine no.', 'text', NULL, NULL, 0, 0, 40),
(126, 18, 'User capacity', 'number', NULL, NULL, 0, 0, 50),
(127, 18, 'Software', 'text', NULL, 'e.g. ZKTime, eTimeTrackLite', 0, 0, 60),
(128, 19, 'Capacity', 'text', '650 VA\n1 kVA\n2 kVA\n3 kVA\n6 kVA\n10 kVA', 'e.g. 1 kVA', 0, 1, 10),
(129, 19, 'UPS type', 'select', 'Offline\nLine interactive\nOnline', NULL, 0, 0, 20),
(130, 19, 'Batteries', 'text', NULL, 'e.g. 2 x 12 V 9 Ah', 0, 0, 30),
(131, 19, 'Battery replaced on', 'date', NULL, NULL, 0, 0, 40),
(132, 19, 'Connected load', 'text', NULL, 'e.g. Server rack, PC-0005', 0, 0, 50),
(133, 19, 'User', 'person', NULL, NULL, 0, 0, 60);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('admin','user','guest') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `failed_logins` int NOT NULL DEFAULT '0',
  `locked_until` datetime DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `full_name`, `password_hash`, `role`, `is_active`, `failed_logins`, `locked_until`, `last_login`, `created_at`) VALUES
(1, 'admin', 'Administrator', '$2y$10$mNSPNARMUtwuGbLduuNC5OajBlo6oH0yC1MmAdxoNDiPKnA9Jalry', 'admin', 1, 0, NULL, '2026-11-12 02:50:48', '2026-11-12 02:50:39');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `devices`
--
ALTER TABLE `devices`
  ADD CONSTRAINT `fk_device_type` FOREIGN KEY (`type_id`) REFERENCES `device_types` (`id`);

--
-- Constraints for table `device_extras`
--
ALTER TABLE `device_extras`
  ADD CONSTRAINT `fk_extra_device` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `device_values`
--
ALTER TABLE `device_values`
  ADD CONSTRAINT `fk_value_device` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_value_field` FOREIGN KEY (`field_id`) REFERENCES `type_fields` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `type_fields`
--
ALTER TABLE `type_fields`
  ADD CONSTRAINT `fk_field_type` FOREIGN KEY (`type_id`) REFERENCES `device_types` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
