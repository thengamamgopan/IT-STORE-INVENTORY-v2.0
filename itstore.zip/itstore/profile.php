<?php
require __DIR__ . '/includes/init.php';
require_login();
$me = current_user();
if (is_guest()) {
    deny_page('Change password', 'Guest accounts are shared, so their password is set by an admin on the Users page.');
}
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $cur  = isset($_POST['current']) && is_string($_POST['current']) ? $_POST['current'] : '';
    $new  = isset($_POST['new']) && is_string($_POST['new']) ? $_POST['new'] : '';
    $new2 = isset($_POST['new2']) && is_string($_POST['new2']) ? $_POST['new2'] : '';

    $st = db()->prepare('SELECT password_hash FROM users WHERE id = ?');
    $st->execute([$me['id']]);
    if (!password_verify($cur, (string)$st->fetchColumn())) {
        $errors[] = 'Your current password is not right.';
    }
    if (strlen($new) < 8) {
        $errors[] = 'The new password must be at least 8 characters.';
    } elseif ($new !== $new2) {
        $errors[] = 'The two new passwords do not match.';
    }
    if (!$errors) {
        db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([password_hash($new, PASSWORD_DEFAULT), $me['id']]);
        session_regenerate_id(true);
        flash('success', 'Your password has been changed.');
        redirect('dashboard.php');
    }
}

$pageTitle = 'Change password';
$activeNav = 'profile';
require __DIR__ . '/includes/header.php';
?>
<div class="page-head"><div><h1>Change password</h1><p class="muted">Signed in as <b><?= e($me['username']) ?></b>.</p></div></div>
<section class="panel form-panel narrow">
  <?php if ($errors): ?><div class="notice notice-error"><?= implode('<br>', array_map('e', $errors)) ?></div><?php endif; ?>
  <form method="post" class="stack">
    <?= csrf_field() ?>
    <label class="field"><span>Current password</span><input type="password" name="current" required autocomplete="current-password"></label>
    <label class="field"><span>New password <small class="muted">(at least 8 characters)</small></span><input type="password" name="new" required minlength="8" autocomplete="new-password"></label>
    <label class="field"><span>Type the new password again</span><input type="password" name="new2" required minlength="8" autocomplete="new-password"></label>
    <button class="btn btn-primary" type="submit">Change password</button>
  </form>
</section>
<?php require __DIR__ . '/includes/footer.php';
