<?php
require __DIR__ . '/includes/init.php';

if (hash_equals(csrf_token(), (string)($_GET['t'] ?? ''))) {
    $_SESSION = [];
    session_regenerate_id(true);
    flash('success', 'You have signed out.');
}
redirect('login.php');
