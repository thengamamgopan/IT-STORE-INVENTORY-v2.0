<?php
require __DIR__ . '/includes/init.php';
require_login();

$pdo = db();
$total = (int)$pdo->query('SELECT COUNT(*) FROM devices')->fetchColumn();
$monthStart = date('Y-m-01 00:00:00');
$st = $pdo->prepare('SELECT COUNT(*) FROM devices WHERE created_at >= ?');
$st->execute([$monthStart]);
$addedThisMonth = (int)$st->fetchColumn();

// counts per type and status
$byTypeStatus = [];
$statusTotals = [];
foreach ($pdo->query('SELECT type_id, status, COUNT(*) AS n FROM devices GROUP BY type_id, status') as $r) {
    $byTypeStatus[(int)$r['type_id']][$r['status']] = (int)$r['n'];
    $statusTotals[$r['status']] = ($statusTotals[$r['status']] ?? 0) + (int)$r['n'];
}
$types = get_types();
$sections = $pdo->query("SELECT section, COUNT(*) AS n FROM devices WHERE section <> '' GROUP BY section ORDER BY n DESC, section LIMIT 8")->fetchAll();
$recent = $pdo->query("SELECT * FROM activity_log WHERE device_id IS NOT NULL OR action = 'deleted' ORDER BY id DESC LIMIT 8")->fetchAll();

function status_class(string $s): string
{
    if (strcasecmp($s, 'Serviceable') === 0) return 'ok';
    if (strcasecmp($s, 'Unserviceable') === 0) return 'bad';
    return 'other';
}

$pageTitle = 'Dashboard';
$activeNav = 'dashboard';
require __DIR__ . '/includes/header.php';
?>
<div class="page-head">
  <div>
    <h1>Dashboard</h1>
    <p class="muted">Everything in the IT store at a glance.</p>
  </div>
</div>

<?php if ($total === 0): ?>
  <div class="empty">
    <?= icon('box', 40) ?>
    <h2>No equipment yet</h2>
    <?php if (can_edit()): ?>
    <p>Add your first item and it will show up here, counted by type and section.</p>
    <p><a class="btn btn-primary" href="device_form.php"><?= icon('plus', 17) ?> Add equipment</a></p>
    <?php else: ?>
    <p>Items will show up here once they are added to the register.</p>
    <?php endif; ?>
  </div>
<?php else: ?>

<dl class="tally">
  <div><dt>Items in register</dt><dd><a href="devices.php"><?= number_format($total) ?></a></dd></div>
  <?php foreach (STATUS_OPTIONS as $s): ?>
    <div class="tally-<?= status_class($s) ?>"><dt><?= e($s) ?></dt><dd><a href="devices.php?status=<?= urlencode($s) ?>"><?= number_format($statusTotals[$s] ?? 0) ?></a></dd></div>
  <?php endforeach; ?>
  <div><dt>Added this month</dt><dd><?= number_format($addedThisMonth) ?></dd></div>
</dl>

<div class="dash-grid">
  <section class="panel">
    <div class="panel-head"><h2>By type</h2><a class="small" href="devices.php">See all equipment</a></div>
    <table class="table type-table">
      <thead><tr><th>Type</th><th class="num">Items</th><?php foreach (STATUS_OPTIONS as $s): ?><th class="num"><?= e($s) ?></th><?php endforeach; ?><th class="bar-col"><span class="sr">Share</span></th></tr></thead>
      <tbody>
      <?php foreach ($types as $t):
          $counts = $byTypeStatus[(int)$t['id']] ?? [];
          $n = array_sum($counts);
          if ($n === 0) continue; ?>
        <tr data-href="devices.php?type=<?= (int)$t['id'] ?>">
          <td><a class="type-name" href="devices.php?type=<?= (int)$t['id'] ?>"><?= icon($t['icon']) ?><?= e($t['name']) ?></a></td>
          <td class="num"><b><?= $n ?></b></td>
          <?php foreach (STATUS_OPTIONS as $s): ?>
            <td class="num"><?php $c = $counts[$s] ?? 0; echo $c ? '<a href="devices.php?type=' . (int)$t['id'] . '&amp;status=' . urlencode($s) . '">' . $c . '</a>' : '<span class="muted">0</span>'; ?></td>
          <?php endforeach; ?>
          <td class="bar-col">
            <div class="bar" title="<?= e(implode(', ', array_map(function ($k, $v) { return "$k: $v"; }, array_keys($counts), $counts))) ?>">
              <?php foreach ($counts as $s => $c): ?><i class="bar-<?= status_class($s) ?>" style="width:<?= round($c / $n * 100, 2) ?>%"></i><?php endforeach; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php $unused = array_filter($types, function ($t) use ($byTypeStatus) { return empty($byTypeStatus[(int)$t['id']]) && $t['is_active']; });
    if ($unused): ?>
      <p class="muted small pad">No items yet: <?= e(implode(', ', array_column($unused, 'name'))) ?>.</p>
    <?php endif; ?>
  </section>

  <div class="dash-side">
    <section class="panel">
      <div class="panel-head"><h2>Recent changes</h2><?php if (is_admin()): ?><a class="small" href="activity.php">Activity log</a><?php endif; ?></div>
      <ul class="feed">
        <?php foreach ($recent as $r): ?>
          <li>
            <span class="feed-what"><?= e(action_label($r['action'])) ?>
              <?php if ($r['device_id'] && $r['action'] !== 'deleted'): ?><a href="device_view.php?id=<?= (int)$r['device_id'] ?>"><?= asset_tag($r['asset_tag'], 'tag-sm') ?></a><?php else: ?><?= asset_tag($r['asset_tag'], 'tag-sm tag-void') ?><?php endif; ?>
            </span>
            <span class="feed-meta"><?= e($r['username']) ?>, <?= e(fmt_date($r['created_at'])) ?></span>
          </li>
        <?php endforeach; ?>
        <?php if (!$recent): ?><li class="muted">Nothing yet.</li><?php endif; ?>
      </ul>
    </section>

    <?php if ($sections): ?>
    <section class="panel">
      <div class="panel-head"><h2>Busiest sections</h2></div>
      <table class="table compact">
        <tbody>
        <?php foreach ($sections as $s): ?>
          <tr data-href="devices.php?section=<?= urlencode($s['section']) ?>"><td><a href="devices.php?section=<?= urlencode($s['section']) ?>"><?= e($s['section']) ?></a></td><td class="num"><?= (int)$s['n'] ?></td></tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </section>
    <?php endif; ?>
  </div>
</div>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php';
