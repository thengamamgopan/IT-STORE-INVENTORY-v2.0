<?php
/* Downloads the equipment list (with the current filters) as a PDF, A4 landscape */
require __DIR__ . '/includes/init.php';
require __DIR__ . '/includes/report.php';
require __DIR__ . '/lib/fpdf/fpdf.php';
require_export();

$all = get('all') === '1';
$rep = report_build($_GET, $all);
$me = current_user();

/** FPDF's built-in fonts use the Windows-1252 character set */
function pdf_txt($s): string
{
    $s = (string)$s;
    if ($s === '' || !preg_match('/[^\x20-\x7E]/', $s)) {
        return $s;
    }
    if (function_exists('iconv')) {
        $r = @iconv('UTF-8', 'windows-1252//TRANSLIT', $s);
        if ($r !== false) {
            return $r;
        }
    }
    if (function_exists('mb_convert_encoding')) {
        return mb_convert_encoding($s, 'Windows-1252', 'UTF-8');
    }
    return preg_replace('/[^\x20-\x7E]/', '?', $s);
}

class ReportPDF extends FPDF
{
    public $rep;
    public $meta = '';
    public $cols = [];
    public $widths = [];
    public $fs = 7.5;      // table font size (pt)
    public $lh = 3.4;      // line height (mm)
    public $pad = 1.4;     // cell padding (mm)
    public $inTable = false;

    public function noCellMargin()
    {
        $this->cMargin = 0;
    }

    public function Header()
    {
        $this->SetTextColor(122, 135, 148);
        $this->SetFont('Helvetica', 'B', 8);
        $this->Cell(0, 4, pdf_txt(ORG_NAME), 0, 1);
        $this->SetTextColor(28, 38, 48);
        $this->SetFont('Helvetica', 'B', 14);
        $this->Cell(160, 7, pdf_txt($this->rep['title']), 0, 0);
        $this->SetFont('Helvetica', '', 8);
        $this->SetTextColor(75, 89, 104);
        $this->Cell(0, 7, pdf_txt($this->meta), 0, 1, 'R');
        $this->SetFont('Helvetica', '', 8.5);
        $this->Cell(0, 5, pdf_txt($this->rep['summary']), 0, 1);
        $this->Ln(2);
        if ($this->inTable) {
            $this->tableHeader();
        }
    }

    public function Footer()
    {
        $this->SetY(-10);
        $this->SetFont('Helvetica', '', 7);
        $this->SetTextColor(122, 135, 148);
        $this->Cell(0, 5, pdf_txt(APP_NAME), 0, 0, 'L');
        $this->Cell(0, 5, 'Page ' . $this->PageNo() . ' of {nb}', 0, 0, 'R');
    }

    public function tableHeader()
    {
        $this->SetFont('Helvetica', 'B', $this->fs);
        $this->SetFillColor(28, 38, 48);
        $this->SetTextColor(255, 255, 255);
        $h = 0;
        foreach ($this->cols as $i => $c) {
            $h = max($h, $this->NbLines($this->widths[$i] - 2 * $this->pad, $c[0]));
        }
        $h = $h * $this->lh + 2 * $this->pad;
        $x = $this->lMargin;
        $y = $this->GetY();
        foreach ($this->cols as $i => $c) {
            $w = $this->widths[$i];
            $this->Rect($x, $y, $w, $h, 'F');
            $this->SetXY($x + $this->pad, $y + $this->pad);
            $this->MultiCell($w - 2 * $this->pad, $this->lh, $c[0], 0, 'L');
            $x += $w;
        }
        $this->SetXY($this->lMargin, $y + $h);
        $this->SetTextColor(28, 38, 48);
    }

    public function row(array $cells, bool $zebra)
    {
        $this->SetFont('Helvetica', '', $this->fs);
        $lines = 1;
        foreach ($cells as $i => $txt) {
            $kind = $this->cols[$i][1];
            if ($kind === 'tag' || $kind === 'status') {
                $this->SetFont('Helvetica', 'B', $this->fs);
            }
            $lines = max($lines, $this->NbLines($this->widths[$i] - 2 * $this->pad, $txt));
            $this->SetFont('Helvetica', '', $this->fs);
        }
        $h = $lines * $this->lh + 2 * $this->pad;
        if ($this->GetY() + $h > $this->PageBreakTrigger) {
            $this->AddPage($this->CurOrientation);
        }
        $x = $this->lMargin;
        $y = $this->GetY();
        $total = array_sum($this->widths);
        if ($zebra) {
            $this->SetFillColor(246, 248, 250);
            $this->Rect($x, $y, $total, $h, 'F');
        }
        foreach ($cells as $i => $txt) {
            $w = $this->widths[$i];
            $kind = $this->cols[$i][1];
            $this->SetXY($x + $this->pad, $y + $this->pad);
            if ($kind === 'tag' && $txt !== '') {
                $this->SetFont('Helvetica', 'B', $this->fs);
                $tw = min($this->GetStringWidth($txt) + 1.6, $w - 2 * $this->pad + 1);
                $this->SetFillColor(244, 196, 48);
                $this->Rect($x + $this->pad - 0.8, $y + $this->pad - 0.3, $tw, $this->lh + 0.6, 'F');
                $this->SetTextColor(43, 34, 0);
            } elseif ($kind === 'status') {
                $this->SetFont('Helvetica', 'B', $this->fs);
                if (strcasecmp($txt, 'Unserviceable') === 0) {
                    $this->SetTextColor(180, 35, 24);
                } elseif (strcasecmp($txt, 'Serviceable') === 0) {
                    $this->SetTextColor(31, 122, 71);
                } else {
                    $this->SetTextColor(122, 80, 0);
                }
            } else {
                $this->SetFont('Helvetica', '', $this->fs);
                $this->SetTextColor(28, 38, 48);
            }
            $this->MultiCell($w - 2 * $this->pad, $this->lh, $txt, 0, 'L');
            $x += $w;
        }
        $this->SetDrawColor(214, 220, 226);
        $this->Line($this->lMargin, $y + $h, $this->lMargin + $total, $y + $h);
        $this->SetXY($this->lMargin, $y + $h);
        $this->SetTextColor(28, 38, 48);
    }

    /** "All fields" layout: one block per item, label/value pairs in six columns */
    public function record(array $rec)
    {
        $W = $this->w - $this->lMargin - $this->rMargin;
        $per = 6;
        $colW = $W / $per;
        $lh = 3.4;
        // work out the grid rows first, so a block never splits across pages
        $grid = [];
        $line = [];
        foreach ($rec['pairs'] as $p) {
            if ($p[2] === 'wide') {
                if ($line) { $grid[] = $line; $line = []; }
                $grid[] = [$p];
                continue;
            }
            $line[] = $p;
            if (count($line) === $per) { $grid[] = $line; $line = []; }
        }
        if ($line) { $grid[] = $line; }
        $heights = [];
        $this->SetFont('Helvetica', '', 8);
        foreach ($grid as $g) {
            $h = 1;
            foreach ($g as $p) {
                $w = ($p[2] === 'wide' ? $W : $colW) - 3;
                $h = max($h, $this->NbLines($w, $p[1]));
            }
            $heights[] = 3 + $h * $lh + 1.2;
        }
        $blockH = 7.5 + array_sum($heights) + ($grid ? 2 : 6) + 3;
        if ($this->GetY() + $blockH > $this->PageBreakTrigger) {
            $this->AddPage($this->CurOrientation);
        }

        $x = $this->lMargin;
        $y = $this->GetY();
        // header bar: tag, make & model, status
        $this->SetFillColor(236, 239, 242);
        $this->Rect($x, $y, $W, 7.5, 'F');
        $this->SetFont('Helvetica', 'B', 9);
        $tw = $this->GetStringWidth($rec['tag']) + 3;
        $this->SetFillColor(244, 196, 48);
        $this->Rect($x + 1.5, $y + 1.3, $tw, 4.9, 'F');
        $this->SetTextColor(43, 34, 0);
        $this->SetXY($x + 3, $y + 1.3);
        $this->Cell($tw - 3, 4.9, $rec['tag']);
        $this->SetTextColor(28, 38, 48);
        $this->SetFont('Helvetica', 'B', 9.5);
        $this->SetXY($x + 1.5 + $tw + 3, $y + 1.3);
        $this->Cell($W - $tw - 60, 4.9, $rec['title']);
        $st = $rec['status'];
        if (strcasecmp($st, 'Unserviceable') === 0) {
            $this->SetTextColor(180, 35, 24);
        } elseif (strcasecmp($st, 'Serviceable') === 0) {
            $this->SetTextColor(31, 122, 71);
        } else {
            $this->SetTextColor(122, 80, 0);
        }
        $this->SetFont('Helvetica', 'B', 8.5);
        $this->SetXY($x + $W - 52, $y + 1.3);
        $this->Cell(50, 4.9, $st, 0, 0, 'R');
        $this->SetTextColor(28, 38, 48);
        $y += 9;

        if (!$grid) {
            $this->SetFont('Helvetica', 'I', 8);
            $this->SetTextColor(122, 135, 148);
            $this->SetXY($x + 1.5, $y);
            $this->Cell(0, 4, 'No other details recorded.');
            $y += 6;
        }
        foreach ($grid as $gi => $g) {
            foreach ($g as $ci => $p) {
                $cx = $x + $ci * $colW + 1.5;
                $w = ($p[2] === 'wide' ? $W : $colW) - 3;
                $this->SetXY($cx, $y);
                $this->SetFont('Helvetica', '', 6.5);
                $this->SetTextColor(122, 135, 148);
                $this->Cell($w, 3, $p[0]);
                $this->SetXY($cx, $y + 3);
                $this->SetFont('Helvetica', '', 8);
                $this->SetTextColor(28, 38, 48);
                $this->MultiCell($w, $lh, $p[1], 0, 'L');
            }
            $y += $heights[$gi];
        }
        $this->SetDrawColor(200, 207, 214);
        $this->Line($x, $y + 1, $x + $W, $y + 1);
        $this->SetXY($x, $y + 3);
    }

    /** How many lines a MultiCell of width $w would take (from the FPDF "table" example) */
    public function NbLines($w, $txt)
    {
        $cw = $this->CurrentFont['cw'];
        if ($w == 0) {
            $w = $this->w - $this->rMargin - $this->x;
        }
        $wmax = ($w - 2 * $this->cMargin) * 1000 / $this->FontSize;
        $s = str_replace("\r", '', (string)$txt);
        $nb = strlen($s);
        if ($nb > 0 && $s[$nb - 1] === "\n") {
            $nb--;
        }
        $sep = -1;
        $i = 0;
        $j = 0;
        $l = 0;
        $nl = 1;
        while ($i < $nb) {
            $c = $s[$i];
            if ($c === "\n") {
                $i++;
                $sep = -1;
                $j = $i;
                $l = 0;
                $nl++;
                continue;
            }
            if ($c === ' ') {
                $sep = $i;
            }
            $l += $cw[$c] ?? 500;
            if ($l > $wmax) {
                if ($sep === -1) {
                    if ($i === $j) {
                        $i++;
                    }
                } else {
                    $i = $sep + 1;
                }
                $sep = -1;
                $j = $i;
                $l = 0;
                $nl++;
            } else {
                $i++;
            }
        }
        return $nl;
    }
}

$pdf = new ReportPDF('L', 'mm', 'A4');
$pdf->rep = $rep;
$pdf->meta = number_format($rep['count']) . ' item' . ($rep['count'] === 1 ? '' : 's') . '   |   Printed ' . fmt_date(now()) . ' by ' . $me['full_name'];
$pdf->SetTitle($rep['title'], true);
$pdf->SetAuthor(ORG_NAME, true);
$pdf->SetCreator(APP_NAME, true);
$pdf->SetMargins(10, 10, 10);
$pdf->SetAutoPageBreak(false, 14);
$pdf->AliasNbPages();
$pdf->noCellMargin();

if ($rep['all']) {
    // One block per item
    $pdf->AddPage();
    if (!$rep['records']) {
        $pdf->SetFont('Helvetica', '', 10);
        $pdf->Cell(0, 10, 'No equipment matches these filters.', 0, 1);
    }
    foreach ($rep['records'] as $rec) {
        $rec['tag'] = pdf_txt($rec['tag']);
        $rec['title'] = pdf_txt($rec['title']);
        $rec['status'] = pdf_txt($rec['status']);
        $rec['pairs'] = array_map(function ($p) {
            $v = strlen($p[1]) > 1500 ? substr($p[1], 0, 1500) . '...' : $p[1];
            return [pdf_txt($p[0]), pdf_txt($v), $p[2]];
        }, $rec['pairs']);
        $pdf->record($rec);
    }
    $name = strtolower(preg_replace('/[^A-Za-z0-9]+/', '-', $rep['title'])) . '-all-fields-' . date('Y-m-d') . '.pdf';
    $pdf->Output('D', $name);
    exit;
}

// Columns: row number first, then the report columns. Text converted for the PDF fonts.
$cols = array_merge([['#', 'num']], array_map(function ($c) { return [pdf_txt($c[0]), $c[1]]; }, $rep['columns']));
$rows = [];
foreach ($rep['rows'] as $i => $r) {
    $cells = [(string)($i + 1)];
    foreach ($r as $v) {
        $v = (string)$v;
        if (strlen($v) > 600) {
            $v = substr($v, 0, 600) . '...';
        }
        $cells[] = pdf_txt($v);
    }
    $rows[] = $cells;
}
$pdf->cols = $cols;
if (count($cols) > 13) {
    $pdf->fs = 6.3;
    $pdf->lh = 2.9;
    $pdf->pad = 1.1;
}

// Column widths: fit the content, then squeeze or stretch to the page width
$avail = 297 - 20;
$nat = [];
$min = [];
foreach ($cols as $i => $c) {
    $pdf->SetFont('Helvetica', 'B', $pdf->fs);
    $head = $pdf->GetStringWidth($c[0]);
    $longestWord = 0;
    foreach (preg_split('/\s+/', $c[0]) as $wd) {
        $longestWord = max($longestWord, $pdf->GetStringWidth($wd));
    }
    $pdf->SetFont('Helvetica', in_array($c[1], ['tag', 'status'], true) ? 'B' : '', $pdf->fs);
    $content = 0;
    $wordMax = 0;
    foreach ($rows as $r) {
        $content = max($content, $pdf->GetStringWidth($r[$i]));
        foreach (preg_split('/\s+/', $r[$i]) as $wd) {
            $wordMax = max($wordMax, $pdf->GetStringWidth($wd));
        }
    }
    $pad = 2 * $pdf->pad + 0.8;
    $cap = $c[1] === 'text' ? 70 : 48;
    $nat[$i] = min(max($head, $content), $cap) + $pad;
    // never narrower than its longest word, so words are not cut in half
    $min[$i] = in_array($c[1], ['tag', 'status', 'num'], true) ? $nat[$i] : min($nat[$i], max($longestWord, min($wordMax, 32)) + $pad);
}
$sumNat = array_sum($nat);
$sumMin = array_sum($min);
$widths = [];
foreach ($nat as $i => $n) {
    if ($sumNat <= $avail) {
        $widths[$i] = $n * $avail / $sumNat;            // stretch to the full width
    } elseif ($sumMin < $avail) {
        $k = ($avail - $sumMin) / max(0.001, $sumNat - $sumMin);
        $widths[$i] = $min[$i] + ($n - $min[$i]) * $k;   // squeeze the long columns, they wrap
    } else {
        $widths[$i] = $min[$i] * $avail / $sumMin;
    }
}
$pdf->widths = $widths;

$pdf->inTable = (bool)$rows;
$pdf->AddPage();
if (!$rows) {
    $pdf->SetFont('Helvetica', '', 10);
    $pdf->Cell(0, 10, 'No equipment matches these filters.', 0, 1);
}
foreach ($rows as $i => $r) {
    $pdf->row($r, $i % 2 === 1);
}

$name = strtolower(preg_replace('/[^A-Za-z0-9]+/', '-', $rep['title'])) . '-' . date('Y-m-d') . '.pdf';
$pdf->Output('D', $name);
