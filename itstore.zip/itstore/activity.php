<?php
require __DIR__ . '/includes/init.php';
require_admin();
$pdo = db();

$action = get('action');
$user = get('user');
$q = get('q');
$page = max(1, (int)get('page', '1'));
$per = 50;

$where = ['1=1'];
$params = [];
if ($action !== '') {
    $where[] = 'action = ?';
    $params[] = $action;
}
if ($user !== '') {
    $where[] = 'username = ?';
    $params[] = $user;
}
if ($q !== '') {
    $where[] = '(asset_tag LIKE ? OR details LIKE ?)';
    $params[] = '%' . like_escape($q) . '%';
    $params[] = '%' . like_escape($q) . '%';
}
$w = implode(' AND ', $where);
$st = $pdo->prepare("SELECT COUNT(*) FROM activity_log WHERE $w");
$st->execute($params);
$total = (int)$st->fetchColumn();
$pages = max(1, (int)ceil($total / $per));
$page = min($page, $pages);
$st = $pdo->prepare("SELECT * FROM activity_log WHERE $w ORDER BY id DESC LIMIT $per OFFSET " . (($page - 1) * $per));
$st->execute($params);
$rows = $st->fetchAll();

$actions = $pdo->query('SELECT DISTINCT action FROM activity_log ORDER BY action')->fetchAll(PDO::FETCH_COLUMN);
$usernames = $pdo->query("SELECT DISTINCT username FROM activity_log WHERE username <> '' ORDER BY username")->fetchAll(PDO::FETCH_COLUMN);
$base = array_filter(['action' => $action, 'user' => $user, 'q' => $q], 'strlen');

$pageTitle = 'Activity log';
$activeNav = 'activity';
require __DIR__ . '/includes/header.php';
?>
<div class="page-head"><div><h1>Activity log</h1><p class="muted">Who added, edited or deleted what, and when. Deleted items keep their details here.</p></div></div>

<form class="filters" method="get">
  <label class="field grow"><span>Asset tag or text</span><input type="search" name="q" value="<?= e($q) ?>"></label>
  <label class="field"><span>Action</span><select name="action"><option value="">All actions</option>
    <?php foreach ($actions as $a): ?><option value="<?= e($a) ?>" <?= $a === $action ? 'selected' : '' ?>><?= e(action_label($a)) ?></option><?php endforeach; ?></select></label>
  <label class="field"><span>Person</span><select name="user"><option value="">Everyone</option>
    <?php foreach ($usernames as $u): ?><option <?= $u === $user ? 'selected' : '' ?>><?= e($u) ?></option><?php endforeach; ?></select></label>
  <div class="filter-btns"><button class="btn btn-primary" type="submit">Filter</button><?php if ($base): ?><a class="btn btn-ghost" href="activity.php">Clear</a><?php endif; ?></div>
</form>

<div class="table-wrap">
<table class="table log">
  <thead><tr><th>When</th><th>Who</th><th>Action</th><th>Item</th><th>Details</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td class="nowrap"><?= e(fmt_date($r['created_at'])) ?></td>
      <td><?= e($r['username']) ?></td>
      <td><?= e(action_label($r['action'])) ?></td>
      <td><?php if ($r['asset_tag'] !== ''): ?><?= $r['device_id'] ? '<a href="device_view.php?id=' . (int)$r['device_id'] . '">' . asset_tag($r['asset_tag'], 'tag-sm') . '</a>' : asset_tag($r['asset_tag'], 'tag-sm tag-void') ?><?php endif; ?></td>
      <td class="details"><?= nl2br(e((string)$r['details'])) ?></td>
    </tr>
  <?php endforeach; ?>
  <?php if (!$rows): ?><tr><td colspan="5" class="muted">No activity matches.</td></tr><?php endif; ?>
  </tbody>
</table>
</div>
<?php if ($pages > 1): ?>
<nav class="pager" aria-label="Pages">
  <span class="muted">Page <?= $page ?> of <?= $pages ?></span>
  <span class="pager-links">
    <?php if ($page > 1): ?><a class="btn btn-sm" href="activity.php?<?= e(http_build_query($base + ['page' => $page - 1])) ?>">Newer</a><?php endif; ?>
    <?php if ($page < $pages): ?><a class="btn btn-sm" href="activity.php?<?= e(http_build_query($base + ['page' => $page + 1])) ?>">Older</a><?php endif; ?>
  </span>
</nav>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php';
