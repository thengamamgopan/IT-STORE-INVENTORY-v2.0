<?php
/* Shared helpers */

function app_url(string $path): string
{
    return $path; // every page lives in the app's root folder
}

function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function now(): string
{
    return date('Y-m-d H:i:s');
}

function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

function str_cut(string $s, int $len): string
{
    $s = trim($s);
    if (function_exists('mb_substr')) {
        return mb_substr($s, 0, $len, 'UTF-8');
    }
    return substr($s, 0, $len);
}

function post(string $key, string $default = ''): string
{
    $v = $_POST[$key] ?? $default;
    return is_string($v) ? trim($v) : $default;
}

function get(string $key, string $default = ''): string
{
    $v = $_GET[$key] ?? $default;
    return is_string($v) ? trim($v) : $default;
}

function like_escape(string $s): string
{
    return addcslashes($s, '%_\\');
}

function fmt_date(?string $dt, bool $withTime = true): string
{
    if (!$dt) {
        return '';
    }
    $ts = strtotime($dt);
    return $withTime ? date('d M Y, H:i', $ts) : date('d M Y', $ts);
}

/* ---------- CSRF ---------- */

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_check(): void
{
    $sent = $_POST['csrf'] ?? '';
    if (!is_string($sent) || !hash_equals(csrf_token(), $sent)) {
        fatal_page('This form has expired', 'Go back, reload the page and try again.', 400);
    }
}

/* ---------- Flash messages ---------- */

function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'msg' => $message];
}

function render_flash(): string
{
    if (empty($_SESSION['flash'])) {
        return '';
    }
    $out = '';
    foreach ($_SESSION['flash'] as $f) {
        $out .= '<div class="notice notice-' . e($f['type']) . '" role="status">' . $f['msg'] . '</div>';
    }
    unset($_SESSION['flash']);
    return $out;
}

/* ---------- Activity log ---------- */

function log_activity(string $action, ?int $deviceId = null, string $assetTag = '', string $details = ''): void
{
    $u = current_user();
    $st = db()->prepare('INSERT INTO activity_log (user_id, username, action, device_id, asset_tag, details, created_at)
                         VALUES (?,?,?,?,?,?,?)');
    $st->execute([$u ? $u['id'] : null, $u ? $u['username'] : '', $action, $deviceId, $assetTag, $details, now()]);
}

function action_label(string $action): string
{
    $map = [
        'added' => 'Added', 'updated' => 'Edited', 'deleted' => 'Deleted', 'login' => 'Signed in',
        'user_added' => 'Added user', 'user_updated' => 'Edited user', 'type_changed' => 'Changed device types',
    ];
    return $map[$action] ?? ucfirst(str_replace('_', ' ', $action));
}

/* ---------- Device types and fields ---------- */

const FIELD_KINDS = [
    'text'     => 'Text',
    'textarea' => 'Long text',
    'number'   => 'Number',
    'select'   => 'Drop-down list',
    'date'     => 'Date',
    'ip'       => 'IP address',
    'mac'      => 'MAC address',
    'person'   => 'Person (user of the item)',
];

const TYPE_ICONS = ['desktop', 'laptop', 'server', 'monitor', 'nas', 'switch', 'router', 'modem', 'wifi', 'firewall',
    'printer', 'scanner', 'rack', 'nvr', 'camera', 'fingerprint', 'ups', 'phone', 'projector', 'box'];

function get_types(bool $activeOnly = false): array
{
    $sql = 'SELECT t.*, (SELECT COUNT(*) FROM devices d WHERE d.type_id = t.id) AS item_count,
                   (SELECT COUNT(*) FROM type_fields f WHERE f.type_id = t.id) AS field_count
            FROM device_types t' . ($activeOnly ? ' WHERE t.is_active = 1' : '') . ' ORDER BY t.sort_order, t.name';
    return db()->query($sql)->fetchAll();
}

function get_type(int $id): ?array
{
    $st = db()->prepare('SELECT * FROM device_types WHERE id = ?');
    $st->execute([$id]);
    $row = $st->fetch();
    return $row ?: null;
}

function get_type_fields(int $typeId): array
{
    $st = db()->prepare('SELECT * FROM type_fields WHERE type_id = ? ORDER BY sort_order, id');
    $st->execute([$typeId]);
    return $st->fetchAll();
}

function field_options(?string $options): array
{
    if ($options === null || trim($options) === '') {
        return [];
    }
    $out = [];
    foreach (preg_split('/\r\n|\r|\n/', $options) as $line) {
        $line = trim($line);
        if ($line !== '' && !in_array($line, $out, true)) {
            $out[] = $line;
        }
    }
    return $out;
}

/* ---------- Devices ---------- */

function load_device(int $id): ?array
{
    $st = db()->prepare('SELECT d.*, t.name AS type_name, t.icon AS type_icon, t.prefix AS type_prefix,
                                cu.full_name AS created_by_name, uu.full_name AS updated_by_name
                         FROM devices d
                         JOIN device_types t ON t.id = d.type_id
                         LEFT JOIN users cu ON cu.id = d.created_by
                         LEFT JOIN users uu ON uu.id = d.updated_by
                         WHERE d.id = ?');
    $st->execute([$id]);
    $row = $st->fetch();
    return $row ?: null;
}

function load_device_values(int $deviceId): array
{
    $st = db()->prepare('SELECT field_id, value FROM device_values WHERE device_id = ?');
    $st->execute([$deviceId]);
    $out = [];
    foreach ($st->fetchAll() as $r) {
        $out[(int)$r['field_id']] = $r['value'];
    }
    return $out;
}

function load_device_extras(int $deviceId): array
{
    $st = db()->prepare('SELECT label, value FROM device_extras WHERE device_id = ? ORDER BY sort_order, id');
    $st->execute([$deviceId]);
    return $st->fetchAll();
}

function next_asset_tag(string $prefix): string
{
    $prefix = strtoupper(trim($prefix)) ?: 'IT';
    // Also looks at the activity log, so a deleted item's number is never handed out again
    $st = db()->prepare('SELECT asset_tag FROM devices WHERE asset_tag LIKE ?
                         UNION SELECT asset_tag FROM activity_log WHERE asset_tag LIKE ?');
    $like = like_escape($prefix) . '-%';
    $st->execute([$like, $like]);
    $max = 0;
    foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $tag) {
        if (preg_match('/^' . preg_quote($prefix, '/') . '-(\d+)$/i', $tag, $m)) {
            $max = max($max, (int)$m[1]);
        }
    }
    return $prefix . '-' . str_pad((string)($max + 1), 4, '0', STR_PAD_LEFT);
}

function normalize_mac(string $mac): ?string
{
    $hex = preg_replace('/[^0-9A-Fa-f]/', '', $mac);
    if (strlen($hex) !== 12 || !preg_match('/^[0-9A-Fa-f :.\-]+$/', $mac)) {
        return null;
    }
    return strtoupper(implode(':', str_split($hex, 2)));
}

function distinct_values(string $column, ?int $typeId = null): array
{
    $allowed = ['make', 'model', 'section', 'location', 'grant_name'];
    if (!in_array($column, $allowed, true)) {
        return [];
    }
    $sql = "SELECT DISTINCT $column FROM devices WHERE $column <> ''" . ($typeId ? ' AND type_id = ?' : '') . " ORDER BY $column LIMIT 300";
    $st = db()->prepare($sql);
    $st->execute($typeId ? [$typeId] : []);
    return $st->fetchAll(PDO::FETCH_COLUMN);
}

function datalist(string $id, array $values): string
{
    if (!$values) {
        return '';
    }
    $html = '<datalist id="' . e($id) . '">';
    foreach ($values as $v) {
        $html .= '<option value="' . e($v) . '">';
    }
    return $html . '</datalist>';
}

function status_badge(string $status): string
{
    $opts = STATUS_OPTIONS;
    $cls = 'st-other';
    if (strcasecmp($status, 'Serviceable') === 0) {
        $cls = 'st-ok';
    } elseif (strcasecmp($status, 'Unserviceable') === 0) {
        $cls = 'st-bad';
    } elseif (isset($opts[0]) && $status === $opts[0]) {
        $cls = 'st-ok';
    }
    return '<span class="status ' . $cls . '">' . e($status) . '</span>';
}

function asset_tag(string $tag, string $extraClass = ''): string
{
    return '<span class="tag ' . e($extraClass) . '">' . e($tag) . '</span>';
}

/**
 * Builds the WHERE clause for the equipment list and the CSV export
 * from the same filters, so both always show the same items.
 */
function device_filter(array $src): array
{
    $where = ['1=1'];
    $params = [];

    $typeId = (int)($src['type'] ?? 0);
    if ($typeId > 0) {
        $where[] = 'd.type_id = ?';
        $params[] = $typeId;
    }
    $status = isset($src['status']) && is_string($src['status']) ? trim($src['status']) : '';
    if ($status !== '') {
        $where[] = 'd.status = ?';
        $params[] = $status;
    }
    $section = isset($src['section']) && is_string($src['section']) ? trim($src['section']) : '';
    if ($section !== '') {
        $where[] = 'd.section = ?';
        $params[] = $section;
    }
    $q = isset($src['q']) && is_string($src['q']) ? trim($src['q']) : '';
    if ($q !== '') {
        $words = array_slice(preg_split('/\s+/', $q), 0, 6);
        foreach ($words as $w) {
            $like = '%' . like_escape($w) . '%';
            $where[] = '(d.asset_tag LIKE ? OR d.make LIKE ? OR d.model LIKE ? OR d.serial_no LIKE ? OR d.section LIKE ?
                        OR d.location LIKE ? OR d.grant_name LIKE ? OR d.remarks LIKE ? OR d.status LIKE ?
                        OR EXISTS (SELECT 1 FROM device_values v WHERE v.device_id = d.id AND v.value LIKE ?)
                        OR EXISTS (SELECT 1 FROM device_extras x WHERE x.device_id = d.id AND (x.value LIKE ? OR x.label LIKE ?)))';
            for ($i = 0; $i < 12; $i++) {
                $params[] = $like;
            }
        }
    }
    return [implode(' AND ', $where), $params];
}

/** ORDER BY clause for the equipment list, print view and PDF */
function device_sort_sql(string $sort, string $dir): string
{
    $map = [
        'tag'     => 'd.asset_tag',
        'type'    => 't.sort_order, t.name',
        'make'    => 'd.make, d.model',
        'serial'  => 'd.serial_no',
        'section' => 'd.section',
        'status'  => 'd.status',
        'updated' => 'd.updated_at',
    ];
    $cols = $map[$sort] ?? $map['tag'];
    $dir = $dir === 'desc' ? 'DESC' : 'ASC';
    return implode(', ', array_map(function ($c) use ($dir) { return trim($c) . ' ' . $dir; }, explode(',', $cols)));
}

/** The current list filters, read from the query string, for links to print / PDF / CSV */
function list_filters(array $src): array
{
    $out = [];
    foreach (['q', 'status', 'section', 'sort', 'dir'] as $k) {
        if (isset($src[$k]) && is_string($src[$k]) && trim($src[$k]) !== '') {
            $out[$k] = trim($src[$k]);
        }
    }
    if (!empty($src['type']) && (int)$src['type'] > 0) {
        $out['type'] = (int)$src['type'];
    }
    return $out;
}

function nav_link(string $href, string $iconName, string $label, string $key, string $active): string
{
    $cls = $key === $active ? ' class="active" aria-current="page"' : '';
    return '<a href="' . e($href) . '"' . $cls . '>' . icon($iconName) . '<span>' . e($label) . '</span></a>';
}

function can_delete(): bool
{
    $u = current_user();
    return $u !== null && ($u['role'] === 'admin' || ($u['role'] === 'user' && USERS_CAN_DELETE));
}
