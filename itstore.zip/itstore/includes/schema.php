<?php
/* Database tables and the starter device types. Used by install.php only. */

function schema_sql(): array
{
    $t = 'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    return [
        "CREATE TABLE IF NOT EXISTS users (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) NOT NULL,
            full_name VARCHAR(100) NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            role ENUM('admin','user','guest') NOT NULL DEFAULT 'user',
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            failed_logins INT NOT NULL DEFAULT 0,
            locked_until DATETIME NULL,
            last_login DATETIME NULL,
            created_at DATETIME NOT NULL,
            UNIQUE KEY uq_username (username)
        ) $t",

        "CREATE TABLE IF NOT EXISTS device_types (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(80) NOT NULL,
            prefix VARCHAR(10) NOT NULL,
            icon VARCHAR(30) NOT NULL DEFAULT 'box',
            sort_order INT NOT NULL DEFAULT 0,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            UNIQUE KEY uq_type_name (name)
        ) $t",

        "CREATE TABLE IF NOT EXISTS type_fields (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            type_id INT UNSIGNED NOT NULL,
            label VARCHAR(80) NOT NULL,
            field_type VARCHAR(20) NOT NULL DEFAULT 'text',
            options TEXT NULL,
            placeholder VARCHAR(120) NULL,
            is_required TINYINT(1) NOT NULL DEFAULT 0,
            show_in_list TINYINT(1) NOT NULL DEFAULT 0,
            sort_order INT NOT NULL DEFAULT 0,
            KEY idx_field_type (type_id),
            CONSTRAINT fk_field_type FOREIGN KEY (type_id) REFERENCES device_types(id) ON DELETE CASCADE
        ) $t",

        "CREATE TABLE IF NOT EXISTS devices (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            asset_tag VARCHAR(50) NOT NULL,
            type_id INT UNSIGNED NOT NULL,
            make VARCHAR(100) NOT NULL DEFAULT '',
            model VARCHAR(100) NOT NULL DEFAULT '',
            serial_no VARCHAR(100) NOT NULL DEFAULT '',
            section VARCHAR(100) NOT NULL DEFAULT '',
            location VARCHAR(100) NOT NULL DEFAULT '',
            grant_name VARCHAR(100) NOT NULL DEFAULT '',
            status VARCHAR(30) NOT NULL DEFAULT 'Serviceable',
            remarks TEXT NULL,
            created_by INT UNSIGNED NULL,
            updated_by INT UNSIGNED NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            UNIQUE KEY uq_asset_tag (asset_tag),
            KEY idx_dev_type (type_id),
            KEY idx_dev_serial (serial_no),
            KEY idx_dev_section (section),
            KEY idx_dev_status (status),
            CONSTRAINT fk_device_type FOREIGN KEY (type_id) REFERENCES device_types(id)
        ) $t",

        "CREATE TABLE IF NOT EXISTS device_values (
            device_id INT UNSIGNED NOT NULL,
            field_id INT UNSIGNED NOT NULL,
            value TEXT NOT NULL,
            PRIMARY KEY (device_id, field_id),
            KEY idx_value_field (field_id),
            CONSTRAINT fk_value_device FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE,
            CONSTRAINT fk_value_field FOREIGN KEY (field_id) REFERENCES type_fields(id) ON DELETE CASCADE
        ) $t",

        "CREATE TABLE IF NOT EXISTS device_extras (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            device_id INT UNSIGNED NOT NULL,
            label VARCHAR(100) NOT NULL,
            value TEXT NOT NULL,
            sort_order INT NOT NULL DEFAULT 0,
            KEY idx_extra_device (device_id),
            CONSTRAINT fk_extra_device FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE
        ) $t",

        "CREATE TABLE IF NOT EXISTS activity_log (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id INT UNSIGNED NULL,
            username VARCHAR(50) NOT NULL DEFAULT '',
            action VARCHAR(30) NOT NULL,
            device_id INT UNSIGNED NULL,
            asset_tag VARCHAR(50) NOT NULL DEFAULT '',
            details TEXT NULL,
            created_at DATETIME NOT NULL,
            KEY idx_log_device (device_id),
            KEY idx_log_time (created_at)
        ) $t",
    ];
}

/**
 * Starter device types.
 * Each field: [label, kind, options (one per line), placeholder, show in list (1/0)]
 * Kinds: text, textarea, number, select, date, ip, mac, person
 * For "text" fields, options become suggestions; for "select" they are the only choices.
 */
function starter_types(): array
{
    $os  = "Windows 11 Pro\nWindows 10 Pro\nWindows 7\nUbuntu\nLinux Mint\nmacOS";
    $yn  = "Yes\nNo";
    $ptype = "Laser mono\nLaser colour\nInkjet\nInk tank\nDot matrix\nMultifunction (print, scan, copy)";
    $paper = "A4\nA3\nA4 and A3\nLegal";

    return [
        ['Computer', 'PC', 'desktop', [
            ['Processor', 'text', '', 'e.g. Intel Core i5-12400', 1],
            ['Motherboard', 'text', '', 'e.g. Gigabyte H610M', 0],
            ['GPU', 'text', "Onboard", 'e.g. Onboard or NVIDIA GT 730 2 GB', 0],
            ['RAM', 'text', "4 GB\n8 GB\n16 GB\n32 GB", 'e.g. 8 GB DDR4', 1],
            ['SSD', 'text', "128 GB\n256 GB\n512 GB\n1 TB", 'e.g. 256 GB SATA', 0],
            ['HDD', 'text', "500 GB\n1 TB\n2 TB", 'e.g. 1 TB', 0],
            ['NVMe', 'text', "256 GB\n512 GB\n1 TB", 'e.g. 512 GB', 0],
            ['IP address', 'ip', '', 'e.g. 192.168.1.25', 1],
            ['MAC address', 'mac', '', 'e.g. 00:1A:2B:3C:4D:5E', 0],
            ['User of the PC', 'person', '', 'Name of the person using it', 1],
            ['OS', 'text', $os, 'e.g. Windows 11 Pro', 0],
            ['OS version', 'text', '', 'e.g. 23H2 or build 22631', 0],
        ]],
        ['Laptop', 'LAP', 'laptop', [
            ['Processor', 'text', '', 'e.g. Intel Core i7-1255U', 1],
            ['RAM', 'text', "8 GB\n16 GB\n32 GB", 'e.g. 16 GB', 1],
            ['SSD', 'text', "256 GB\n512 GB\n1 TB", '', 0],
            ['HDD', 'text', '', '', 0],
            ['NVMe', 'text', "256 GB\n512 GB\n1 TB", '', 0],
            ['GPU', 'text', 'Onboard', '', 0],
            ['Screen size', 'text', "13.3 inch\n14 inch\n15.6 inch", '', 0],
            ['IP address', 'ip', '', '', 0],
            ['MAC address (LAN)', 'mac', '', '', 0],
            ['MAC address (Wi-Fi)', 'mac', '', '', 0],
            ['User', 'person', '', 'Name of the person using it', 1],
            ['OS', 'text', $os, '', 0],
            ['OS version', 'text', '', '', 0],
            ['Charger', 'text', '', 'e.g. Original 65 W', 0],
        ]],
        ['Server', 'SRV', 'server', [
            ['Processor', 'text', '', 'e.g. 2 x Intel Xeon Silver 4310', 1],
            ['RAM', 'text', '', 'e.g. 64 GB ECC', 1],
            ['Storage / RAID', 'textarea', '', 'e.g. 4 x 1.2 TB SAS in RAID 5', 0],
            ['IP address', 'ip', '', '', 1],
            ['MAC address', 'mac', '', '', 0],
            ['iDRAC / iLO IP', 'ip', '', '', 0],
            ['Role', 'text', "Domain controller\nFile server\nDatabase server\nApplication server\nHypervisor", '', 1],
            ['OS', 'text', "Windows Server 2022\nWindows Server 2019\nUbuntu Server\nVMware ESXi\nProxmox", '', 0],
            ['OS version', 'text', '', '', 0],
            ['Rack position', 'text', '', 'e.g. Rack 1, U10-U11', 0],
        ]],
        ['Monitor', 'MON', 'monitor', [
            ['Screen size', 'text', "19 inch\n22 inch\n24 inch\n27 inch", '', 1],
            ['Resolution', 'text', "1366 x 768\n1920 x 1080\n2560 x 1440", '', 0],
            ['Ports', 'text', '', 'e.g. HDMI, VGA', 0],
            ['Connected to', 'text', '', 'Asset tag of the PC, e.g. PC-0012', 0],
            ['User', 'person', '', '', 1],
        ]],
        ['NAS', 'NAS', 'nas', [
            ['IP address', 'ip', '', '', 1],
            ['MAC address', 'mac', '', '', 0],
            ['Drive bays', 'number', '', 'e.g. 4', 0],
            ['Installed disks', 'textarea', '', 'e.g. 4 x 4 TB WD Red', 0],
            ['Usable capacity', 'text', '', 'e.g. 12 TB', 1],
            ['RAID type', 'select', "RAID 0\nRAID 1\nRAID 5\nRAID 6\nRAID 10\nSHR\nJBOD", '', 0],
            ['Firmware version', 'text', '', 'e.g. DSM 7.2', 0],
        ]],
        ['L2 Switch', 'L2SW', 'switch', [
            ['Management IP', 'ip', '', '', 1],
            ['MAC address', 'mac', '', '', 0],
            ['Ports', 'text', '', 'e.g. 24 x 1G + 4 SFP', 1],
            ['Managed', 'select', "Managed\nSmart / web managed\nUnmanaged", '', 0],
            ['PoE', 'select', "No\nYes, all ports\nYes, some ports", '', 0],
            ['Firmware version', 'text', '', '', 0],
            ['Rack position', 'text', '', 'e.g. MDF rack 1, U5', 0],
        ]],
        ['L3 Switch', 'L3SW', 'switch', [
            ['Management IP', 'ip', '', '', 1],
            ['MAC address', 'mac', '', '', 0],
            ['Ports', 'text', '', 'e.g. 48 x 1G', 1],
            ['Uplink / SFP ports', 'text', '', 'e.g. 4 x 10G SFP+', 0],
            ['PoE', 'select', "No\nYes, all ports\nYes, some ports", '', 0],
            ['VLANs', 'textarea', '', 'e.g. 10 Admin, 20 CCTV, 30 Guest', 0],
            ['Firmware version', 'text', '', '', 0],
            ['Rack position', 'text', '', '', 0],
        ]],
        ['Router', 'RTR', 'router', [
            ['WAN IP', 'ip', '', '', 1],
            ['LAN IP', 'ip', '', '', 1],
            ['MAC address', 'mac', '', '', 0],
            ['Ports', 'text', '', 'e.g. 1 WAN + 4 LAN', 0],
            ['ISP / link', 'text', '', '', 0],
            ['Firmware version', 'text', '', '', 0],
        ]],
        ['Modem', 'MDM', 'modem', [
            ['Connection type', 'select', "Fiber (ONT)\nVDSL\nADSL\n4G / 5G\nCable", '', 1],
            ['ISP', 'text', '', '', 1],
            ['Account / circuit ID', 'text', '', '', 0],
            ['IP address', 'ip', '', '', 0],
            ['MAC address', 'mac', '', '', 0],
            ['Firmware version', 'text', '', '', 0],
        ]],
        ['Wi-Fi Access Point', 'AP', 'wifi', [
            ['IP address', 'ip', '', '', 1],
            ['MAC address', 'mac', '', '', 0],
            ['SSID', 'text', '', 'Wi-Fi network names', 1],
            ['Band', 'select', "2.4 GHz\n5 GHz\nDual band\nTri band", '', 0],
            ['Powered by PoE', 'select', $yn, '', 0],
        ]],
        ['Firewall', 'FW', 'firewall', [
            ['Management IP', 'ip', '', '', 1],
            ['WAN IP', 'ip', '', '', 0],
            ['MAC address', 'mac', '', '', 0],
            ['Firmware version', 'text', '', '', 0],
            ['Licence valid until', 'date', '', '', 1],
        ]],
        ['Network Printer', 'NPR', 'printer', [
            ['IP address', 'ip', '', '', 1],
            ['MAC address', 'mac', '', '', 0],
            ['Printer type', 'select', $ptype, '', 0],
            ['Toner / cartridge', 'text', '', 'e.g. HP 26A', 1],
            ['Paper size', 'select', $paper, '', 0],
            ['Duplex', 'select', $yn, '', 0],
            ['Page count', 'number', '', '', 0],
        ]],
        ['Printer', 'PRN', 'printer', [
            ['Printer type', 'select', $ptype, '', 0],
            ['Connection', 'select', "USB\nParallel\nWi-Fi direct", '', 0],
            ['Connected to PC', 'text', '', 'Asset tag of the PC, e.g. PC-0012', 0],
            ['User', 'person', '', '', 1],
            ['Toner / cartridge', 'text', '', 'e.g. HP 85A', 1],
            ['Paper size', 'select', $paper, '', 0],
        ]],
        ['Scanner', 'SCN', 'scanner', [
            ['Scanner type', 'select', "Flatbed\nSheet-fed (ADF)\nFlatbed + ADF", '', 0],
            ['Connection', 'select', "USB\nNetwork", '', 0],
            ['IP address', 'ip', '', '', 0],
            ['User', 'person', '', '', 1],
            ['Max paper size', 'select', $paper, '', 0],
        ]],
        ['MDF', 'MDF', 'rack', [
            ['Rack size', 'text', "6U\n9U\n12U\n22U\n42U", 'e.g. 42U', 1],
            ['Patch panels', 'text', '', 'e.g. 2 x 24-port Cat6', 0],
            ['Total ports', 'number', '', '', 0],
            ['Cable type', 'select', "Cat5e\nCat6\nCat6A\nFiber\nMixed", '', 0],
            ['Installed equipment', 'textarea', '', 'e.g. L3SW-0001, L2SW-0003, NVR-0001', 0],
            ['UPS connected', 'select', $yn, '', 0],
        ]],
        ['NVR', 'NVR', 'nvr', [
            ['IP address', 'ip', '', '', 1],
            ['MAC address', 'mac', '', '', 0],
            ['Channels', 'text', "4\n8\n16\n32\n64", 'e.g. 16', 1],
            ['HDD installed', 'text', '', 'e.g. 2 x 4 TB surveillance', 0],
            ['Recording days', 'number', '', 'About how many days it keeps', 0],
            ['Firmware version', 'text', '', '', 0],
        ]],
        ['CCTV Camera', 'CAM', 'camera', [
            ['Camera type', 'select', "Dome\nBullet\nTurret\nPTZ\nFisheye", '', 1],
            ['Resolution', 'text', "2 MP\n4 MP\n5 MP\n8 MP (4K)", '', 0],
            ['IP address', 'ip', '', '', 1],
            ['MAC address', 'mac', '', '', 0],
            ['NVR / channel', 'text', '', 'e.g. NVR-0001, channel 5', 0],
            ['PoE', 'select', $yn, '', 0],
        ]],
        ['Biometric Device', 'BIO', 'fingerprint', [
            ['Verification type', 'select', "Fingerprint\nFace\nCard\nFingerprint + card\nFace + fingerprint", '', 1],
            ['IP address', 'ip', '', '', 1],
            ['MAC address', 'mac', '', '', 0],
            ['Device ID / machine no.', 'text', '', '', 0],
            ['User capacity', 'number', '', '', 0],
            ['Software', 'text', '', 'e.g. ZKTime, eTimeTrackLite', 0],
        ]],
        ['UPS', 'UPS', 'ups', [
            ['Capacity', 'text', "650 VA\n1 kVA\n2 kVA\n3 kVA\n6 kVA\n10 kVA", 'e.g. 1 kVA', 1],
            ['UPS type', 'select', "Offline\nLine interactive\nOnline", '', 0],
            ['Batteries', 'text', '', 'e.g. 2 x 12 V 9 Ah', 0],
            ['Battery replaced on', 'date', '', '', 0],
            ['Connected load', 'text', '', 'e.g. Server rack, PC-0005', 0],
            ['User', 'person', '', '', 0],
        ]],
        ['Other', 'OTH', 'box', []],
    ];
}
