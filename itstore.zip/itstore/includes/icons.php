<?php
/* Inline SVG icons - no internet connection needed */

function icon(string $name, int $size = 18, string $class = ''): string
{
    static $paths = [
        // equipment
        'desktop'     => '<rect x="2" y="4" width="13" height="10" rx="1.5"/><path d="M6 18h5M8.5 14v4"/><rect x="17" y="4" width="5" height="16" rx="1"/><path d="M19.5 8h.01"/>',
        'laptop'      => '<path d="M20 16V7a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v9m16 0H4m16 0 1.3 2.6a1 1 0 0 1-.9 1.4H3.6a1 1 0 0 1-.9-1.4L4 16"/>',
        'server'      => '<rect x="3" y="3" width="18" height="7" rx="1.5"/><rect x="3" y="14" width="18" height="7" rx="1.5"/><path d="M7 6.5h.01M7 17.5h.01M11 6.5h6M11 17.5h6"/>',
        'monitor'     => '<rect x="3" y="4" width="18" height="12" rx="1.5"/><path d="M12 16v4M8 20h8"/>',
        'nas'         => '<rect x="5" y="2" width="14" height="20" rx="2"/><path d="M9 6h6M9 10h6M9 14h6"/><path d="M12 18h.01"/>',
        'switch'      => '<rect x="2" y="8" width="20" height="8" rx="1.5"/><path d="M6 12h.01M9 12h.01M12 12h.01M15 12h.01M18 12h.01"/>',
        'router'      => '<rect x="2" y="13" width="20" height="7" rx="1.5"/><path d="M6 16.5h.01M10 16.5h.01M7 13 5 6M17 13l2-7"/>',
        'modem'       => '<rect x="3" y="8" width="18" height="11" rx="2"/><path d="M7 15h.01M11 15h.01M15 15h.01M8 5c2.5-1.6 5.5-1.6 8 0"/>',
        'wifi'        => '<path d="M2 9a14 14 0 0 1 20 0M5 12.5a10 10 0 0 1 14 0M8.5 16a5 5 0 0 1 7 0M12 19.5h.01"/>',
        'firewall'    => '<path d="M12 3 4 6v6c0 4.5 3.4 8.2 8 9 4.6-.8 8-4.5 8-9V6z"/><path d="M8 11h8M8 15h8M12 11v4"/>',
        'printer'     => '<path d="M6 9V3h12v6"/><rect x="3" y="9" width="18" height="8" rx="1.5"/><path d="M6 14h12v7H6z"/>',
        'scanner'     => '<rect x="3" y="11" width="18" height="8" rx="1.5"/><path d="M3 15h18M5 11l3-7h11M17 17h.01"/>',
        'rack'        => '<rect x="4" y="2" width="16" height="20" rx="1.5"/><path d="M4 7h16M4 12h16M4 17h16M7 4.5h.01M7 9.5h.01M7 14.5h.01M7 19.5h.01"/>',
        'nvr'         => '<rect x="2" y="7" width="20" height="10" rx="1.5"/><circle cx="7" cy="12" r="2"/><path d="M12 12h6"/>',
        'camera'      => '<path d="M16.8 12h3.6a1 1 0 0 1 .9 1.4l-2 4.1a1 1 0 0 1-1.7.1l-2.1-3"/><path d="M17.1 9.1a1 1 0 0 1 .4 1.3l-3.1 6.2a1 1 0 0 1-1.3.4l-9.5-4.7a2.9 2.9 0 0 1-1.3-3.9L3.7 5.6a2.9 2.9 0 0 1 3.9-1.3z"/><path d="M2 19h3.8a2 2 0 0 0 1.8-1.1L9 15M2 21v-4M7 9h.01"/>',
        'fingerprint' => '<path d="M12 11v3a8 8 0 0 1-1.2 4.2"/><path d="M8 11a4 4 0 0 1 8 0v2a11 11 0 0 1-.7 4"/><path d="M5 13v-2a7 7 0 0 1 14 0v1"/><path d="M5.2 16.5A8 8 0 0 0 6 13"/><path d="M19 15.5a14 14 0 0 1-.6 3"/>',
        'ups'         => '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M12.5 7l-3 5h5l-3 5"/>',
        'phone'       => '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 3v18M11 8h6M11 12h1.5M14.5 12H16M11 16h1.5M14.5 16H16"/>',
        'projector'   => '<rect x="2" y="8" width="20" height="9" rx="2"/><circle cx="15" cy="12.5" r="2.5"/><path d="M6 12.5h3M5 17v2M19 17v2"/>',
        'box'         => '<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="M3 8l9 5 9-5M12 13v8"/>',
        // interface
        'grid'        => '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
        'list'        => '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
        'plus'        => '<path d="M12 5v14M5 12h14"/>',
        'users'       => '<circle cx="9" cy="8" r="4"/><path d="M2 21a7 7 0 0 1 14 0M16 3.5a4 4 0 0 1 0 9M22 21a7 7 0 0 0-4-6.3"/>',
        'user'        => '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
        'sliders'     => '<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
        'history'     => '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5M12 7v5l3 2"/>',
        'logout'      => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
        'search'      => '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
        'edit'        => '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
        'trash'       => '<path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6M10 11v6M14 11v6"/>',
        'download'    => '<path d="M12 3v12M7 10l5 5 5-5M5 21h14"/>',
        'menu'        => '<path d="M4 6h16M4 12h16M4 18h16"/>',
        'key'         => '<circle cx="7.5" cy="15.5" r="4.5"/><path d="M10.7 12.3 21 2M16 7l3 3M19 4l2 2"/>',
        'x'           => '<path d="M18 6 6 18M6 6l12 12"/>',
        'copy'        => '<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/>',
        'up'          => '<path d="M12 19V5M5 12l7-7 7 7"/>',
        'down'        => '<path d="M12 5v14M19 12l-7 7-7-7"/>',
        'eye'         => '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
        'print'       => '<path d="M6 9V3h12v6"/><rect x="3" y="9" width="18" height="8" rx="1.5"/><path d="M6 14h12v7H6z"/>',
        'upload'      => '<path d="M12 15V3M7 8l5-5 5 5M5 21h14"/>',
        'file'        => '<path d="M14 3H6a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>',
        'sheet'       => '<rect x="4" y="3" width="16" height="18" rx="1.5"/><path d="M4 9h16M4 15h16M10 3v18"/>',
        'chevron'     => '<path d="m9 6 6 6-6 6"/>',
    ];
    $p = $paths[$name] ?? $paths['box'];
    return '<svg class="ico ' . $class . '" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $p . '</svg>';
}
