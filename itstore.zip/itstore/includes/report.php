<?php
/* Builds the equipment report used by the print view and the PDF download */

/**
 * @param array $src      list filters (q, type, status, section, sort, dir)
 * @param bool  $allFields true = every field of the chosen type, false = the list columns
 * @return array title, summary, columns [label, kind], rows [[cell, ...]], count, type
 */
function report_build(array $src, bool $allFields): array
{
    $pdo = db();
    $f = list_filters($src);
    [$where, $params] = device_filter($f);
    $type = !empty($f['type']) ? get_type((int)$f['type']) : null;
    $allFields = $allFields && $type !== null;

    $order = device_sort_sql($f['sort'] ?? 'tag', $f['dir'] ?? 'asc');
    $st = $pdo->prepare("SELECT d.*, t.name AS type_name,
          (SELECT v.value FROM device_values v JOIN type_fields tf ON tf.id = v.field_id
             WHERE v.device_id = d.id AND tf.field_type = 'ip' ORDER BY tf.sort_order, tf.id LIMIT 1) AS ip,
          (SELECT v.value FROM device_values v JOIN type_fields tf ON tf.id = v.field_id
             WHERE v.device_id = d.id AND tf.field_type = 'person' ORDER BY tf.sort_order, tf.id LIMIT 1) AS person
        FROM devices d JOIN device_types t ON t.id = d.type_id
        WHERE $where ORDER BY $order, d.id");
    $st->execute($params);
    $devices = $st->fetchAll();

    $fields = [];
    if ($type) {
        $fields = get_type_fields((int)$type['id']);
        if (!$allFields) {
            $fields = array_values(array_filter($fields, function ($fl) { return (int)$fl['show_in_list'] === 1; }));
        }
    }

    $values = [];
    if ($fields && $devices) {
        $fids = array_map('intval', array_column($fields, 'id'));
        $in = implode(',', array_fill(0, count($fids), '?'));
        $vs = $pdo->prepare("SELECT device_id, field_id, value FROM device_values
                             WHERE field_id IN ($in) AND device_id IN (SELECT d.id FROM devices d WHERE $where)");
        $vs->execute(array_merge($fids, $params));
        foreach ($vs->fetchAll() as $v) {
            $values[(int)$v['device_id']][(int)$v['field_id']] = $v['value'];
        }
    }
    $extras = [];
    if ($allFields && $devices) {
        $xs = $pdo->prepare("SELECT device_id, label, value FROM device_extras
                             WHERE device_id IN (SELECT d.id FROM devices d WHERE $where) ORDER BY sort_order, id");
        $xs->execute($params);
        foreach ($xs->fetchAll() as $x) {
            $extras[(int)$x['device_id']][] = $x['label'] . ': ' . $x['value'];
        }
    }

    // Columns: [label, kind]  kind = tag | status | data | text
    $cols = [['Asset tag', 'tag']];
    if (!$type) {
        $cols[] = ['Type', 'text'];
    }
    $cols[] = ['Make & model', 'text'];
    $cols[] = ['Serial no.', 'data'];
    if ($type) {
        foreach ($fields as $fl) {
            $cols[] = [$fl['label'], in_array($fl['field_type'], ['ip', 'mac'], true) ? 'data' : 'text'];
        }
    } else {
        $cols[] = ['IP address', 'data'];
        $cols[] = ['User', 'text'];
    }
    foreach (['Section', 'Location', 'Grant'] as $c) {
        $cols[] = [$c, 'text'];
    }
    $cols[] = ['Status', 'status'];
    if ($allFields) {
        $cols[] = ['Additional details', 'text'];
        $cols[] = ['Remarks', 'text'];
    }

    // "All fields" is laid out as one block per item (too many fields for table columns)
    $records = [];
    if ($allFields) {
        foreach ($devices as $d) {
            $id = (int)$d['id'];
            $pairs = [];
            foreach (['serial_no' => 'Serial no.', 'section' => 'Section', 'location' => 'Location', 'grant_name' => 'Grant'] as $k => $lab) {
                if ($d[$k] !== '') {
                    $pairs[] = [$lab, $d[$k], $k === 'serial_no' ? 'data' : 'text'];
                }
            }
            foreach ($fields as $fl) {
                $v = (string)($values[$id][(int)$fl['id']] ?? '');
                if ($v !== '') {
                    $pairs[] = [$fl['label'], $fl['field_type'] === 'date' ? fmt_date($v, false) : $v,
                        in_array($fl['field_type'], ['ip', 'mac'], true) ? 'data' : 'text'];
                }
            }
            foreach ($extras[$id] ?? [] as $x) {
                $pos = strpos($x, ': ');
                $pairs[] = [substr($x, 0, $pos), substr($x, $pos + 2), 'text'];
            }
            if ((string)$d['remarks'] !== '') {
                $pairs[] = ['Remarks', (string)$d['remarks'], 'wide'];
            }
            $records[] = [
                'tag'    => $d['asset_tag'],
                'title'  => trim($d['make'] . ' ' . $d['model']) ?: $d['type_name'],
                'status' => $d['status'],
                'pairs'  => $pairs,
            ];
        }
    }

    $rows = [];
    foreach ($devices as $d) {
        $id = (int)$d['id'];
        $r = [$d['asset_tag']];
        if (!$type) {
            $r[] = $d['type_name'];
        }
        $r[] = trim($d['make'] . ' ' . $d['model']);
        $r[] = $d['serial_no'];
        if ($type) {
            foreach ($fields as $fl) {
                $v = (string)($values[$id][(int)$fl['id']] ?? '');
                $r[] = $fl['field_type'] === 'date' && $v !== '' ? fmt_date($v, false) : $v;
            }
        } else {
            $r[] = (string)$d['ip'];
            $r[] = (string)$d['person'];
        }
        $r[] = $d['section'];
        $r[] = $d['location'];
        $r[] = $d['grant_name'];
        $r[] = $d['status'];
        if ($allFields) {
            $r[] = implode('; ', $extras[$id] ?? []);
            $r[] = (string)$d['remarks'];
        }
        $rows[] = $r;
    }

    $summary = [];
    if (!empty($f['status'])) {
        $summary[] = 'Status: ' . $f['status'];
    }
    if (!empty($f['section'])) {
        $summary[] = 'Section: ' . $f['section'];
    }
    if (!empty($f['q'])) {
        $summary[] = 'Search: "' . $f['q'] . '"';
    }

    return [
        'title'   => ($type ? $type['name'] : 'Equipment') . ' register',
        'summary' => $summary ? implode(', ', $summary) : ($type ? 'All ' . $type['name'] . ' items' : 'All equipment'),
        'columns' => $cols,
        'rows'    => $rows,
        'records' => $records,
        'count'   => count($rows),
        'type'    => $type,
        'all'     => $allFields,
        'filters' => $f,
    ];
}
