<?php
/*
 * IT Store Inventory - settings
 * ---------------------------------------------------------------
 * WAMP default: MySQL user "root" with an EMPTY password.
 * If you set a MySQL password, put it in DB_PASS.
 * If you use WAMP's MariaDB instead of MySQL, the port is often 3307.
 */

define('DB_HOST', 'localhost');
define('DB_PORT', 3306);
define('DB_NAME', 'it_store');
define('DB_USER', 'root');
define('DB_PASS', '');

// Shown in the sidebar, on the login page and on printouts
define('APP_NAME', 'IT Store Inventory');
define('ORG_NAME', 'Your Company Name');

// Your local time zone, e.g. 'Asia/Karachi', 'Asia/Kolkata', 'Asia/Dubai', 'Europe/London'
define('APP_TIMEZONE', 'UTC');

// Status choices shown on every item. You can add more, e.g. 'Under repair', 'Condemned'
define('STATUS_OPTIONS', ['Serviceable', 'Unserviceable']);

// Can normal users (not admins) delete equipment? true = yes, false = admins only
define('USERS_CAN_DELETE', false);

// Can guest (view only) accounts print and download PDF / CSV? true = yes, false = view on screen only
define('GUESTS_CAN_EXPORT', true);

// Sign people out after this many minutes without activity
define('SESSION_IDLE_MINUTES', 120);

// Rows per page on the equipment list
define('PER_PAGE', 50);
