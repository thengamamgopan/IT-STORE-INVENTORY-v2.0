<?php
/* Database connection (PDO). Every query in the app uses prepared statements. */

function db_options(): array
{
    return [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
}

function db(): PDO
{
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }
    if (!extension_loaded('pdo_mysql')) {
        fatal_page('PHP extension pdo_mysql is off',
            'In WAMP, left-click the tray icon, open PHP &gt; PHP extensions and tick <b>pdo_mysql</b>. WAMP restarts Apache by itself.');
    }
    $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, db_options());
        $pdo->exec("SET sql_mode = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION'");
    } catch (PDOException $e) {
        $code = isset($e->errorInfo[1]) ? (int)$e->errorInfo[1] : 0;
        if ($code === 1049 || strpos($e->getMessage(), 'Unknown database') !== false) {
            header('Location: ' . app_url('install.php'));
            exit;
        }
        fatal_page('Cannot connect to the database',
            'Check that WAMP is running (tray icon is green) and that the settings in <b>includes/config.php</b> are correct.<br><br>'
            . '<small>' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . '</small>');
    }
    return $pdo;
}

function fatal_page(string $title, string $html, int $code = 500): void
{
    http_response_code($code);
    echo '<!doctype html><meta charset="utf-8"><title>' . htmlspecialchars($title) . '</title>'
       . '<body style="font-family:Segoe UI,Arial,sans-serif;background:#EEF1F4;color:#1C2630;padding:48px">'
       . '<div style="max-width:620px;margin:auto;background:#fff;border:1px solid #D5DBE1;border-radius:6px;padding:28px 32px">'
       . '<h1 style="font-size:22px;margin:0 0 12px">' . htmlspecialchars($title) . '</h1><p style="line-height:1.6">' . $html . '</p></div></body>';
    exit;
}
