<?php
/* Sessions, sign-in state and permissions */

function start_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    session_name('itstore');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure'   => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    ]);
    session_start();
}

function current_user(): ?array
{
    static $user = false;
    if ($user !== false) {
        return $user;
    }
    $user = null;
    if (empty($_SESSION['uid'])) {
        return null;
    }
    $st = db()->prepare('SELECT id, username, full_name, role, is_active FROM users WHERE id = ?');
    $st->execute([(int)$_SESSION['uid']]);
    $row = $st->fetch();
    if ($row && (int)$row['is_active'] === 1) {
        $user = $row;
    }
    return $user;
}

function is_admin(): bool
{
    $u = current_user();
    return $u !== null && $u['role'] === 'admin';
}

function require_login(): void
{
    $idle = SESSION_IDLE_MINUTES * 60;
    if (!empty($_SESSION['last_seen']) && time() - (int)$_SESSION['last_seen'] > $idle) {
        $_SESSION = [];
        session_regenerate_id(true);
        flash('info', 'You were signed out after a period of no activity. Sign in again to continue.');
        redirect('login.php');
    }
    if (current_user() === null) {
        $back = $_SERVER['REQUEST_URI'] ?? '';
        redirect('login.php' . ($back ? '?next=' . urlencode($back) : ''));
    }
    $_SESSION['last_seen'] = time();
}

function is_guest(): bool
{
    $u = current_user();
    return $u !== null && $u['role'] === 'guest';
}

/** Admins and users can add and edit equipment; guests can only look */
function can_edit(): bool
{
    $u = current_user();
    return $u !== null && ($u['role'] === 'admin' || $u['role'] === 'user');
}

/** Print, PDF and CSV. Guests too, unless GUESTS_CAN_EXPORT is false in config.php */
function can_export(): bool
{
    return current_user() !== null && (!is_guest() || !defined('GUESTS_CAN_EXPORT') || GUESTS_CAN_EXPORT);
}

function role_label(string $role): string
{
    $labels = ['admin' => 'Administrator', 'user' => 'User', 'guest' => 'Guest (view only)'];
    return $labels[$role] ?? ucfirst($role);
}

function deny_page(string $title, string $message): void
{
    http_response_code(403);
    $pageTitle = $title;
    $activeNav = '';
    require __DIR__ . '/header.php';
    echo '<div class="empty"><h1>' . e($title) . '</h1><p>' . e($message) . '</p>'
       . '<p><a class="btn" href="devices.php">Go to equipment</a></p></div>';
    require __DIR__ . '/footer.php';
    exit;
}

function require_admin(): void
{
    require_login();
    if (!is_admin()) {
        deny_page('Admins only', 'This page is for administrators. Ask an admin if you need access.');
    }
}

function require_editor(): void
{
    require_login();
    if (!can_edit()) {
        deny_page('View only', 'Your guest account can view equipment but not add or change it. Ask an admin if you need to make changes.');
    }
}

function require_export(): void
{
    require_login();
    if (!can_export()) {
        deny_page('Not available', 'Printing and downloading are switched off for guest accounts.');
    }
}

/** Databases set up before guest accounts existed need the new role added once */
function ensure_guest_role(): void
{
    $col = db()->query("SHOW COLUMNS FROM users LIKE 'role'")->fetch();
    if ($col && stripos((string)$col['Type'], "'guest'") === false) {
        db()->exec("ALTER TABLE users MODIFY role ENUM('admin','user','guest') NOT NULL DEFAULT 'user'");
    }
}
