<?php
/* Reading, checking and saving equipment from a CSV file */

const IMPORT_MAX_ROWS = 5000;
const IMPORT_MAX_BYTES = 5 * 1024 * 1024;

// Column names the importer understands (compared without spaces, dots or case)
const IMPORT_CORE = [
    'assettag' => 'asset_tag', 'tag' => 'asset_tag', 'tagno' => 'asset_tag', 'assetno' => 'asset_tag', 'assetnumber' => 'asset_tag',
    'stockno' => 'asset_tag', 'stocknumber' => 'asset_tag', 'inventoryno' => 'asset_tag', 'assetid' => 'asset_tag',
    'type' => 'type', 'devicetype' => 'type', 'equipmenttype' => 'type', 'itemtype' => 'type', 'category' => 'type',
    'make' => 'make', 'brand' => 'make', 'manufacturer' => 'make', 'company' => 'make',
    'model' => 'model', 'modelno' => 'model', 'modelnumber' => 'model',
    'serialno' => 'serial_no', 'serialnumber' => 'serial_no', 'serial' => 'serial_no', 'sn' => 'serial_no', 'servicetag' => 'serial_no',
    'section' => 'section', 'department' => 'section', 'dept' => 'section', 'branch' => 'section', 'office' => 'section',
    'location' => 'location', 'room' => 'location', 'place' => 'location', 'installedat' => 'location',
    'grant' => 'grant_name', 'grantname' => 'grant_name', 'grantno' => 'grant_name', 'granthead' => 'grant_name',
    'status' => 'status', 'condition' => 'status', 'serviceable' => 'status',
    'remarks' => 'remarks', 'remark' => 'remarks', 'notes' => 'remarks', 'note' => 'remarks', 'comments' => 'remarks',
    'additionaldetails' => 'extras', 'specifications' => 'specs', 'specs' => 'specs',
];
// Row numbers and dates written by the app's own export are skipped
const IMPORT_IGNORE = ['', 'sno', 'srno', 'slno', 'sr', 'no', 'id', 'rowno', 'addedon', 'lastedited'];
// Other names that match a field by its kind
const IMPORT_KIND_ALIASES = [
    'person' => ['user', 'username', 'usedby', 'assignedto', 'issuedto', 'userofthepc', 'employee', 'owner', 'custodian'],
    'ip'     => ['ip', 'ipaddress', 'ipaddr', 'ipno'],
    'mac'    => ['mac', 'macaddress', 'macaddr', 'macid'],
];

// Common other names for the starter fields
const IMPORT_LABEL_ALIASES = [
    'cpu' => 'processor', 'processortype' => 'processor', 'memory' => 'ram', 'ramsize' => 'ram',
    'harddisk' => 'hdd', 'harddrive' => 'hdd', 'hdd1' => 'hdd', 'ssd1' => 'ssd', 'm2' => 'nvme', 'nvmessd' => 'nvme',
    'graphics' => 'gpu', 'graphicscard' => 'gpu', 'vga' => 'gpu', 'mainboard' => 'motherboard', 'mobo' => 'motherboard',
    'operatingsystem' => 'os', 'windows' => 'os', 'windowsversion' => 'osversion', 'build' => 'osversion',
    'screen' => 'screensize', 'display' => 'screensize', 'monitorsize' => 'screensize', 'toner' => 'tonercartridge', 'cartridge' => 'tonercartridge',
];

function import_norm(string $s): string
{
    return preg_replace('/[^a-z0-9]/', '', strtolower($s));
}

/** Reads the CSV into rows of trimmed cells. The first row is the header. */
function import_read_csv(string $path, string &$error): ?array
{
    $raw = @file_get_contents($path);
    if ($raw === false || trim($raw) === '') {
        $error = 'The file is empty.';
        return null;
    }
    if (strncmp($raw, "\xFF\xFE", 2) === 0 && function_exists('mb_convert_encoding')) {
        $raw = mb_convert_encoding(substr($raw, 2), 'UTF-8', 'UTF-16LE');   // Excel "Unicode text"
    } elseif (strncmp($raw, "\xEF\xBB\xBF", 3) === 0) {
        $raw = substr($raw, 3);
    }
    $utf8 = function_exists('mb_check_encoding') ? mb_check_encoding($raw, 'UTF-8') : (bool)preg_match('//u', $raw);
    if (!$utf8) {
        // Excel's plain "CSV (Comma delimited)" is saved as Windows-1252
        $conv = function_exists('mb_convert_encoding') ? mb_convert_encoding($raw, 'UTF-8', 'Windows-1252') : @iconv('Windows-1252', 'UTF-8//IGNORE', $raw);
        $raw = $conv !== false ? $conv : $raw;
    }

    $firstLine = strtok($raw, "\n");
    $delims = [',' => substr_count($firstLine, ','), ';' => substr_count($firstLine, ';'), "\t" => substr_count($firstLine, "\t")];
    arsort($delims);
    $delim = (string)key($delims);

    $h = fopen('php://temp', 'r+');
    fwrite($h, $raw);
    rewind($h);
    $rows = [];
    while (($r = fgetcsv($h, 0, $delim, '"', '')) !== false) {
        $r = array_map(function ($c) { return trim((string)$c); }, $r);
        if (implode('', $r) === '') {
            continue;
        }
        $rows[] = $r;
        if (count($rows) > IMPORT_MAX_ROWS + 1) {
            fclose($h);
            $error = 'The file has more than ' . number_format(IMPORT_MAX_ROWS) . ' rows. Split it into smaller files.';
            return null;
        }
    }
    fclose($h);
    if (count($rows) < 2) {
        $error = 'The file needs a first row with column names and at least one row of equipment below it.';
        return null;
    }
    return $rows;
}

function import_parse_date(string $v): ?string
{
    $v = trim($v);
    if (preg_match('/^(\d{4})-(\d{1,2})-(\d{1,2})/', $v, $m)) {
        [$y, $mo, $d] = [(int)$m[1], (int)$m[2], (int)$m[3]];
    } elseif (preg_match('#^(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{2}|\d{4})$#', $v, $m)) {
        [$d, $mo, $y] = [(int)$m[1], (int)$m[2], (int)$m[3]];
        if ($y < 100) {
            $y += 2000;
        }
    } elseif (preg_match('/[a-z]/i', $v) && ($ts = strtotime($v)) !== false) {
        return date('Y-m-d', $ts);   // e.g. 15 Mar 2027
    } else {
        return null;
    }
    return checkdate($mo, $d, $y) ? sprintf('%04d-%02d-%02d', $y, $mo, $d) : null;
}

/** Cleans one value for a type field. Returns [value, error, warning]. */
function import_check_value(array $fl, string $v): array
{
    $v = str_cut($v, $fl['field_type'] === 'textarea' ? 5000 : 255);
    if ($v === '') {
        return ['', null, null];
    }
    $label = $fl['label'];
    switch ($fl['field_type']) {
        case 'ip':
            return filter_var($v, FILTER_VALIDATE_IP) ? [$v, null, null] : [$v, "$label \"$v\" is not a valid IP address.", null];
        case 'mac':
            $m = normalize_mac($v);
            return $m !== null ? [$m, null, null] : [$v, "$label \"$v\" is not a valid MAC address.", null];
        case 'number':
            $n = str_replace([',', ' '], '', $v);
            return is_numeric($n) ? [$n, null, null] : [$v, "$label should be a number, not \"$v\".", null];
        case 'date':
            $d = import_parse_date($v);
            return $d !== null ? [$d, null, null] : [$v, "$label \"$v\" is not a date. Use YYYY-MM-DD or DD/MM/YYYY.", null];
        case 'select':
            foreach (field_options($fl['options']) as $o) {
                if (strcasecmp($o, $v) === 0) {
                    return [$o, null, null];
                }
            }
            return [$v, null, "$label \"$v\" is not one of the drop-down choices; it will be saved as written."];
    }
    return [$v, null, null];
}

function import_status(string $v): array
{
    if ($v === '') {
        return [STATUS_OPTIONS[0], null];
    }
    $n = import_norm($v);
    foreach (STATUS_OPTIONS as $s) {
        if (import_norm($s) === $n) {
            return [$s, null];
        }
    }
    $aliases = ['servicable' => 'Serviceable', 'ok' => 'Serviceable', 'working' => 'Serviceable', 'inuse' => 'Serviceable', 's' => 'Serviceable',
        'unservicable' => 'Unserviceable', 'unserviceble' => 'Unserviceable', 'us' => 'Unserviceable', 'faulty' => 'Unserviceable',
        'dead' => 'Unserviceable', 'notworking' => 'Unserviceable', 'outoforder' => 'Unserviceable'];
    if (isset($aliases[$n]) && in_array($aliases[$n], STATUS_OPTIONS, true)) {
        return [$aliases[$n], null];
    }
    return [str_cut($v, 30), "Status \"$v\" is not one of " . implode(', ', STATUS_OPTIONS) . '; it will be saved as written.'];
}

/** "Label: value; Label: value" (the format the CSV export writes) */
function import_split_pairs(string $s): array
{
    $out = [];
    foreach (preg_split('/;\s*/', $s) as $part) {
        $part = trim($part);
        if ($part === '') {
            continue;
        }
        $pos = strpos($part, ':');
        if ($pos === false) {
            $out[] = ['Detail', $part];
        } else {
            $out[] = [trim(substr($part, 0, $pos)), trim(substr($part, $pos + 1))];
        }
    }
    return $out;
}

/**
 * Checks every row and works out what will happen to it.
 * $defaultType: type for rows without a Type cell (0 = none). $mode: 'skip' or 'update'.
 */
function import_analyse(array $table, int $defaultType, string $mode): array
{
    $pdo = db();
    $header = $table[0];

    // Types and their fields, looked up by name, prefix, field label and kind alias
    $types = [];
    $typeByName = [];
    foreach ($pdo->query('SELECT id, name, prefix FROM device_types') as $t) {
        $types[(int)$t['id']] = $t + ['fields' => [], 'byLabel' => [], 'byKind' => []];
        $typeByName[import_norm($t['name'])] = (int)$t['id'];
        $typeByName[import_norm($t['prefix'])] = $typeByName[import_norm($t['prefix'])] ?? (int)$t['id'];
    }
    foreach ($pdo->query('SELECT * FROM type_fields ORDER BY sort_order, id') as $fl) {
        $tid = (int)$fl['type_id'];
        if (!isset($types[$tid])) {
            continue;
        }
        $types[$tid]['fields'][(int)$fl['id']] = $fl;
        $types[$tid]['byLabel'][import_norm($fl['label'])] = $types[$tid]['byLabel'][import_norm($fl['label'])] ?? (int)$fl['id'];
        if (isset(IMPORT_KIND_ALIASES[$fl['field_type']]) && !isset($types[$tid]['byKind'][$fl['field_type']])) {
            $types[$tid]['byKind'][$fl['field_type']] = (int)$fl['id'];
        }
    }
    $findField = function (int $tid, string $label) use ($types): ?int {
        $n = import_norm($label);
        if (isset($types[$tid]['byLabel'][$n])) {
            return $types[$tid]['byLabel'][$n];
        }
        if (isset(IMPORT_LABEL_ALIASES[$n]) && isset($types[$tid]['byLabel'][IMPORT_LABEL_ALIASES[$n]])) {
            return $types[$tid]['byLabel'][IMPORT_LABEL_ALIASES[$n]];
        }
        foreach (IMPORT_KIND_ALIASES as $kind => $names) {
            if (in_array($n, $names, true) && isset($types[$tid]['byKind'][$kind])) {
                return $types[$tid]['byKind'][$kind];
            }
        }
        return null;
    };

    // What each column means
    $cols = [];
    $hasType = false;
    $seenCore = [];
    foreach ($header as $i => $h) {
        $n = import_norm($h);
        if (isset(IMPORT_CORE[$n]) && !isset($seenCore[IMPORT_CORE[$n]])) {
            $cols[$i] = ['core', IMPORT_CORE[$n]];
            $seenCore[IMPORT_CORE[$n]] = true;
            $hasType = $hasType || IMPORT_CORE[$n] === 'type';
        } elseif (in_array($n, IMPORT_IGNORE, true)) {
            $cols[$i] = ['ignore', ''];
        } else {
            $cols[$i] = ['other', str_cut($h, 100)];
        }
    }

    // Existing items, and values that should not appear twice
    $existing = [];
    foreach ($pdo->query('SELECT id, asset_tag, type_id FROM devices') as $d) {
        $existing[strtolower($d['asset_tag'])] = $d;
    }
    $seen = ['serial' => [], 'ip' => [], 'mac' => []];
    foreach ($pdo->query("SELECT asset_tag, serial_no FROM devices WHERE serial_no <> ''") as $d) {
        $seen['serial'][strtolower($d['serial_no'])][] = $d['asset_tag'];
    }
    foreach ($pdo->query("SELECT d.asset_tag, tf.field_type, v.value FROM device_values v JOIN type_fields tf ON tf.id = v.field_id
                          JOIN devices d ON d.id = v.device_id WHERE tf.field_type IN ('ip','mac')") as $d) {
        $seen[$d['field_type']][strtolower($d['value'])][] = $d['asset_tag'];
    }

    $rows = [];
    $tagsInFile = [];
    $counts = ['add' => 0, 'update' => 0, 'same' => 0, 'skip' => 0, 'error' => 0];
    $limits = ['asset_tag' => 50, 'make' => 100, 'model' => 100, 'serial_no' => 100, 'section' => 100, 'location' => 100, 'grant_name' => 100, 'status' => 100, 'remarks' => 5000];

    foreach (array_slice($table, 1) as $k => $cells) {
        $row = ['line' => $k + 2, 'action' => 'add', 'errors' => [], 'warnings' => [], 'changes' => [], 'type_id' => 0,
                'core' => [], 'values' => [], 'extras' => [], 'existing_id' => 0, 'tag' => ''];

        // Which type is this row? (Type cell, else the type picked on the form, else the existing item's type when updating)
        $tid = $defaultType;
        $typeCell = '';
        $tagCell = '';
        foreach ($cols as $i => $c) {
            if ($c[0] === 'core' && $c[1] === 'type') {
                $typeCell = $cells[$i] ?? '';
            }
            if ($c[0] === 'core' && $c[1] === 'asset_tag') {
                $tagCell = strtolower($cells[$i] ?? '');
            }
        }
        if ($typeCell === '' && !$tid && $mode === 'update' && $tagCell !== '' && isset($existing[$tagCell])) {
            $tid = (int)$existing[$tagCell]['type_id'];
        }
        if ($typeCell !== '') {
            $tid = $typeByName[import_norm($typeCell)] ?? 0;
            if (!$tid) {
                $row['errors'][] = "Type \"$typeCell\" is not a device type here. Use a name from Device types & fields.";
            }
        } elseif (!$tid || !isset($types[$tid])) {
            $tid = 0;
            $row['errors'][] = $hasType ? 'The Type cell is empty.' : 'No type. Pick the type of equipment above, or add a Type column to the file.';
        }
        $row['type_id'] = $tid;

        $specs = [];
        foreach ($cols as $i => $c) {
            $v = $cells[$i] ?? '';
            if ($c[0] === 'ignore' || $v === '') {
                continue;
            }
            if ($c[0] === 'core') {
                if ($c[1] === 'extras') {
                    foreach (import_split_pairs($v) as $p) {
                        $row['extras'][] = $p;
                    }
                } elseif ($c[1] === 'specs') {
                    $specs = array_merge($specs, import_split_pairs($v));
                } elseif ($c[1] !== 'type') {
                    $row['core'][$c[1]] = str_cut($v, $limits[$c[1]]);
                }
            } else {
                $fid = $tid ? $findField($tid, $c[1]) : null;
                if ($fid !== null) {
                    $row['values'][$fid] = $v;
                } else {
                    $row['extras'][] = [$c[1], $v];
                }
            }
        }
        foreach ($specs as $p) {
            $fid = $tid ? $findField($tid, $p[0]) : null;
            if ($fid !== null && !isset($row['values'][$fid])) {
                $row['values'][$fid] = $p[1];
            } elseif ($fid === null) {
                $row['extras'][] = $p;
            }
        }
        $row['extras'] = array_map(function ($p) { return [str_cut($p[0], 100), str_cut($p[1], 2000)]; }, $row['extras']);

        // Check type field values
        foreach ($row['values'] as $fid => $v) {
            [$clean, $err, $warn] = import_check_value($types[$tid]['fields'][$fid], $v);
            $row['values'][$fid] = $clean;
            if ($err) {
                $row['errors'][] = $err;
            }
            if ($warn) {
                $row['warnings'][] = $warn;
            }
        }
        if (isset($row['core']['status'])) {
            [$row['core']['status'], $warn] = import_status($row['core']['status']);
            if ($warn) {
                $row['warnings'][] = $warn;
            }
        }

        // Asset tag: new, already in the register, or repeated in the file
        $tag = $row['core']['asset_tag'] ?? '';
        $row['tag'] = $tag;
        if ($tag !== '') {
            $lk = strtolower($tag);
            if (isset($tagsInFile[$lk])) {
                $row['errors'][] = "Asset tag $tag is also on row {$tagsInFile[$lk]} of the file.";
            } else {
                $tagsInFile[$lk] = $row['line'];
            }
            if (isset($existing[$lk])) {
                if ($mode === 'update') {
                    if ($tid && (int)$existing[$lk]['type_id'] !== $tid) {
                        $row['errors'][] = "$tag is already in the register as a different type.";
                    }
                    $row['action'] = 'update';
                    $row['existing_id'] = (int)$existing[$lk]['id'];
                } else {
                    $row['action'] = 'skip';
                    $row['warnings'][] = "$tag is already in the register, so this row is skipped.";
                }
            }
        }

        // Required fields (for new items)
        if ($row['action'] === 'add' && $tid) {
            foreach ($types[$tid]['fields'] as $fid => $fl) {
                if ((int)$fl['is_required'] === 1 && ($row['values'][$fid] ?? '') === '') {
                    $row['errors'][] = $fl['label'] . ' is required for ' . $types[$tid]['name'] . '.';
                }
            }
        }

        // Possible duplicates (warnings only)
        if ($row['action'] !== 'skip' && !$row['errors']) {
            $self = strtolower($tag);
            $dupNote = function (string $what, string $val, array $tags) use ($self): ?string {
                $tags = array_values(array_filter(array_unique($tags), function ($t) use ($self) { return strtolower($t) !== $self; }));
                return $tags ? "$what $val is also on " . implode(', ', array_slice($tags, 0, 3)) . '.' : null;
            };
            $mark = $tag !== '' ? $tag : 'row ' . $row['line'];
            if (($s = $row['core']['serial_no'] ?? '') !== '') {
                if ($n = $dupNote('Serial no.', $s, $seen['serial'][strtolower($s)] ?? [])) {
                    $row['warnings'][] = $n;
                }
                $seen['serial'][strtolower($s)][] = $mark;
            }
            foreach ($row['values'] as $fid => $v) {
                $kind = $types[$tid]['fields'][$fid]['field_type'];
                if (($kind === 'ip' || $kind === 'mac') && $v !== '') {
                    if ($n = $dupNote($types[$tid]['fields'][$fid]['label'], $v, $seen[$kind][strtolower($v)] ?? [])) {
                        $row['warnings'][] = $n;
                    }
                    $seen[$kind][strtolower($v)][] = $mark;
                }
            }
        }

        if ($row['errors']) {
            $row['action'] = 'error';
        } elseif ($row['action'] === 'update') {
            $row['changes'] = import_merge($row, $types[$tid])['changes'];
            if (!$row['changes']) {
                $row['action'] = 'same';
            }
        }
        $counts[$row['action']]++;
        $rows[] = $row;
    }

    // Describe the columns for the preview
    $described = [];
    foreach ($header as $i => $h) {
        [$kind, $key] = $cols[$i];
        if ($kind === 'ignore') {
            $meaning = 'Not imported';
        } elseif ($kind === 'core') {
            $names = ['asset_tag' => 'Asset tag', 'type' => 'Type', 'make' => 'Make', 'model' => 'Model', 'serial_no' => 'Serial number',
                'section' => 'Section', 'location' => 'Location', 'grant_name' => 'Grant', 'status' => 'Status', 'remarks' => 'Remarks',
                'extras' => 'Additional details (Label: value; ...)', 'specs' => 'Type fields (Label: value; ...)'];
            $meaning = $names[$key];
        } elseif ($defaultType && !$hasType) {
            $fid = $findField($defaultType, $key);
            $meaning = $fid ? $types[$defaultType]['name'] . ' field "' . $types[$defaultType]['fields'][$fid]['label'] . '"' : 'Additional detail "' . $key . '"';
        } else {
            $meaning = 'A field of the row\'s type if it has one with this name, otherwise an additional detail';
        }
        $described[] = [$h === '' ? '(no name)' : $h, $meaning];
    }

    return ['rows' => $rows, 'counts' => $counts, 'columns' => $described, 'types' => $types];
}

/** For an update row: the item's current data with the file's non-blank cells applied, and what changed */
function import_merge(array $r, array $type): array
{
    $coreKeys = ['make', 'model', 'serial_no', 'section', 'location', 'grant_name', 'status', 'remarks'];
    $coreLabels = ['make' => 'Make', 'model' => 'Model', 'serial_no' => 'Serial no.', 'section' => 'Section', 'location' => 'Location',
        'grant_name' => 'Grant', 'status' => 'Status'];
    $id = (int)$r['existing_id'];
    $d = load_device($id);
    $oldVals = load_device_values($id);
    $oldX = load_device_extras($id);
    $changes = [];
    $c = [];
    foreach ($coreKeys as $k) {
        $c[$k] = (string)$d[$k];
        if (isset($r['core'][$k]) && $r['core'][$k] !== $c[$k]) {
            $changes[] = $k === 'remarks' ? 'Remarks updated' : $coreLabels[$k] . ': ' . ($c[$k] === '' ? '(blank)' : $c[$k]) . ' → ' . $r['core'][$k];
            $c[$k] = $r['core'][$k];
        }
    }
    $vals = $oldVals;
    foreach ($r['values'] as $fid => $v) {
        if ($v !== '' && ($vals[$fid] ?? '') !== $v) {
            $o = $vals[$fid] ?? '';
            $changes[] = $type['fields'][$fid]['label'] . ': ' . ($o === '' ? '(blank)' : $o) . ' → ' . $v;
            $vals[$fid] = $v;
        }
    }
    $extras = array_map(function ($x) { return [$x['label'], $x['value']]; }, $oldX);
    $xChanged = false;
    foreach ($r['extras'] as $x) {
        $found = false;
        foreach ($extras as $j => $old) {
            if (strcasecmp($old[0], $x[0]) === 0) {
                $found = true;
                if ($old[1] !== $x[1]) {
                    $extras[$j][1] = $x[1];
                    $xChanged = true;
                }
            }
        }
        if (!$found) {
            $extras[] = $x;
            $xChanged = true;
        }
    }
    if ($xChanged) {
        $changes[] = 'Additional details updated';
    }
    return ['id' => $id, 'device' => $d, 'core' => $c, 'values' => $vals, 'extras' => $extras, 'changes' => $changes];
}

/** Saves the checked rows. Returns counts of what was done. */
function import_apply(array $an, string $fileName): array
{
    $pdo = db();
    $uid = (int)current_user()['id'];
    $ts = now();
    $done = ['added' => 0, 'updated' => 0, 'unchanged' => 0];
    $types = $an['types'];

    // Rows with their own tags first, so automatic numbers never clash with them
    $rows = array_filter($an['rows'], function ($r) { return $r['action'] === 'add' || $r['action'] === 'update'; });
    $done['unchanged'] = $an['counts']['same'] ?? 0;
    usort($rows, function ($a, $b) { return [$a['tag'] === '' ? 1 : 0, $a['line']] <=> [$b['tag'] === '' ? 1 : 0, $b['line']]; });

    $coreKeys = ['make', 'model', 'serial_no', 'section', 'location', 'grant_name', 'status', 'remarks'];
    $insVal = $pdo->prepare('INSERT INTO device_values (device_id, field_id, value) VALUES (?,?,?)');
    $insX = $pdo->prepare('INSERT INTO device_extras (device_id, label, value, sort_order) VALUES (?,?,?,?)');

    $pdo->beginTransaction();
    try {
        foreach ($rows as $r) {
            $type = $types[$r['type_id']];
            if ($r['action'] === 'add') {
                $tag = $r['tag'] !== '' ? $r['tag'] : next_asset_tag($type['prefix']);
                $c = array_merge(array_fill_keys($coreKeys, ''), ['status' => STATUS_OPTIONS[0]], $r['core']);
                $pdo->prepare('INSERT INTO devices (asset_tag, type_id, make, model, serial_no, section, location, grant_name, status, remarks,
                               created_by, updated_by, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
                    ->execute([$tag, $r['type_id'], $c['make'], $c['model'], $c['serial_no'], $c['section'], $c['location'], $c['grant_name'],
                        $c['status'], $c['remarks'], $uid, $uid, $ts, $ts]);
                $id = (int)$pdo->lastInsertId();
                foreach ($r['values'] as $fid => $v) {
                    if ($v !== '') {
                        $insVal->execute([$id, $fid, $v]);
                    }
                }
                foreach ($r['extras'] as $i => $x) {
                    $insX->execute([$id, $x[0], $x[1], $i]);
                }
                $summary = trim($type['name'] . ': ' . $c['make'] . ' ' . $c['model']) . ($c['serial_no'] !== '' ? ', S/N ' . $c['serial_no'] : '');
                log_activity('added', $id, $tag, $summary . "\nImported from " . $fileName);
                $done['added']++;
                continue;
            }

            // Update: cells with a value replace the current value, blank cells keep it
            $m = import_merge($r, $type);
            [$id, $d, $c, $vals, $extras, $changes] = [$m['id'], $m['device'], $m['core'], $m['values'], $m['extras'], $m['changes']];
            if (!$changes) {
                $done['unchanged']++;
                continue;
            }
            $pdo->prepare('UPDATE devices SET make=?, model=?, serial_no=?, section=?, location=?, grant_name=?, status=?, remarks=?, updated_by=?, updated_at=? WHERE id=?')
                ->execute([$c['make'], $c['model'], $c['serial_no'], $c['section'], $c['location'], $c['grant_name'], $c['status'], $c['remarks'], $uid, $ts, $id]);
            $pdo->prepare('DELETE FROM device_values WHERE device_id = ?')->execute([$id]);
            foreach ($vals as $fid => $v) {
                if ($v !== '') {
                    $insVal->execute([$id, $fid, $v]);
                }
            }
            $pdo->prepare('DELETE FROM device_extras WHERE device_id = ?')->execute([$id]);
            foreach ($extras as $i => $x) {
                $insX->execute([$id, $x[0], $x[1], $i]);
            }
            log_activity('updated', $id, $d['asset_tag'], 'Imported from ' . $fileName . "\n" . implode("\n", $changes));
            $done['updated']++;
        }
        $pdo->commit();
    } catch (Throwable $ex) {
        $pdo->rollBack();
        throw $ex;
    }
    return $done;
}
