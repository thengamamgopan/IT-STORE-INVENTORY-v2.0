<?php
/** @var string $pageTitle */
/** @var string $activeNav */
$pageTitle = $pageTitle ?? APP_NAME;
$activeNav = $activeNav ?? '';
$me = current_user();
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle) ?> | <?= e(APP_NAME) ?></title>
<link rel="stylesheet" href="assets/style.css?v=4">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
</head>
<body>
<a class="skip" href="#main">Skip to content</a>
<div class="app">
  <aside class="sidebar" id="sidebar">
    <div class="brand">
      <span class="brand-mark" aria-hidden="true">IT</span>
      <span class="brand-text"><b><?= e(APP_NAME) ?></b><small><?= e(ORG_NAME) ?></small></span>
    </div>
    <nav class="nav" aria-label="Main">
      <?= nav_link('dashboard.php', 'grid', 'Dashboard', 'dashboard', $activeNav) ?>
      <?= nav_link('devices.php', 'list', 'Equipment', 'devices', $activeNav) ?>
      <?php if (can_edit()): ?><?= nav_link('device_form.php', 'plus', 'Add equipment', 'add', $activeNav) ?><?php endif; ?>
      <?php if ($me && $me['role'] === 'admin'): ?>
        <div class="nav-group">Administration</div>
        <?= nav_link('types.php', 'sliders', 'Device types & fields', 'types', $activeNav) ?>
        <?= nav_link('users.php', 'users', 'Users', 'users', $activeNav) ?>
        <?= nav_link('activity.php', 'history', 'Activity log', 'activity', $activeNav) ?>
      <?php endif; ?>
    </nav>
    <?php if ($me): ?>
    <div class="me">
      <div class="me-name"><?= icon('user', 16) ?><span><?= e($me['full_name']) ?><small><?= e(role_label($me['role'])) ?></small></span></div>
      <?php if (!is_guest()): ?><?= nav_link('profile.php', 'key', 'Change password', 'profile', $activeNav) ?><?php endif; ?>
      <a href="logout.php?t=<?= e(csrf_token()) ?>"><?= icon('logout') ?><span>Sign out</span></a>
    </div>
    <?php endif; ?>
  </aside>
  <div class="scrim" data-close-nav></div>
  <div class="main-wrap">
    <header class="topbar">
      <button class="icon-btn nav-toggle" type="button" data-open-nav aria-label="Open menu" aria-controls="sidebar"><?= icon('menu', 20) ?></button>
      <form class="topsearch" action="devices.php" method="get" role="search">
        <?= icon('search', 17) ?>
        <input type="search" name="q" value="<?= e($activeNav === 'devices' ? get('q') : '') ?>" placeholder="Search tag, serial, IP, MAC, user, section…" aria-label="Search equipment">
      </form>
      <?php if (can_edit()): ?><a class="btn btn-primary top-add" href="device_form.php"><?= icon('plus', 17) ?><span>Add equipment</span></a>
      <?php else: ?><span class="view-only top-add">View only</span><?php endif; ?>
    </header>
    <main id="main" class="content">
      <?= render_flash() ?>
