<?php
/* Loaded at the top of every page */

if (version_compare(PHP_VERSION, '7.4.0', '<')) {
    die('IT Store Inventory needs PHP 7.4 or newer. In WAMP, left-click the tray icon > PHP > Version and pick a newer one.');
}

require __DIR__ . '/config.php';
require __DIR__ . '/db.php';
require __DIR__ . '/functions.php';
require __DIR__ . '/icons.php';
require __DIR__ . '/auth.php';

date_default_timezone_set(APP_TIMEZONE);
start_session();
