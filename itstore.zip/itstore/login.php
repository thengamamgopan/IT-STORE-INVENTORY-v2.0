<?php
require __DIR__ . '/includes/init.php';

if (current_user()) {
    redirect('dashboard.php');
}

$error = '';
$username = '';
// only allow redirects back into this app
function safe_next(string $n): string
{
    return preg_match('#^/(?![/\\\\])[^\s]*$#', $n) || preg_match('#^[a-z_]+\.php(\?[^\s]*)?$#', $n) ? $n : '';
}
$next = safe_next(get('next'));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $username = strtolower(post('username'));
    $password = $_POST['password'] ?? '';
    $next = safe_next(post('next'));

    $st = db()->prepare('SELECT * FROM users WHERE username = ?');
    $st->execute([$username]);
    $u = $st->fetch();

    if ($u && $u['locked_until'] && strtotime($u['locked_until']) > time()) {
        $mins = (int)ceil((strtotime($u['locked_until']) - time()) / 60);
        $error = "Too many wrong passwords. This account is locked for $mins more minute" . ($mins === 1 ? '' : 's') . ', or an admin can unlock it.';
    } elseif ($u && (int)$u['is_active'] === 1 && is_string($password) && password_verify($password, $u['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['uid'] = (int)$u['id'];
        $_SESSION['last_seen'] = time();
        db()->prepare('UPDATE users SET failed_logins = 0, locked_until = NULL, last_login = ? WHERE id = ?')->execute([now(), $u['id']]);
        if (password_needs_rehash($u['password_hash'], PASSWORD_DEFAULT)) {
            db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([password_hash($password, PASSWORD_DEFAULT), $u['id']]);
        }
        log_activity('login');
        redirect($next !== '' ? $next : 'dashboard.php');
    } else {
        if ($u) {
            $fails = (int)$u['failed_logins'] + 1;
            $lock = $fails >= 5 ? date('Y-m-d H:i:s', time() + 10 * 60) : null;
            db()->prepare('UPDATE users SET failed_logins = ?, locked_until = ? WHERE id = ?')->execute([$lock ? 0 : $fails, $lock, $u['id']]);
        }
        $error = ($u && (int)$u['is_active'] !== 1)
            ? 'This account is switched off. Ask an admin to turn it back on.'
            : 'Wrong username or password.';
    }
}
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sign in | <?= e(APP_NAME) ?></title>
<link rel="stylesheet" href="assets/style.css?v=4"><link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
</head>
<body class="auth-page">
<main class="auth-card">
  <div class="auth-brand">
    <span class="brand-mark" aria-hidden="true">IT</span>
    <div><b><?= e(APP_NAME) ?></b><small><?= e(ORG_NAME) ?></small></div>
  </div>
  <h1>Sign in</h1>
  <?= render_flash() ?>
  <?php if ($error): ?><div class="notice notice-error" role="alert"><?= e($error) ?></div><?php endif; ?>
  <form method="post" class="stack">
    <?= csrf_field() ?>
    <input type="hidden" name="next" value="<?= e($next) ?>">
    <label class="field"><span>Username</span>
      <input name="username" value="<?= e($username) ?>" required autofocus autocomplete="username" autocapitalize="none"></label>
    <label class="field"><span>Password</span>
      <input type="password" name="password" required autocomplete="current-password"></label>
    <button class="btn btn-primary btn-block" type="submit">Sign in</button>
  </form>
  <p class="muted small">Forgot your password? Ask an administrator to reset it.</p>
</main>
</body>
</html>
